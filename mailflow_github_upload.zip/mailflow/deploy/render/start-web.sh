#!/bin/sh
set -eu

if [ -n "${RENDER_EXTERNAL_URL:-}" ]; then
  export APP_URL="${APP_URL:-$RENDER_EXTERNAL_URL}"
  export MAILFLOW_PUBLIC_BASE_URL="${MAILFLOW_PUBLIC_BASE_URL:-$RENDER_EXTERNAL_URL}"
  export MAILFLOW_TRUSTED_ORIGINS="${MAILFLOW_TRUSTED_ORIGINS:-$RENDER_EXTERNAL_URL}"
fi

export MAILFLOW_FRONTEND_DIR="${MAILFLOW_FRONTEND_DIR:-/app/frontend}"
exec uvicorn app.main:app \
  --host 0.0.0.0 \
  --port "${PORT:-10000}" \
  --proxy-headers \
  --forwarded-allow-ips '*'
