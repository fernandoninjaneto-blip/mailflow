#!/bin/sh
set -eu

if [ -n "${RENDER_EXTERNAL_URL:-}" ]; then
  export APP_URL="${APP_URL:-$RENDER_EXTERNAL_URL}"
  export MAILFLOW_PUBLIC_BASE_URL="${MAILFLOW_PUBLIC_BASE_URL:-$RENDER_EXTERNAL_URL}"
  export MAILFLOW_TRUSTED_ORIGINS="${MAILFLOW_TRUSTED_ORIGINS:-$RENDER_EXTERNAL_URL}"
fi

export MAILFLOW_FRONTEND_DIR="${MAILFLOW_FRONTEND_DIR:-/app/frontend}"

python -m app.worker &
worker_pid=$!
uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-10000}" --proxy-headers --forwarded-allow-ips '*' &
api_pid=$!

shutdown() {
  kill "$api_pid" "$worker_pid" 2>/dev/null || true
  wait "$api_pid" 2>/dev/null || true
  wait "$worker_pid" 2>/dev/null || true
}
trap shutdown INT TERM EXIT

while kill -0 "$api_pid" 2>/dev/null && kill -0 "$worker_pid" 2>/dev/null; do
  sleep 2
done

exit 1
