#!/usr/bin/env sh
set -eu

if [ "$#" -ne 1 ]; then
  echo "Uso: $0 caminho/do/backup.dump" >&2
  exit 2
fi
FILE="$1"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.production.yml}"
ENV_FILE="${ENV_FILE:-}"

compose() {
  if [ -n "$ENV_FILE" ]; then
    docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" "$@"
  else
    docker compose -f "$COMPOSE_FILE" "$@"
  fi
}

test -s "$FILE"
if [ -f "$FILE.sha256" ]; then
  sha256sum -c "$FILE.sha256"
fi

echo "ATENÇÃO: este comando substitui o banco mailflow do compose selecionado."
if [ "${MAILFLOW_CONFIRM_RESTORE:-}" != "RESTORE" ]; then
  echo "Defina MAILFLOW_CONFIRM_RESTORE=RESTORE para confirmar." >&2
  exit 3
fi

compose stop api worker
compose exec -T db sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" dropdb -U mailflow --if-exists mailflow && PGPASSWORD="$POSTGRES_PASSWORD" createdb -U mailflow mailflow'
cat "$FILE" | compose exec -T db sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" pg_restore -U mailflow -d mailflow --no-owner --no-privileges'
compose run --rm migrate
compose start api worker

echo "Restore concluído. Verifique /api/health/ready antes de liberar tráfego."
