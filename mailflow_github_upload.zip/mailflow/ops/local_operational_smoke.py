#!/usr/bin/env python3
from __future__ import annotations
import os, signal, subprocess, sys, tempfile, time
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / 'backend'
PORT = 18080
BASE = f'http://127.0.0.1:{PORT}'

def wait_status(path, wanted=200, timeout=20):
    deadline=time.time()+timeout
    last=None
    while time.time()<deadline:
        try:
            r=httpx.get(BASE+path, timeout=2); last=r.status_code
            if r.status_code==wanted: return r
        except Exception: pass
        time.sleep(.3)
    raise RuntimeError(f'{path}: esperado {wanted}, ultimo={last}')

def stop(p):
    if p and p.poll() is None:
        p.terminate()
        try: p.wait(timeout=5)
        except subprocess.TimeoutExpired: p.kill(); p.wait(timeout=3)

def main():
    tmp=Path(tempfile.mkdtemp(prefix='mailflow-v16-'))
    db=tmp/'staging.db'
    env=os.environ.copy()
    env.update({
        'DATABASE_URL':f'sqlite:///{db}', 'APP_ENV':'development',
        'APP_URL':BASE, 'MAILFLOW_PUBLIC_BASE_URL':BASE,
        'SESSION_COOKIE_NAME':'mailflow_session','CSRF_COOKIE_NAME':'mailflow_csrf',
        'COOKIE_SECURE':'false','MAILFLOW_EXPOSE_RESET_TOKEN':'false',
        'MAILFLOW_CSRF_ENABLED':'true','MAILFLOW_CSRF_SECRET':'c'*64,
        'MAILFLOW_SECURITY_SECRET':'s'*64,'MAILFLOW_UNSUBSCRIBE_SECRET':'u'*64,
        'MAILFLOW_SUPPRESSION_SECRET':'p'*64,
        'MAILFLOW_ORIGIN_CHECK_ENABLED':'true','MAILFLOW_TRUSTED_ORIGINS':BASE,
        'MAILFLOW_RATE_LIMIT_ENABLED':'true','TRUST_PROXY_HEADERS':'false',
        'MAIL_PROVIDER':'console','MAILFLOW_REQUIRE_WORKER_HEALTH':'true',
        'MAILFLOW_WORKER_STALE_SECONDS':'3','MAILFLOW_WORKER_INTERVAL_SECONDS':'1',
        'LOG_LEVEL':'WARNING','PYTHONUNBUFFERED':'1',
    })
    subprocess.run([sys.executable,'-m','alembic','upgrade','head'], cwd=BACKEND, env=env, check=True, stdout=subprocess.DEVNULL)
    api=worker=None
    try:
        api=subprocess.Popen([sys.executable,'-m','uvicorn','app.main:app','--host','127.0.0.1','--port',str(PORT),'--log-level','warning'], cwd=BACKEND, env=env)
        worker=subprocess.Popen([sys.executable,'-m','app.worker'], cwd=BACKEND, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        wait_status('/api/health/live',200)
        wait_status('/api/health/ready',200)
        subprocess.run([sys.executable,str(ROOT/'ops'/'staging_smoke.py'),'--base-url',BASE], env=env, check=True)
        stop(worker); worker=None
        time.sleep(4.2)
        wait_status('/api/health/ready',503,timeout=8)
        print('[OK] readiness falha com worker parado/stale')
        worker=subprocess.Popen([sys.executable,'-m','app.worker'], cwd=BACKEND, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        wait_status('/api/health/ready',200,timeout=12)
        print('[OK] readiness recupera apos reinicio do worker')
        print(f'[PASS] smoke operacional local completo; db={db}')
    finally:
        stop(worker); stop(api)
    return 0

if __name__=='__main__': raise SystemExit(main())
