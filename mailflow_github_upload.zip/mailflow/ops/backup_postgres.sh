#!/usr/bin/env sh
set -eu

COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.production.yml}"
ENV_FILE="${ENV_FILE:-}"
BACKUP_DIR="${BACKUP_DIR:-./ops/backups}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FILE="$BACKUP_DIR/mailflow_$STAMP.dump"
mkdir -p "$BACKUP_DIR"

compose() {
  if [ -n "$ENV_FILE" ]; then
    docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" "$@"
  else
    docker compose -f "$COMPOSE_FILE" "$@"
  fi
}

echo "Criando backup em $FILE"
compose exec -T db sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" pg_dump -U mailflow -d mailflow -Fc' > "$FILE"

test -s "$FILE"
sha256sum "$FILE" > "$FILE.sha256"
echo "Backup concluído: $FILE"
