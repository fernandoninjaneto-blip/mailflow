#!/usr/bin/env sh
set -eu

if [ "${MAILFLOW_ENVIRONMENT:-}" != "staging" ]; then
  echo "Defina MAILFLOW_ENVIRONMENT=staging para executar o teste de restore." >&2
  exit 2
fi
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.staging.yml}"
ENV_FILE="${ENV_FILE:-.env.staging}"
BACKUP_DIR="${BACKUP_DIR:-./ops/backups}"
export COMPOSE_FILE ENV_FILE BACKUP_DIR

compose() {
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" "$@"
}

./ops/backup_postgres.sh
LATEST="$(ls -1t "$BACKUP_DIR"/mailflow_*.dump | head -1)"
sha256sum -c "$LATEST.sha256"

TEST_DB="mailflow_restore_test_$(date -u +%H%M%S)"
cleanup() {
  compose exec -T db sh -c "PGPASSWORD=\"\$POSTGRES_PASSWORD\" dropdb -U mailflow --if-exists '$TEST_DB'" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

compose exec -T db sh -c "PGPASSWORD=\"\$POSTGRES_PASSWORD\" createdb -U mailflow '$TEST_DB'"
cat "$LATEST" | compose exec -T db sh -c "PGPASSWORD=\"\$POSTGRES_PASSWORD\" pg_restore -U mailflow -d '$TEST_DB' --no-owner --no-privileges"

for table in workspaces contacts campaigns email_deliveries; do
  SRC="$(compose exec -T db sh -c "PGPASSWORD=\"\$POSTGRES_PASSWORD\" psql -U mailflow -d mailflow -Atqc 'select count(*) from $table'")"
  DST="$(compose exec -T db sh -c "PGPASSWORD=\"\$POSTGRES_PASSWORD\" psql -U mailflow -d '$TEST_DB' -Atqc 'select count(*) from $table'")"
  if [ "$SRC" != "$DST" ]; then
    echo "Falha no restore: $table origem=$SRC restaurado=$DST" >&2
    exit 4
  fi
  echo "[OK] restore $table: $DST registros"
done

ALEMBIC="$(compose exec -T db sh -c "PGPASSWORD=\"\$POSTGRES_PASSWORD\" psql -U mailflow -d '$TEST_DB' -Atqc 'select version_num from alembic_version limit 1'")"
test -n "$ALEMBIC"
echo "[OK] alembic_version restaurada: $ALEMBIC"
echo "Teste de backup/restore NÃO destrutivo concluído: $LATEST"
