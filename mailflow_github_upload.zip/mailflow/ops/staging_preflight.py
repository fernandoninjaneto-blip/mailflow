#!/usr/bin/env python3
from __future__ import annotations
import argparse, shutil, subprocess
from pathlib import Path

REQUIRED = ['MAILFLOW_HOST','POSTGRES_PASSWORD','MAILFLOW_CSRF_SECRET','MAILFLOW_SECURITY_SECRET','MAILFLOW_UNSUBSCRIBE_SECRET','MAILFLOW_SUPPRESSION_SECRET']

def load_env(path: Path):
    out={}
    for raw in path.read_text().splitlines():
        line=raw.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        k,v=line.split('=',1); out[k.strip()]=v.strip().strip('"').strip("'")
    return out

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--env-file',default='.env.staging')
    p.add_argument('--compose-file',default='docker-compose.staging.yml')
    p.add_argument('--skip-docker',action='store_true',help='Valida arquivos/segredos sem executar docker compose config')
    a=p.parse_args()
    env_path=Path(a.env_file); compose_path=Path(a.compose_file); errors=[]
    if not env_path.exists(): errors.append(f'{env_path} não existe')
    if not compose_path.exists(): errors.append(f'{compose_path} não existe')
    if errors:
        print('PREFLIGHT FAIL'); [print('-',e) for e in errors]; return 1
    env=load_env(env_path)
    for k in REQUIRED:
        if not env.get(k): errors.append(f'{k} ausente')
    for k in REQUIRED[2:]:
        if len(env.get(k,'')) < 32: errors.append(f'{k} deve ter >= 32 caracteres')
    if len(env.get('POSTGRES_PASSWORD','')) < 20: errors.append('POSTGRES_PASSWORD deve ter >= 20 caracteres')
    host=env.get('MAILFLOW_HOST','')
    if not host or '/' in host or ':' in host or '.' not in host: errors.append('MAILFLOW_HOST deve ser hostname DNS, sem esquema/caminho')
    if 'seudominio' in host.lower() or any(env.get(k,'').lower().startswith('gere-') for k in REQUIRED[1:]): errors.append('Substitua todos os placeholders do arquivo de ambiente')
    if env.get('MAIL_PROVIDER','console') != 'console': errors.append('Staging inicial deve usar MAIL_PROVIDER=console')
    text=compose_path.read_text()
    for svc in ['db','migrate','api','worker','frontend','caddy']:
        if f'  {svc}:' not in text: errors.append(f'serviço {svc} ausente no compose')
    if not a.skip_docker:
        if not shutil.which('docker'):
            errors.append('Docker não encontrado neste servidor')
        else:
            proc=subprocess.run(['docker','compose','--env-file',str(env_path),'-f',str(compose_path),'config','-q'],capture_output=True,text=True)
            if proc.returncode: errors.append('docker compose config falhou: '+(proc.stderr.strip() or proc.stdout.strip()))
    if errors:
        print('PREFLIGHT FAIL')
        for e in errors: print('-',e)
        return 1
    print('PREFLIGHT PASS')
    print(f'host={host} provider={env.get("MAIL_PROVIDER","console")} stale={env.get("MAILFLOW_WORKER_STALE_SECONDS","15")}s')
    return 0
if __name__=='__main__': raise SystemExit(main())
