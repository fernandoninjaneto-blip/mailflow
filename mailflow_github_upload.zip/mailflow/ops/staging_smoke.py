#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, time, uuid
from urllib.parse import urlparse
import httpx


def fail(msg: str):
    raise RuntimeError(msg)


def main() -> int:
    p = argparse.ArgumentParser(description='Smoke test HTTP do MailFlow staging')
    p.add_argument('--base-url', required=True)
    p.add_argument('--insecure', action='store_true')
    p.add_argument('--timeout', type=float, default=20)
    args = p.parse_args()
    base = args.base_url.rstrip('/')
    origin = f"{urlparse(base).scheme}://{urlparse(base).netloc}"
    run = uuid.uuid4().hex[:10]
    email = f'smoke-{run}@example.com'
    password = 'SmokeSenha123!'
    headers = {'Origin': origin, 'User-Agent': 'MailFlow-Staging-Smoke/1.0'}

    with httpx.Client(base_url=base, verify=not args.insecure, timeout=args.timeout, follow_redirects=True) as c:
        def csrf_token():
            for cookie in c.cookies.jar:
                if cookie.name.endswith('mailflow_csrf') or cookie.name.endswith('_csrf') or cookie.name == 'mailflow_csrf':
                    return cookie.value
            return None

        def req(method, path, **kwargs):
            h = dict(headers)
            h.update(kwargs.pop('headers', {}))
            if method.upper() not in {'GET','HEAD','OPTIONS'}:
                token = csrf_token()
                if token:
                    h['X-CSRF-Token'] = token
            r = c.request(method, path, headers=h, **kwargs)
            return r

        checks = []
        def ok(name, cond, detail=''):
            if not cond: fail(f'{name}: {detail}')
            checks.append(name)
            print(f'[OK] {name}')

        r = c.get('/api/health/live'); ok('liveness', r.status_code == 200, r.text)
        r = c.get('/api/health/ready'); ok('readiness', r.status_code == 200, r.text)

        r = req('POST','/api/auth/register', json={'workspace_name':f'Smoke {run}','name':'Admin Smoke','email':email,'password':password})
        ok('cadastro', r.status_code == 201, r.text)
        ok('cookie de sessao', any('session' in x.name for x in c.cookies.jar))
        ok('cookie csrf', csrf_token() is not None)
        r = c.get('/api/auth/me'); ok('sessao autenticada', r.status_code == 200, r.text)

        r = req('POST','/api/auth/logout'); ok('logout', r.status_code == 204, r.text)
        r = req('POST','/api/auth/login', json={'email':email,'password':password}); ok('login', r.status_code == 200, r.text)

        bad_email = f'naoexiste-{run}@example.com'
        statuses = [req('POST','/api/auth/login', json={'email':bad_email,'password':'errada'}).status_code for _ in range(11)]
        ok('rate limit login', statuses[-1] == 429 and 401 in statuses[:-1], str(statuses))

        csv = 'nome;email;tags;origem\nAna Smoke;ana-'+run+'@example.com;evento;CSV Smoke\nBruno Smoke;bruno-'+run+'@example.com;evento|comprador;CSV Smoke\n'
        mapping = json.dumps({'name':'nome','email':'email','tags':'tags','source':'origem'})
        r = req('POST','/api/contacts/import', files={'file':('smoke.csv',csv.encode(),'text/csv')}, data={'mapping':mapping,'duplicate_strategy':'skip','default_tags':'[]','default_source':'Smoke'})
        ok('importacao CSV', r.status_code == 200 and r.json().get('created') == 2, r.text)
        r = c.get('/api/contacts/search', params={'source':'CSV Smoke','page':1,'page_size':20})
        ok('busca de contatos', r.status_code == 200 and r.json()['total'] >= 2, r.text)
        items = r.json()['items']; ana = next(x for x in items if x['email'].startswith('ana-')); bruno = next(x for x in items if x['email'].startswith('bruno-'))

        r = req('POST','/api/lists', json={'name':f'Lista Smoke {run}','description':'Homologacao'})
        ok('criar lista', r.status_code == 201, r.text); list_id = r.json()['id']
        r = req('POST',f'/api/lists/{list_id}/members', json={'contact_ids':[ana['id'],bruno['id']]})
        ok('membros da lista', r.status_code == 200 and r.json()['member_count'] == 2, r.text)

        r = req('POST','/api/segments', json={'name':f'Segmento Smoke {run}','description':'Ativos do evento','match_mode':'all','rules':[{'field':'tag','operator':'contains','value':'evento'}]})
        ok('criar segmento', r.status_code == 201, r.text); segment_id = r.json()['id']
        r = c.get(f'/api/segments/{segment_id}/preview'); ok('preview segmento', r.status_code == 200 and r.json()['active_count'] >= 2, r.text)

        r = req('POST','/api/templates', json={'name':f'Template Smoke {run}','type':'Homologacao','subject':'Smoke {{nome}}','preheader':'Teste operacional','body':'Ola {{nome}}','editor_mode':'html','html_body':'<p>Ola {{nome}}</p><p>Smoke operacional.</p>'})
        ok('criar template', r.status_code == 201, r.text)

        r = req('POST','/api/campaigns', json={'name':f'Campanha Smoke {run}','subject':'Smoke {{nome}}','preheader':'Teste operacional','body':'Ola {{nome}}','editor_mode':'html','html_body':'<p>Ola {{nome}}</p><p>Smoke operacional.</p>','audience_type':'segment','audience_id':segment_id,'exclude_tags':['comprador'],'status':'draft'})
        ok('criar campanha', r.status_code == 201, r.text); cid = r.json()['id']
        review = c.get(f'/api/campaigns/{cid}/review'); ok('revisao pre-disparo', review.status_code == 200 and review.json()['eligible'] == 1 and review.json()['can_send'], review.text)
        rv = review.json()
        r = req('POST',f'/api/campaigns/{cid}/send', json={'review_token':rv['review_token'],'expected_recipients':rv['eligible'],'confirmation':'ENVIAR'})
        ok('enfileirar campanha', r.status_code == 200 and r.json()['queued'] == 1, r.text)

        deadline = time.time()+20
        dl = None
        while time.time() < deadline:
            rr = c.get(f'/api/campaigns/{cid}/deliveries')
            if rr.status_code == 200:
                dl = rr.json()
                if dl['sent'] + dl['delivered'] + dl['failed'] + dl.get('suppressed',0) >= 1: break
            time.sleep(.5)
        ok('worker processou fila', bool(dl) and dl['processed'] >= 1, json.dumps(dl or {}))

        r = req('POST','/api/suppressions', json={'email':bruno['email'],'reason':'manual'})
        ok('supressao global', r.status_code == 201, r.text)
        r = req('POST','/api/campaigns', json={'name':f'Supressao Smoke {run}','subject':'Supressao','preheader':'Teste','body':'Teste','editor_mode':'html','html_body':'<p>Teste</p>','audience_type':'all','status':'draft'})
        ok('campanha de supressao', r.status_code == 201, r.text); sid = r.json()['id']
        sr = c.get(f'/api/campaigns/{sid}/review'); ok('supressao aplicada na revisao', sr.status_code == 200 and (sr.json()['exclusions']['suppression'] + sr.json()['exclusions']['inactive_status']) >= 1 and sr.json()['eligible'] == 1, sr.text)

        r = req('POST','/api/automations', json={'name':f'Automacao Smoke {run}','trigger_type':'manual','trigger_config':{},'steps':[{'type':'add_tag','tag':'smoke-automation-ok'}],'reentry_policy':'once','active':True})
        ok('criar automacao', r.status_code == 201, r.text); aid = r.json()['id']
        r = req('POST',f'/api/automations/{aid}/enroll', json={'contact_id':ana['id']}); ok('inscrever automacao', r.status_code == 200, r.text)
        deadline = time.time()+12
        tagged = False
        while time.time() < deadline:
            rr = c.get(f"/api/contacts/{ana['id']}")
            if rr.status_code == 200 and 'smoke-automation-ok' in rr.json()['contact']['tags']:
                tagged = True; break
            time.sleep(.5)
        ok('worker processou automacao', tagged)

        r = c.get('/api/reports/overview', params={'days':30}); ok('relatorios avancados', r.status_code == 200 and 'summary' in r.json(), r.text)
        r = c.get('/api/health/ready'); ok('readiness final', r.status_code == 200, r.text)
        print(json.dumps({'result':'PASS','checks':checks,'workspace_email':email,'campaign_id':cid}, ensure_ascii=False))
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'[FAIL] {exc}', file=sys.stderr)
        raise SystemExit(1)
