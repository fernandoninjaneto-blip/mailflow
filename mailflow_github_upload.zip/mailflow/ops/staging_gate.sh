#!/usr/bin/env sh
set -eu

ENV_FILE="${ENV_FILE:-.env.staging}"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.staging.yml}"
test -f "$ENV_FILE" || { echo "Arquivo $ENV_FILE não encontrado." >&2; exit 2; }

# shellcheck disable=SC1090
set -a
. "$ENV_FILE"
set +a

: "${MAILFLOW_HOST:?Defina MAILFLOW_HOST em $ENV_FILE}"
python3 ./ops/staging_preflight.py --env-file "$ENV_FILE" --compose-file "$COMPOSE_FILE"
BASE_URL="https://${MAILFLOW_HOST}"
STALE="${MAILFLOW_WORKER_STALE_SECONDS:-15}"

compose() { docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" "$@"; }
status_code() { curl -sS -o /tmp/mailflow-health-body -w '%{http_code}' "$1" || true; }
wait_200() {
  url="$1"; limit="${2:-120}"; start="$(date +%s)"
  while :; do
    code="$(status_code "$url")"
    [ "$code" = "200" ] && return 0
    now="$(date +%s)"; [ $((now-start)) -ge "$limit" ] && { echo "Timeout aguardando 200 em $url (ultimo=$code)" >&2; cat /tmp/mailflow-health-body >&2 || true; return 1; }
    sleep 2
  done
}

echo "==> Subindo staging"
compose up -d --build
wait_200 "$BASE_URL/api/health/live" 180
wait_200 "$BASE_URL/api/health/ready" 180
echo "[OK] staging live/ready"

echo "==> Smoke HTTP"
python3 ./ops/staging_smoke.py --base-url "$BASE_URL"

echo "==> Teste de falha do worker"
compose stop worker
sleep $((STALE + 3))
CODE="$(status_code "$BASE_URL/api/health/ready")"
if [ "$CODE" = "200" ]; then
  echo "Readiness permaneceu 200 com worker stale; falha no gate." >&2
  compose start worker
  exit 5
fi
echo "[OK] readiness falhou com worker parado (HTTP $CODE)"
compose start worker
wait_200 "$BASE_URL/api/health/ready" 120
echo "[OK] readiness recuperou depois do restart"

echo "==> Backup/restore não destrutivo"
MAILFLOW_ENVIRONMENT=staging ENV_FILE="$ENV_FILE" COMPOSE_FILE="$COMPOSE_FILE" ./ops/test_backup_restore.sh

echo "==> Estado final"
compose ps
printf '\nPASS: staging operacional aprovado. O ambiente permaneceu no ar.\n'
