(function(){
  const registry=new Map();
  let seq=0;
  const esc=(v='')=>String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
  const clone=v=>JSON.parse(JSON.stringify(v));
  const safeColor=(v,d)=>/^#[0-9a-f]{6}$/i.test(v||'')?v:d;
  const safeUrl=(v,image=false)=>{v=String(v||'').trim();const schemes=image?['http://','https://']:['http://','https://','mailto:','tel:'];return schemes.some(x=>v.toLowerCase().startsWith(x))?v:'';};
  const clamp=(v,d,min,max)=>{v=parseInt(v,10);if(Number.isNaN(v))v=d;return Math.max(min,Math.min(max,v));};
  const defaults={
    heading:{text:'Seu título aqui',level:'h2',align:'left',font_size:28,color:'#16181d'},
    text:{text:'Escreva aqui o conteúdo do seu e-mail.',align:'left',font_size:16,color:'#3f4350'},
    image:{url:'',alt:'Imagem do e-mail',width:100,link:''},
    button:{text:'Clique em saiba mais',url:'https://',align:'left',bg_color:'#2427d8',text_color:'#ffffff',radius:8},
    divider:{color:'#e5e7eb'},
    spacer:{height:24}
  };
  const labels={heading:'Título',text:'Texto',image:'Imagem',button:'Botão',divider:'Divisor',spacer:'Espaçamento'};
  const icons={heading:'T',text:'¶',image:'▧',button:'▰',divider:'—',spacer:'↕'};

  function normalize(initial){
    const body=initial?.body||'';
    let blocks=Array.isArray(initial?.design_json)?clone(initial.design_json):[];
    if(!blocks.length && body.trim()) blocks=[{id:uid(),type:'text',data:{...defaults.text,text:body}}];
    blocks=blocks.map(b=>({id:b.id||uid(),type:defaults[b.type]?b.type:'text',data:{...defaults[b.type||'text'],...(b.data||{})}}));
    return {mode:initial?.editor_mode==='html'?'html':'visual',blocks,html:initial?.html_body||'',device:'desktop',selected:blocks[0]?.id||null};
  }
  function uid(){return `b_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,7)}`;}
  function variables(custom=[]){
    const base=[['{{nome}}','Nome'],['{{nome|Olá}}','Nome + fallback'],['{{sobrenome}}','Sobrenome'],['{{email}}','E-mail'],['{{empresa}}','Empresa']];
    custom.forEach(f=>base.push([`{{${f.key}}}`,f.label]));
    return base;
  }
  function substitute(text){
    const ctx={nome:'Fernando',sobrenome:'Neto',email:'fernando@exemplo.com',empresa:'Sua Empresa',cidade:'Belém',curso:'Psicanálise'};
    return String(text||'').replace(/\{\{\s*([\w.-]+)(?:\|([^{}]*))?\s*\}\}/g,(_,k,fallback)=>ctx[k]||String(fallback||'').trim());
  }
  function renderBlocks(blocks){
    const rows=[];
    for(const block of blocks){const d=block.data||{};
      if(block.type==='heading'){
        const level=['h1','h2','h3'].includes(d.level)?d.level:'h2',size=clamp(d.font_size,{h1:34,h2:28,h3:22}[level],14,52),align=['left','center','right'].includes(d.align)?d.align:'left',color=safeColor(d.color,'#16181d');
        rows.push(`<tr><td style="padding:12px 32px;text-align:${align}"><${level} style="margin:0;color:${color};font-family:Arial,sans-serif;font-size:${size}px;line-height:1.2">${esc(substitute(d.text)).replace(/\n/g,'<br>')}</${level}></td></tr>`);
      } else if(block.type==='text'){
        const size=clamp(d.font_size,16,11,28),align=['left','center','right'].includes(d.align)?d.align:'left',color=safeColor(d.color,'#3f4350');
        rows.push(`<tr><td style="padding:10px 32px;text-align:${align};color:${color};font-family:Arial,sans-serif;font-size:${size}px;line-height:1.6">${esc(substitute(d.text)).replace(/\n/g,'<br>')}</td></tr>`);
      } else if(block.type==='image'){
        const src=safeUrl(d.url,true); if(!src) rows.push('<tr><td style="padding:12px 32px;text-align:center;color:#8b909a;font-family:Arial,sans-serif;font-size:13px"><div style="padding:38px 18px;border:1px dashed #cfd2dc;border-radius:8px">Adicione a URL da imagem</div></td></tr>'); else {const width=clamp(d.width,100,10,100),alt=esc(d.alt||''),link=safeUrl(d.link);let img=`<img src="${esc(src)}" alt="${alt}" width="${width}%" style="display:inline-block;max-width:100%;height:auto;border:0;border-radius:8px">`;if(link)img=`<a href="${esc(link)}" target="_blank">${img}</a>`;rows.push(`<tr><td style="padding:12px 32px;text-align:center">${img}</td></tr>`);}
      } else if(block.type==='button'){
        const align=['left','center','right'].includes(d.align)?d.align:'left',bg=safeColor(d.bg_color,'#2427d8'),fg=safeColor(d.text_color,'#ffffff'),radius=clamp(d.radius,8,0,30),url=safeUrl(d.url)||'#';
        rows.push(`<tr><td style="padding:14px 32px;text-align:${align}"><a href="${esc(url)}" style="display:inline-block;background:${bg};color:${fg};font-family:Arial,sans-serif;font-size:15px;font-weight:bold;text-decoration:none;padding:12px 20px;border-radius:${radius}px">${esc(substitute(d.text||'Clique em saiba mais'))}</a></td></tr>`);
      } else if(block.type==='divider') rows.push(`<tr><td style="padding:14px 32px"><div style="border-top:1px solid ${safeColor(d.color,'#e5e7eb')};font-size:1px;line-height:1px">&nbsp;</div></td></tr>`);
      else if(block.type==='spacer'){const h=clamp(d.height,24,4,120);rows.push(`<tr><td height="${h}" style="height:${h}px;font-size:1px;line-height:1px">&nbsp;</td></tr>`);}
    }
    const inner=rows.join('')||'<tr><td style="padding:36px 32px;text-align:center;color:#777;font-family:Arial,sans-serif">Adicione blocos ao seu e-mail.</td></tr>';
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;background:#f4f5f7"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;background:#f4f5f7"><tr><td align="center" style="padding:28px 12px"><table role="presentation" width="600" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:600px;background:#fff;border-radius:10px;overflow:hidden">${inner}</table></td></tr></table></body></html>`;
  }
  function plain(blocks){return blocks.map(b=>{const d=b.data||{};if(['heading','text'].includes(b.type))return d.text||'';if(b.type==='button')return `${d.text||''}${d.url?`: ${d.url}`:''}`;if(b.type==='image')return d.alt||'';return '';}).filter(Boolean).join('\n\n');}

  function inspector(editor){
    const block=editor.state.blocks.find(b=>b.id===editor.state.selected);
    if(!block)return '<div class="mail-inspector-empty">Selecione um bloco para editar.</div>';
    const d=block.data||{}; const field=(label,name,value,type='text',extra='')=>`<label>${label}<input data-prop="${name}" type="${type}" value="${esc(value??'')}" ${extra}></label>`;
    let html=`<div class="mail-inspector-head"><strong>${labels[block.type]}</strong><span>Configurações</span></div>`;
    if(block.type==='heading') html+=`<label>Texto<textarea data-prop="text" rows="4">${esc(d.text||'')}</textarea></label><div class="mail-inspector-grid"><label>Nível<select data-prop="level"><option value="h1" ${d.level==='h1'?'selected':''}>H1</option><option value="h2" ${d.level==='h2'?'selected':''}>H2</option><option value="h3" ${d.level==='h3'?'selected':''}>H3</option></select></label>${field('Tamanho','font_size',d.font_size,'number','min="14" max="52"')}</div>${alignField(d.align)}${field('Cor','color',d.color,'color')}`;
    if(block.type==='text') html+=`<label>Texto<textarea data-prop="text" rows="7">${esc(d.text||'')}</textarea></label><div class="mail-inspector-grid">${field('Tamanho','font_size',d.font_size,'number','min="11" max="28"')}${field('Cor','color',d.color,'color')}</div>${alignField(d.align)}`;
    if(block.type==='image') html+=`${field('URL da imagem','url',d.url,'url')}${field('Texto alternativo','alt',d.alt)}${field('Link ao clicar','link',d.link,'url')}${field('Largura (%)','width',d.width,'number','min="10" max="100"')}`;
    if(block.type==='button') html+=`${field('Texto do botão','text',d.text)}${field('Link','url',d.url,'url')}${alignField(d.align)}<div class="mail-inspector-grid">${field('Fundo','bg_color',d.bg_color,'color')}${field('Texto','text_color',d.text_color,'color')}</div>${field('Raio','radius',d.radius,'number','min="0" max="30"')}`;
    if(block.type==='divider') html+=field('Cor','color',d.color,'color');
    if(block.type==='spacer') html+=field('Altura (px)','height',d.height,'number','min="4" max="120"');
    if(['heading','text','button'].includes(block.type)) html+=`<div class="mail-var-panel"><span>Inserir variável</span><div>${variables(editor.customFields).map(([token,label])=>`<button type="button" class="mail-var-btn" data-token="${esc(token)}">${esc(label)}</button>`).join('')}</div><small>Fallback opcional: <code>{{nome|Olá}}</code></small></div>`;
    return html;
  }
  function alignField(v){return `<label>Alinhamento<select data-prop="align"><option value="left" ${v==='left'?'selected':''}>Esquerda</option><option value="center" ${v==='center'?'selected':''}>Centro</option><option value="right" ${v==='right'?'selected':''}>Direita</option></select></label>`;}

  function card(block,selected){const d=block.data||{};let snippet='';if(['heading','text','button'].includes(block.type))snippet=d.text||'';else if(block.type==='image')snippet=d.url||'Sem imagem';else if(block.type==='spacer')snippet=`${d.height||24}px`;else snippet='Linha horizontal';return `<div class="mail-block-card ${selected?'selected':''}" data-block-id="${block.id}"><div class="mail-block-main"><span class="mail-block-icon">${icons[block.type]}</span><div><strong>${labels[block.type]}</strong><small>${esc(snippet).slice(0,90)}</small></div></div><div class="mail-block-actions"><button type="button" data-action="up" title="Subir">↑</button><button type="button" data-action="down" title="Descer">↓</button><button type="button" data-action="duplicate" title="Duplicar">⧉</button><button type="button" data-action="delete" title="Excluir">×</button></div></div>`;}

  function buildShell(editor){
    return `<div class="mail-editor" data-mail-editor="${editor.id}"><div class="mail-editor-top"><div class="mail-mode-tabs"><button type="button" data-mode="visual" class="${editor.state.mode==='visual'?'active':''}">Editor visual</button><button type="button" data-mode="html" class="${editor.state.mode==='html'?'active':''}">HTML</button></div><div class="mail-device-tabs"><span>Prévia</span><button type="button" data-device="desktop" class="${editor.state.device==='desktop'?'active':''}">Desktop</button><button type="button" data-device="mobile" class="${editor.state.device==='mobile'?'active':''}">Mobile</button></div></div><div class="mail-editor-layout"><div class="mail-builder"><div class="mail-visual-mode ${editor.state.mode==='visual'?'':'hidden'}"><div class="mail-block-toolbar">${Object.keys(defaults).map(type=>`<button type="button" data-add-block="${type}"><span>${icons[type]}</span>${labels[type]}</button>`).join('')}</div><div class="mail-block-list">${editor.state.blocks.map(b=>card(b,b.id===editor.state.selected)).join('')||'<div class="mail-empty-blocks">Comece adicionando um bloco.</div>'}</div><div class="mail-inspector">${inspector(editor)}</div></div><div class="mail-html-mode ${editor.state.mode==='html'?'':'hidden'}"><label>HTML do e-mail<textarea class="mail-html-source" spellcheck="false" placeholder="Cole ou escreva seu HTML aqui...">${esc(editor.state.html)}</textarea></label><div class="mail-html-help">O HTML é salvo integralmente. Scripts não são executados na prévia porque o iframe é isolado.</div></div></div><div class="mail-preview-pane"><div class="mail-preview-meta"><strong class="mail-preview-subject">Assunto do e-mail</strong><span class="mail-preview-preheader">Preheader</span></div><div class="mail-preview-stage"><iframe sandbox="" title="Prévia do e-mail" class="mail-preview-frame ${editor.state.device==='mobile'?'mobile':''}"></iframe></div></div></div></div>`;
  }

  function mount(container,initial={},opts={}){
    const editor={id:`mail_editor_${++seq}`,container,state:normalize(initial),customFields:opts.customFields||[],metadata:opts.metadata||(()=>({subject:'Assunto do e-mail',preheader:'Preheader'})),onChange:opts.onChange||(()=>{}),lastInput:null};
    registry.set(editor.id,editor); render(editor); return {
      getValue:()=>serialize(editor),
      setMetadata:()=>refreshPreview(editor),
      destroy:()=>registry.delete(editor.id)
    };
  }
  function serialize(editor){const htmlBody=editor.state.mode==='visual'?renderBlocks(editor.state.blocks):editor.state.html;return {editor_mode:editor.state.mode,design_json:clone(editor.state.blocks),html_body:htmlBody,body:editor.state.mode==='visual'?plain(editor.state.blocks):''};}
  function render(editor){editor.container.innerHTML=buildShell(editor);bind(editor);refreshPreview(editor);}
  function refreshPreview(editor){
    const root=editor.container.querySelector('.mail-editor'); if(!root)return;
    const meta=editor.metadata()||{};root.querySelector('.mail-preview-subject').textContent=substitute(meta.subject||'Assunto do e-mail');root.querySelector('.mail-preview-preheader').textContent=substitute(meta.preheader||'Preheader');
    const html=editor.state.mode==='visual'?renderBlocks(editor.state.blocks):(editor.state.html||'<!doctype html><html><body style="font-family:Arial;padding:30px;color:#777">Cole seu HTML para visualizar.</body></html>');
    root.querySelector('.mail-preview-frame').srcdoc=substitute(html);
    editor.onChange(serialize(editor));
  }
  function bind(editor){
    const root=editor.container.querySelector('.mail-editor');
    root.querySelectorAll('[data-mode]').forEach(btn=>btn.onclick=()=>{const next=btn.dataset.mode;if(next===editor.state.mode)return;if(next==='html'&&!editor.state.html)editor.state.html=renderBlocks(editor.state.blocks);editor.state.mode=next;render(editor);});
    root.querySelectorAll('[data-device]').forEach(btn=>btn.onclick=()=>{editor.state.device=btn.dataset.device;root.querySelectorAll('[data-device]').forEach(x=>x.classList.toggle('active',x===btn));root.querySelector('.mail-preview-frame').classList.toggle('mobile',editor.state.device==='mobile');});
    root.querySelectorAll('[data-add-block]').forEach(btn=>btn.onclick=()=>{const type=btn.dataset.addBlock,b={id:uid(),type,data:clone(defaults[type])};editor.state.blocks.push(b);editor.state.selected=b.id;render(editor);});
    root.querySelectorAll('.mail-block-card').forEach(cardEl=>{
      cardEl.onclick=e=>{if(e.target.closest('[data-action]'))return;editor.state.selected=cardEl.dataset.blockId;render(editor);};
      cardEl.querySelectorAll('[data-action]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();const id=cardEl.dataset.blockId,idx=editor.state.blocks.findIndex(b=>b.id===id),action=btn.dataset.action;if(idx<0)return;if(action==='up'&&idx>0)[editor.state.blocks[idx-1],editor.state.blocks[idx]]=[editor.state.blocks[idx],editor.state.blocks[idx-1]];if(action==='down'&&idx<editor.state.blocks.length-1)[editor.state.blocks[idx+1],editor.state.blocks[idx]]=[editor.state.blocks[idx],editor.state.blocks[idx+1]];if(action==='duplicate'){const copy=clone(editor.state.blocks[idx]);copy.id=uid();editor.state.blocks.splice(idx+1,0,copy);editor.state.selected=copy.id;}if(action==='delete'){editor.state.blocks.splice(idx,1);editor.state.selected=editor.state.blocks[Math.min(idx,editor.state.blocks.length-1)]?.id||null;}render(editor);});
    });
    root.querySelectorAll('[data-prop]').forEach(input=>{input.onfocus=()=>editor.lastInput=input;input.oninput=()=>{const block=editor.state.blocks.find(b=>b.id===editor.state.selected);if(!block)return;let v=input.value;if(input.type==='number')v=Number(v);block.data[input.dataset.prop]=v;refreshPreview(editor);const cardEl=root.querySelector(`[data-block-id="${block.id}"] small`);if(cardEl&&['text','url','height'].includes(input.dataset.prop))cardEl.textContent=String(v).slice(0,90);};});
    root.querySelectorAll('.mail-var-btn').forEach(btn=>btn.onclick=()=>{const input=editor.lastInput||root.querySelector('[data-prop="text"]');if(!input)return;const token=btn.dataset.token,start=input.selectionStart??input.value.length,end=input.selectionEnd??input.value.length;input.value=input.value.slice(0,start)+token+input.value.slice(end);input.focus();input.selectionStart=input.selectionEnd=start+token.length;input.dispatchEvent(new Event('input',{bubbles:true}));});
    const source=root.querySelector('.mail-html-source');if(source){source.oninput=()=>{editor.state.html=source.value;refreshPreview(editor);};}
  }
  window.MailFlowEmailEditor={mount,renderBlocks};
})();
