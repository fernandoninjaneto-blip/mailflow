const API = window.MAILFLOW_API_BASE || '/api';

const state = {
  user: null,
  workspace: null,
  users: [],
  contacts: [],
  contactStats: { total: 0, active: 0, unsubscribed: 0, bounce: 0, blocked: 0, invalid: 0, tagged: 0 },
  contactTags: [],
  contactSources: [],
  customFields: [],
  contactPage: { total: 0, page: 1, page_size: 25, pages: 1 },
  contactFilters: { q: '', status: '', tag: '', source: '', custom_key: '', custom_value: '', created_from: '', created_to: '' },
  selectedContacts: new Set(),
  lists: [],
  segments: [],
  campaigns: [],
  templates: [],
  automations: [],
  events: [],
  settings: { sender_name: 'Sua Marca', sender_email: '', reply_to: '' },
  deliveryProvider: { provider: 'console', configured: true, live: false, mode: 'development', webhook_configured: false, queue: 'database' },
  sendingDomains: [],
  senderIdentities: [],
  deliverability: {provider:'console',provider_configured:true,domains:0,ready_domains:0,sender_identities:0,ready_sender_identities:0,default_sender_id:null,live_send_ready:false,bulk_marketing_ready:false,blockers:[],warnings:[]},
  dashboard: null,
  analytics: null,
  analyticsDays: 30,
  suppressions: [],
  consents: [],
};
let currentCampaignFilter = 'all';

function fmt(n) { return new Intl.NumberFormat('pt-BR').format(n || 0); }
function pct(a, b) { return b ? ((a / b) * 100).toFixed(1).replace('.', ',') + '%' : '0%'; }
function escapeHtml(v='') { return String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c])); }
function empty(title, text) { return `<div class="empty"><strong>${escapeHtml(title)}</strong>${escapeHtml(text)}</div>`; }
function statusLabel(status) { return ({draft:'Rascunho',scheduled:'Agendada',sending:'Enviando',sent:'Enviada',paused:'Pausada',cancelled:'Cancelada'})[status] || status; }
function contactStatus(status) { return ({active:'Ativo',unsubscribed:'Descadastrado',bounce:'Bounce',blocked:'Bloqueado',invalid:'Inválido'})[status] || status; }
function metricBar(label, value) { return `<div class="metric-bar-row"><div class="metric-line"><span>${label}</span><strong>${value.toFixed(1).replace('.',',')}%</strong></div><div class="bar"><span style="width:${Math.min(value,100)}%"></span></div></div>`; }
function formatDate(v) { if (!v) return '—'; const d = new Date(v); return isNaN(d) ? v : d.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }); }
function showToast(msg) { const t = document.getElementById('toast'); t.textContent = msg; t.classList.remove('hidden'); setTimeout(() => t.classList.add('hidden'), 2600); }

function csrfTokenFromCookie() {
  const parts = document.cookie.split(';').map(x => x.trim()).filter(Boolean);
  for (const item of parts) {
    const idx = item.indexOf('=');
    const name = decodeURIComponent(idx >= 0 ? item.slice(0, idx) : item);
    const value = decodeURIComponent(idx >= 0 ? item.slice(idx + 1) : '');
    if (name === 'mailflow_csrf' || name === '__Host-mailflow_csrf' || name.endsWith('mailflow_csrf')) return value;
  }
  return '';
}

async function request(path, options={}) {
  const isForm = options.body instanceof FormData;
  const headers = isForm ? { ...(options.headers || {}) } : { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const method = String(options.method || 'GET').toUpperCase();
  if (!['GET','HEAD','OPTIONS','TRACE'].includes(method)) {
    const csrf = csrfTokenFromCookie();
    if (csrf) headers['X-CSRF-Token'] = csrf;
  }
  const config = { credentials: 'include', ...options, headers };
  const res = await fetch(`${API}${path}`, config);
  if (!res.ok) {
    let detail = 'Erro ao comunicar com o servidor.';
    try {
      const payload = await res.json();
      if (Array.isArray(payload.detail)) detail = payload.detail.map(x=>x.msg || String(x)).join(' ');
      else detail = payload.detail || detail;
    } catch {}
    throw new Error(detail);
  }
  if (res.status === 204) return null;
  return res.json();
}

const pageMeta = {
  dashboard: ['Dashboard','Visão geral da sua operação de e-mail marketing.'],
  contacts: ['Contatos','Organize, segmente e gerencie sua base.'],
  segments: ['Listas e Segmentos','Crie públicos fixos e audiências dinâmicas reutilizáveis.'],
  campaigns: ['Campanhas','Crie, agende e acompanhe seus envios.'],
  templates: ['Templates','Modelos reutilizáveis para acelerar sua operação.'],
  automations: ['Automações','Construa réguas de relacionamento e vendas.'],
  events: ['Eventos e Lançamentos','Organize cronograma, público, oferta e comunicações vinculadas.'],
  reports: ['Relatórios','Compare períodos, campanhas, automações, eventos e saúde da operação.'],
  settings: ['Configurações','Identidade, integrações e conformidade.']
};

function navigate(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(`page-${page}`).classList.add('active');
  document.querySelector(`[data-page="${page}"]`)?.classList.add('active');
  document.getElementById('pageTitle').textContent = pageMeta[page][0];
  document.getElementById('pageSubtitle').textContent = pageMeta[page][1];
}

document.getElementById('nav').addEventListener('click', e => {
  const btn = e.target.closest('[data-page]'); if (btn) navigate(btn.dataset.page);
});
document.addEventListener('click', e => {
  const go = e.target.closest('[data-go]'); if (go) navigate(go.dataset.go);
});

async function loadAll() {
  try {
    const me = await request('/auth/me');
    state.user = me.user;
    state.workspace = me.workspace;
    showApp();
    await refreshData();
  } catch (err) {
    showAuth('login');
  }
}

function showAuth(view='login') {
  document.getElementById('appShell').classList.add('hidden');
  document.getElementById('authShell').classList.remove('hidden');
  const map={login:'authLogin',register:'authRegister',forgot:'authForgot',reset:'authReset'};
  document.querySelectorAll('.auth-view').forEach(x=>x.classList.add('hidden'));
  document.getElementById(map[view]||map.login).classList.remove('hidden');
}

function showApp() {
  document.getElementById('authShell').classList.add('hidden');
  document.getElementById('appShell').classList.remove('hidden');
  renderAccountHeader();
}

function renderAccountHeader() {
  const user=state.user||{}; const workspace=state.workspace||{};
  document.getElementById('currentUserName').textContent=user.name||'Usuário';
  document.getElementById('currentWorkspaceName').textContent=workspace.name||'Workspace';
  document.getElementById('userAvatar').textContent=(user.name||user.email||'U').trim().charAt(0).toUpperCase();
}

document.addEventListener('click', e=>{
  const b=e.target.closest('[data-auth-view]');
  if(b){ showAuth(b.dataset.authView); }
});

document.getElementById('loginForm').addEventListener('submit', async e=>{
  e.preventDefault(); const f=new FormData(e.target);
  try {
    const me=await request('/auth/login',{method:'POST',body:JSON.stringify({email:f.get('email').trim(),password:f.get('password')})});
    state.user=me.user; state.workspace=me.workspace; e.target.reset(); showApp(); await refreshData(); showToast('Login realizado com sucesso.');
  } catch(err){ showToast(err.message); }
});

document.getElementById('registerForm').addEventListener('submit', async e=>{
  e.preventDefault(); const f=new FormData(e.target);
  try {
    const me=await request('/auth/register',{method:'POST',body:JSON.stringify({workspace_name:f.get('workspace_name').trim(),name:f.get('name').trim(),email:f.get('email').trim(),password:f.get('password')})});
    state.user=me.user; state.workspace=me.workspace; e.target.reset(); showApp(); await refreshData(); showToast('Conta criada. Você é o administrador deste workspace.');
  } catch(err){ showToast(err.message); }
});

document.getElementById('forgotForm').addEventListener('submit', async e=>{
  e.preventDefault(); const f=new FormData(e.target);
  try {
    const result=await request('/auth/forgot-password',{method:'POST',body:JSON.stringify({email:f.get('email').trim()})});
    showToast(result.message);
    const box=document.getElementById('devResetBox');
    if(result.reset_token){
      box.classList.remove('hidden');
      box.innerHTML=`<strong>Modo de desenvolvimento:</strong><br>Token de recuperação: <code>${escapeHtml(result.reset_token)}</code><br><button class="link-btn" id="useResetTokenBtn" type="button">Usar este token</button>`;
      document.getElementById('useResetTokenBtn').onclick=()=>{ document.querySelector('#resetForm [name="token"]').value=result.reset_token; showAuth('reset'); };
    } else {
      box.classList.add('hidden'); box.innerHTML='';
    }
  } catch(err){ showToast(err.message); }
});

document.getElementById('resetForm').addEventListener('submit', async e=>{
  e.preventDefault(); const f=new FormData(e.target);
  try {
    const result=await request('/auth/reset-password',{method:'POST',body:JSON.stringify({token:f.get('token').trim(),new_password:f.get('new_password')})});
    e.target.reset(); history.replaceState({},'',window.location.pathname); showAuth('login'); showToast(result.message);
  } catch(err){ showToast(err.message); }
});

document.getElementById('logoutBtn').addEventListener('click', async ()=>{
  try { await request('/auth/logout',{method:'POST'}); } catch {}
  state.user=null; state.workspace=null; state.users=[]; state.contacts=[]; state.contactTags=[]; state.contactSources=[]; state.customFields=[]; state.selectedContacts=new Set(); state.lists=[]; state.segments=[]; state.campaigns=[]; state.templates=[]; state.automations=[]; state.dashboard=null; state.analytics=null; state.analyticsDays=30; state.deliveryProvider={provider:'console',configured:true,live:false,mode:'development',webhook_configured:false,queue:'database'}; state.sendingDomains=[]; state.senderIdentities=[]; state.deliverability={provider:'console',provider_configured:true,domains:0,ready_domains:0,sender_identities:0,ready_sender_identities:0,default_sender_id:null,live_send_ready:false,bulk_marketing_ready:false,blockers:[],warnings:[]}; state.suppressions=[]; state.consents=[];
  navigate('dashboard'); showAuth('login'); showToast('Sessão encerrada.');
});

function renderAll() {
  renderDashboard(); renderContacts(); renderSegments(); renderCampaigns(); renderTemplates(); renderAutomations(); renderEvents(); renderReports(); renderSettings();
  document.getElementById('sidebarContacts').textContent = `${fmt(state.contactStats.total || state.dashboard?.contacts_total || 0)} contatos`;
  document.getElementById('sidebarCampaigns').textContent = `${state.campaigns.length} campanhas`;
}

function totals() {
  return state.campaigns.filter(c=>c.status==='sent').reduce((a,c)=>({sent:a.sent+c.sent,delivered:a.delivered+c.delivered,opens:a.opens+c.opens,clicks:a.clicks+c.clicks,unsub:a.unsub+c.unsub}),{sent:0,delivered:0,opens:0,clicks:0,unsub:0});
}

function trendText(value, label='vs. período anterior') {
  if(value===null || value===undefined) return `<span class="trend neutral">Sem base anterior</span>`;
  const n=Number(value)||0;
  const cls=n>0?'up':n<0?'down':'neutral';
  const arrow=n>0?'↑':n<0?'↓':'→';
  return `<span class="trend ${cls}">${arrow} ${Math.abs(n).toFixed(1).replace('.',',')}% ${escapeHtml(label)}</span>`;
}
function compactRate(v){return `${Number(v||0).toFixed(1).replace('.',',')}%`;}
function analyticsLineChart(rows, keys=['sent','delivered','opens','clicks']) {
  if(!rows?.length) return empty('Sem dados','Ainda não há atividade para o período selecionado.');
  const width=760,height=210,pad=30;
  const max=Math.max(1,...rows.flatMap(r=>keys.map(k=>Number(r[k]||0))));
  const step=rows.length>1?(width-pad*2)/(rows.length-1):0;
  const labels={sent:'Enviados',delivered:'Entregues',opens:'Aberturas',clicks:'Cliques',new_contacts:'Novos contatos'};
  const css={sent:'series-a',delivered:'series-b',opens:'series-c',clicks:'series-d',new_contacts:'series-e'};
  const lines=keys.map(k=>{
    const pts=rows.map((r,i)=>`${pad+i*step},${height-pad-(Number(r[k]||0)/max)*(height-pad*2)}`).join(' ');
    return `<polyline class="chart-line ${css[k]||''}" points="${pts}" fill="none" />`;
  }).join('');
  const tickEvery=Math.max(1,Math.ceil(rows.length/6));
  const ticks=rows.map((r,i)=>i%tickEvery===0?`<span style="left:${rows.length>1?(i/(rows.length-1))*100:0}%">${escapeHtml(String(r.date||'').slice(5))}</span>`:'').join('');
  return `<div class="chart-legend">${keys.map(k=>`<span><i class="legend-dot ${css[k]||''}"></i>${labels[k]||k}</span>`).join('')}</div><div class="svg-chart"><svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none"><line class="chart-grid" x1="${pad}" y1="${height-pad}" x2="${width-pad}" y2="${height-pad}"/>${lines}</svg><div class="chart-axis-labels">${ticks}</div></div>`;
}
function renderAlerts(targetId, alerts=[]) {
  const box=document.getElementById(targetId); if(!box)return;
  if(!alerts.length){box.innerHTML=`<div class="health-ok"><strong>✓ Nenhum alerta operacional</strong><span>Os indicadores monitorados estão dentro dos limites internos do painel.</span></div>`;return;}
  box.innerHTML=alerts.map(a=>`<div class="ops-alert ${escapeHtml(a.severity)}"><div class="ops-alert-icon">${a.severity==='critical'?'!':a.severity==='warning'?'△':'i'}</div><div><strong>${escapeHtml(a.title)}</strong><p>${escapeHtml(a.message)}</p></div></div>`).join('');
}

function renderDashboard() {
  const legacy = state.dashboard || {contacts_active:0,campaigns_total:0,sent:0,delivered:0,opens:0,clicks:0};
  const a=state.analytics; const t=a?.summary||legacy; const ch=a?.changes||{};
  document.getElementById('statContacts').textContent = fmt(t.active_contacts ?? legacy.contacts_active);
  document.getElementById('statNewContacts').textContent = fmt(t.new_contacts||0);
  document.getElementById('statSent').textContent = fmt(t.sent||0);
  document.getElementById('statDeliveryRate').textContent = compactRate(t.delivery_rate ?? ((t.sent? t.delivered/t.sent*100:0)));
  document.getElementById('statOpenRate').textContent = compactRate(t.open_rate ?? ((t.delivered? t.opens/t.delivered*100:0)));
  document.getElementById('statClickRate').textContent = compactRate(t.click_rate ?? ((t.delivered? t.clicks/t.delivered*100:0)));
  document.getElementById('statContactsTrend').innerHTML=`Base atual • ${fmt(t.contacts_total||0)} contatos totais`;
  document.getElementById('statNewContactsTrend').innerHTML=trendText(ch.new_contacts);
  document.getElementById('statSentTrend').innerHTML=trendText(ch.sent);
  document.getElementById('statDeliveryTrend').innerHTML=trendText(ch.delivery_rate,'vs. taxa anterior');
  document.getElementById('statOpenTrend').innerHTML=trendText(ch.open_rate,'vs. taxa anterior');
  document.getElementById('statClickTrend').innerHTML=trendText(ch.click_rate,'vs. taxa anterior');
  const recent = state.campaigns.slice(0,5);
  document.getElementById('recentCampaigns').innerHTML = recent.length ? `<table><thead><tr><th>Campanha</th><th>Status</th><th>Abertura</th><th>Cliques</th></tr></thead><tbody>${recent.map(c=>`<tr><td><span class="table-title">${escapeHtml(c.name)}</span><span class="table-sub">${escapeHtml(c.subject)}</span></td><td><span class="badge ${c.status}">${statusLabel(c.status)}</span></td><td>${pct(c.opens,c.delivered)}</td><td>${pct(c.clicks,c.delivered)}</td></tr>`).join('')}</tbody></table>` : empty('Nenhuma campanha ainda','Crie sua primeira campanha para começar.');
  const deliveryRate = Number(t.delivery_rate ?? (t.sent ? t.delivered/t.sent*100 : 0));
  const openRate = Number(t.open_rate ?? (t.delivered ? t.opens/t.delivered*100 : 0));
  const clickRate = Number(t.click_rate ?? (t.delivered ? t.clicks/t.delivered*100 : 0));
  document.getElementById('performanceBars').innerHTML = metricBar('Entregabilidade',deliveryRate)+metricBar('Abertura',openRate)+metricBar('Cliques',clickRate);
  document.getElementById('dashboardTrendChart').innerHTML=analyticsLineChart(a?.daily||[],['sent','delivered','opens','clicks']);
  renderAlerts('dashboardAlerts',a?.alerts||[]);
  const sel=document.getElementById('dashboardPeriod'); if(sel)sel.value=String(state.analyticsDays||30);
}

function renderContactFilterOptions() {
  const tagSelect=document.getElementById('contactTagFilter');
  const sourceSelect=document.getElementById('contactSourceFilter');
  const customSelect=document.getElementById('contactCustomFieldFilter');
  const currentTag=state.contactFilters.tag;
  const currentSource=state.contactFilters.source;
  const currentCustom=state.contactFilters.custom_key;
  tagSelect.innerHTML=`<option value="">Todas as tags</option>${state.contactTags.map(t=>`<option value="${escapeHtml(t.name)}" ${t.name===currentTag?'selected':''}>${escapeHtml(t.name)} (${fmt(t.count)})</option>`).join('')}`;
  sourceSelect.innerHTML=`<option value="">Todas as origens</option>${state.contactSources.map(v=>`<option value="${escapeHtml(v)}" ${v===currentSource?'selected':''}>${escapeHtml(v)}</option>`).join('')}`;
  customSelect.innerHTML=`<option value="">Nenhum</option>${state.customFields.map(f=>`<option value="${escapeHtml(f.key)}" ${f.key===currentCustom?'selected':''}>${escapeHtml(f.label)}</option>`).join('')}`;
  document.getElementById('contactStatusFilter').value=state.contactFilters.status;
  document.getElementById('contactCustomValueFilter').disabled=!state.contactFilters.custom_key;
  document.getElementById('contactCustomValueFilter').value=state.contactFilters.custom_value;
  document.getElementById('contactCreatedFromFilter').value=state.contactFilters.created_from;
  document.getElementById('contactCreatedToFilter').value=state.contactFilters.created_to;
}

function renderBulkBar(){
  const count=state.selectedContacts.size;
  document.getElementById('selectedContactsCount').textContent=fmt(count);
  document.getElementById('contactBulkBar').classList.toggle('hidden',!count);
}

function renderContacts() {
  const stats=state.contactStats;
  document.getElementById('contactsTotal').textContent=fmt(stats.total);
  document.getElementById('contactsActive').textContent=fmt(stats.active);
  document.getElementById('contactsUnsub').textContent=fmt(stats.unsubscribed);
  document.getElementById('contactsTagged').textContent=fmt(stats.tagged);
  renderContactFilterOptions();

  const list=state.contacts;
  const pageIds=list.map(c=>c.id);
  const allPageSelected=pageIds.length>0 && pageIds.every(id=>state.selectedContacts.has(id));
  document.getElementById('contactsTable').innerHTML=list.length?`<table><thead><tr><th class="check-col"><input type="checkbox" id="selectPageContacts" ${allPageSelected?'checked':''} aria-label="Selecionar página"></th><th>Contato</th><th>Tags</th><th>Origem</th><th>Status</th><th>Cadastro</th><th></th></tr></thead><tbody>${list.map(c=>`<tr><td class="check-col"><input type="checkbox" class="contact-check" data-id="${c.id}" ${state.selectedContacts.has(c.id)?'checked':''} aria-label="Selecionar contato"></td><td><button class="contact-link" onclick="viewContact('${c.id}')"><span class="table-title">${escapeHtml(([c.name,c.last_name].filter(Boolean).join(' '))||'Sem nome')}</span><span class="table-sub">${escapeHtml(c.email)}${c.phone?` • ${escapeHtml(c.phone)}`:''}</span></button></td><td>${(c.tags||[]).slice(0,3).map(t=>`<span class="badge neutral">${escapeHtml(t)}</span>`).join(' ')||'—'}${(c.tags||[]).length>3?` <span class="small">+${(c.tags||[]).length-3}</span>`:''}</td><td>${escapeHtml(c.source||'—')}</td><td><span class="badge ${c.status}">${contactStatus(c.status)}</span></td><td>${formatDate(c.created_at)}</td><td><button class="action-btn" onclick="editContact('${c.id}')">Editar</button><button class="action-btn" onclick="deleteContact('${c.id}')">Excluir</button></td></tr>`).join('')}</tbody></table>`:empty('Nenhum contato encontrado','Ajuste os filtros ou importe sua base.');

  document.getElementById('contactsPageInfo').textContent=`${fmt(state.contactPage.total)} contatos • página ${state.contactPage.page} de ${state.contactPage.pages}`;
  document.getElementById('contactsPrevBtn').disabled=state.contactPage.page<=1;
  document.getElementById('contactsNextBtn').disabled=state.contactPage.page>=state.contactPage.pages;
  renderBulkBar();

  document.getElementById('selectPageContacts')?.addEventListener('change',e=>{
    pageIds.forEach(id=>e.target.checked?state.selectedContacts.add(id):state.selectedContacts.delete(id));
    renderContacts();
  });
  document.querySelectorAll('.contact-check').forEach(el=>el.addEventListener('change',e=>{
    const id=e.target.dataset.id;
    e.target.checked?state.selectedContacts.add(id):state.selectedContacts.delete(id);
    renderBulkBar();
    const header=document.getElementById('selectPageContacts');
    if(header) header.checked=pageIds.length>0 && pageIds.every(x=>state.selectedContacts.has(x));
  }));
}

function appendContactFilters(p){
  Object.entries(state.contactFilters).forEach(([k,v])=>{
    if(!v)return;
    if(k==='created_from') p.set(k,`${v}T00:00:00Z`);
    else if(k==='created_to') p.set(k,`${v}T23:59:59Z`);
    else p.set(k,v);
  });
  return p;
}
function contactQueryString(){
  const p=new URLSearchParams({page:String(state.contactPage.page),page_size:String(state.contactPage.page_size)});
  return appendContactFilters(p).toString();
}

async function refreshContacts({meta=true}={}){
  const calls=[request(`/contacts/search?${contactQueryString()}`)];
  if(meta) calls.push(request('/contacts/stats'),request('/contacts/tags'),request('/contacts/sources'),request('/contacts/custom-fields'));
  const results=await Promise.all(calls);
  const page=results[0];
  state.contacts=page.items;
  state.contactPage={total:page.total,page:page.page,page_size:page.page_size,pages:page.pages};
  if(meta){[state.contactStats,state.contactTags,state.contactSources,state.customFields]=results.slice(1);}
  renderContacts();
  document.getElementById('sidebarContacts').textContent=`${fmt(state.contactStats.total)} contatos`;
}

let contactSearchTimer;
document.getElementById('contactSearch').addEventListener('input',e=>{
  clearTimeout(contactSearchTimer);
  contactSearchTimer=setTimeout(async()=>{state.contactFilters.q=e.target.value.trim();state.contactPage.page=1;await refreshContacts({meta:false});},300);
});
['contactStatusFilter','contactTagFilter','contactSourceFilter'].forEach(id=>document.getElementById(id).addEventListener('change',async e=>{
  const map={contactStatusFilter:'status',contactTagFilter:'tag',contactSourceFilter:'source'};
  state.contactFilters[map[id]]=e.target.value;state.contactPage.page=1;await refreshContacts({meta:false});
}));
document.getElementById('contactCustomFieldFilter').addEventListener('change',async e=>{
  state.contactFilters.custom_key=e.target.value;
  if(!e.target.value) state.contactFilters.custom_value='';
  state.contactPage.page=1;renderContactFilterOptions();await refreshContacts({meta:false});
});
document.getElementById('contactCustomValueFilter').addEventListener('input',e=>{
  clearTimeout(contactSearchTimer);
  contactSearchTimer=setTimeout(async()=>{state.contactFilters.custom_value=e.target.value.trim();state.contactPage.page=1;await refreshContacts({meta:false});},300);
});
['contactCreatedFromFilter','contactCreatedToFilter'].forEach(id=>document.getElementById(id).addEventListener('change',async e=>{
  state.contactFilters[id==='contactCreatedFromFilter'?'created_from':'created_to']=e.target.value;state.contactPage.page=1;await refreshContacts({meta:false});
}));
document.getElementById('clearContactFiltersBtn').onclick=async()=>{
  state.contactFilters={q:'',status:'',tag:'',source:'',custom_key:'',custom_value:'',created_from:'',created_to:''};state.contactPage.page=1;document.getElementById('contactSearch').value='';await refreshContacts({meta:false});
};
document.getElementById('contactsPrevBtn').onclick=async()=>{if(state.contactPage.page>1){state.contactPage.page--;await refreshContacts({meta:false});}};
document.getElementById('contactsNextBtn').onclick=async()=>{if(state.contactPage.page<state.contactPage.pages){state.contactPage.page++;await refreshContacts({meta:false});}};

function campaignStatusText(c){
  if(c.status==='scheduled' && c.send_armed) return 'Agendada • ativa';
  if(c.status==='scheduled' && !c.send_armed) return 'Agendada • não ativada';
  return statusLabel(c.status);
}

function campaignActions(c){
  const common=`<button class="action-btn" onclick="previewCampaign('${c.id}')">Prévia</button><button class="action-btn" onclick="sendTest('${c.id}')">Teste</button>`;
  if(c.status==='sending') return `${common}<button class="action-btn" onclick="viewDeliveries('${c.id}')">Acompanhar</button><button class="action-btn" onclick="viewCampaignReport('${c.id}')">Relatório</button><button class="action-btn" onclick="pauseCampaign('${c.id}')">Pausar</button><button class="action-btn danger-text" onclick="cancelCampaign('${c.id}')">Cancelar</button>`;
  if(c.status==='paused') return `${common}<button class="action-btn" onclick="viewDeliveries('${c.id}')">Acompanhar</button><button class="action-btn" onclick="viewCampaignReport('${c.id}')">Relatório</button><button class="action-btn" onclick="resumeCampaign('${c.id}')">Retomar</button><button class="action-btn danger-text" onclick="cancelCampaign('${c.id}')">Cancelar</button>`;
  if(c.status==='sent' || c.status==='cancelled') return `${common}<button class="action-btn" onclick="viewDeliveries('${c.id}')">Entregas</button><button class="action-btn primary-action" onclick="viewCampaignReport('${c.id}')">Relatório</button>`;
  if(c.status==='scheduled' && c.send_armed) return `${common}<button class="action-btn" onclick="reviewCampaign('${c.id}')">Revisão</button><button class="action-btn" onclick="pauseCampaign('${c.id}')">Pausar</button><button class="action-btn danger-text" onclick="cancelCampaign('${c.id}')">Cancelar</button>`;
  return `<button class="action-btn" onclick="editCampaign('${c.id}')">Editar</button>${common}<button class="action-btn primary-action" onclick="reviewCampaign('${c.id}')">${c.status==='scheduled'?'Revisar e agendar':'Revisar e enviar'}</button>`;
}

function renderCampaigns() {
  const list = state.campaigns.filter(c => currentCampaignFilter==='all' || c.status===currentCampaignFilter);
  document.getElementById('campaignsTable').innerHTML = list.length ? `<table><thead><tr><th>Campanha</th><th>Público</th><th>Status</th><th>Data</th><th>Enviados</th><th>Entrega</th><th>Falhas</th><th></th></tr></thead><tbody>${list.map(c=>`<tr><td><span class="table-title">${escapeHtml(c.name)}</span><span class="table-sub">${escapeHtml(c.subject)}</span></td><td>${escapeHtml(c.segment)}</td><td><span class="badge ${c.status}">${escapeHtml(campaignStatusText(c))}</span></td><td>${formatDate(c.scheduled_at || c.updated_at)}</td><td>${fmt(c.sent)}</td><td>${pct(c.delivered,c.sent)}</td><td>${fmt((c.failures||0)+(c.bounces||0)+(c.complaints||0))}</td><td>${campaignActions(c)}</td></tr>`).join('')}</tbody></table>` : empty('Nenhuma campanha encontrada','Crie uma campanha ou altere o filtro.');
}

document.getElementById('campaignFilters').addEventListener('click', e=>{
  const b=e.target.closest('[data-filter]'); if(!b)return;
  currentCampaignFilter=b.dataset.filter;
  document.querySelectorAll('.filter-tab').forEach(x=>x.classList.remove('active')); b.classList.add('active'); renderCampaigns();
});

function renderTemplates() {
  document.getElementById('templateGrid').innerHTML = state.templates.length ? state.templates.map(t=>`<article class="template-card"><div class="template-preview"><span>${escapeHtml(t.type)}</span></div><h3>${escapeHtml(t.name)}</h3><p class="muted">${escapeHtml(t.subject)}</p><div class="template-actions"><button class="btn btn-primary" onclick="useTemplate('${t.id}')">Usar</button><button class="btn btn-secondary" onclick="deleteTemplate('${t.id}')">Excluir</button></div></article>`).join('') : empty('Nenhum template','Crie seu primeiro modelo reutilizável.');
}

function automationTriggerText(a){
  const c=a.trigger_config||{};
  if(a.trigger_type==='contact_created') return 'Contato entra na base';
  if(a.trigger_type==='tag_added') return `Tag adicionada: ${c.tag||'—'}`;
  if(a.trigger_type==='list_joined') return `Entrou na lista: ${state.lists.find(x=>x.id===c.list_id)?.name||'Lista'}`;
  if(a.trigger_type==='email_clicked') return `Clique em campanha${c.campaign_id?`: ${state.campaigns.find(x=>x.id===c.campaign_id)?.name||'campanha'}`:''}`;
  if(a.trigger_type==='status_changed') return `Status alterado${c.to?` para ${contactStatus(c.to)}`:''}`;
  return 'Inscrição manual';
}
function automationStepText(step){
  if(step.type==='send_email') return `Enviar e-mail: ${state.templates.find(x=>x.id===step.template_id)?.name||'Template'}`;
  if(step.type==='wait') return `Aguardar ${step.amount||1} ${{minutes:'minuto(s)',hours:'hora(s)',days:'dia(s)'}[step.unit]||''}`;
  if(step.type==='condition') return `Verificar condição${step.on_false==='skip_next'?' e pular próxima etapa se falsa':' e encerrar se falsa'}`;
  if(step.type==='add_tag') return `Adicionar tag: ${step.tag||''}`;
  if(step.type==='remove_tag') return `Remover tag: ${step.tag||''}`;
  return step.type||'Etapa';
}
function renderAutomations() {
  document.getElementById('automationGrid').innerHTML = state.automations.length ? state.automations.map(a=>`<article class="automation-card"><div class="panel-head"><div><span class="badge ${a.active?'active':'neutral'}">${a.active?'Ativa':'Pausada'}</span><h3 style="margin-top:10px">${escapeHtml(a.name)}</h3><p>${escapeHtml(automationTriggerText(a))}</p></div></div><div class="automation-kpis"><span><strong>${fmt(a.running_count)}</strong> em andamento</span><span><strong>${fmt(a.completed_count)}</strong> concluídas</span><span><strong>${fmt(a.failed_count)}</strong> falhas</span></div><div class="flow">${(a.steps||[]).map((step,i)=>`${i+1}. ${escapeHtml(automationStepText(step))}`).join('<br>')}</div><div class="automation-actions"><button class="btn btn-primary" onclick="viewAutomationRuns('${a.id}')">Execuções</button><button class="btn btn-secondary" onclick="editAutomation('${a.id}')">Editar</button><button class="btn btn-secondary" onclick="toggleAutomation('${a.id}')">${a.active?'Pausar':'Ativar'}</button><button class="btn btn-secondary danger-text" onclick="deleteAutomation('${a.id}')">Excluir</button></div></article>`).join('') : empty('Nenhuma automação','Crie uma régua com gatilho, e-mails, esperas e condições.');
}

function renderReports() {
  const a=state.analytics;
  if(!a){
    ['reportSent','reportDeliveryRate','reportOpenRate','reportClickRate','reportBounceRate','reportComplaintRate'].forEach(id=>{const el=document.getElementById(id);if(el)el.textContent='0';});
    return;
  }
  const t=a.summary||{}, ch=a.changes||{};
  document.getElementById('reportSent').textContent=fmt(t.sent);
  document.getElementById('reportDeliveryRate').textContent=compactRate(t.delivery_rate);
  document.getElementById('reportOpenRate').textContent=compactRate(t.open_rate);
  document.getElementById('reportClickRate').textContent=compactRate(t.click_rate);
  document.getElementById('reportBounceRate').textContent=compactRate(t.bounce_rate);
  document.getElementById('reportComplaintRate').textContent=compactRate(t.complaint_rate);
  document.getElementById('reportSentTrend').innerHTML=trendText(ch.sent);
  document.getElementById('reportDeliveryTrend').innerHTML=trendText(ch.delivery_rate,'vs. taxa anterior');
  document.getElementById('reportOpenTrend').innerHTML=trendText(ch.open_rate,'vs. taxa anterior');
  document.getElementById('reportClickTrend').innerHTML=trendText(ch.click_rate,'vs. taxa anterior');
  document.getElementById('reportBounceCount').textContent=`${fmt(t.bounces)} ocorrência(s) • ${trendText(ch.bounce_rate,'vs. taxa anterior')}`;
  document.getElementById('reportComplaintCount').textContent=`${fmt(t.complaints)} ocorrência(s)`;
  document.getElementById('reportDailyChart').innerHTML=analyticsLineChart(a.daily||[],['sent','delivered','opens','clicks']);
  document.getElementById('contactGrowthChart').innerHTML=analyticsLineChart(a.daily||[],['new_contacts']);

  const comps=a.campaign_comparison||[];
  document.getElementById('campaignComparisonTable').innerHTML=comps.length?`<table><thead><tr><th>Campanha</th><th>Enviados</th><th>Entrega</th><th>Abertura</th><th>CTR</th><th>CTOR</th><th>Bounce</th><th>Spam</th><th></th></tr></thead><tbody>${comps.map(c=>`<tr><td><span class="table-title">${escapeHtml(c.name)}</span><span class="table-sub">${escapeHtml(c.subject)}</span></td><td>${fmt(c.sent)}</td><td>${compactRate(c.delivery_rate)}</td><td>${compactRate(c.open_rate)}</td><td>${compactRate(c.click_rate)}</td><td>${compactRate(c.ctor)}</td><td>${compactRate(c.bounce_rate)}</td><td>${compactRate(c.complaint_rate)}</td><td><button class="action-btn" onclick="viewCampaignReport('${c.id}')">Detalhes</button></td></tr>`).join('')}</tbody></table>`:empty('Sem campanhas no período','Campanhas com entregas no período aparecerão aqui.');

  const subjects=a.top_subjects||[];
  document.getElementById('topSubjects').innerHTML=subjects.length?`<div class="rank-list">${subjects.map((c,i)=>`<div class="rank-item"><span class="rank-pos">${i+1}</span><div class="rank-copy"><strong>${escapeHtml(c.subject||c.name)}</strong><small>${escapeHtml(c.name)} • ${fmt(c.delivered)} entregues</small></div><div class="rank-metric"><strong>${compactRate(c.open_rate)}</strong><small>abertura</small></div></div>`).join('')}</div>`:empty('Sem dados','Ainda não há assuntos com entregas no período.');
  const links=a.top_links||[];
  document.getElementById('topLinks').innerHTML=links.length?`<div class="rank-list">${links.map((l,i)=>`<div class="rank-item"><span class="rank-pos">${i+1}</span><div class="rank-copy"><strong>${escapeHtml(l.host||'Link')}</strong><small title="${escapeHtml(l.url)}">${escapeHtml(l.url.length>65?l.url.slice(0,62)+'…':l.url)}</small></div><div class="rank-metric"><strong>${fmt(l.unique_clicks)}</strong><small>${fmt(l.total_clicks)} total</small></div></div>`).join('')}</div>`:empty('Sem cliques','Os links clicados aparecerão aqui.');

  const autos=a.automation_performance||[];
  document.getElementById('automationPerformance').innerHTML=autos.length?`<table><thead><tr><th>Automação</th><th>Execuções</th><th>Concluídas</th><th>Em andamento</th><th>Falhas</th><th>Conclusão</th></tr></thead><tbody>${autos.map(x=>`<tr><td><span class="table-title">${escapeHtml(x.name)}</span><span class="table-sub">${x.active?'Ativa':'Pausada'}</span></td><td>${fmt(x.runs)}</td><td>${fmt(x.completed)}</td><td>${fmt(x.in_progress)}</td><td>${fmt(x.failed)}</td><td>${compactRate(x.completion_rate)}</td></tr>`).join('')}</tbody></table>`:empty('Sem execuções','As automações iniciadas no período aparecerão aqui.');
  const evs=a.event_performance||[];
  document.getElementById('eventPerformance').innerHTML=evs.length?`<table><thead><tr><th>Evento</th><th>Campanhas</th><th>Enviados</th><th>Entrega</th><th>Abertura</th><th>Cliques</th></tr></thead><tbody>${evs.map(x=>`<tr><td><span class="table-title">${escapeHtml(x.name)}</span><span class="table-sub">${formatDate(x.start_at)}</span></td><td>${fmt(x.campaigns_prepared)}</td><td>${fmt(x.sent)}</td><td>${compactRate(x.delivery_rate)}</td><td>${compactRate(x.open_rate)}</td><td>${compactRate(x.click_rate)}</td></tr>`).join('')}</tbody></table>`:empty('Sem eventos no período','Eventos e lançamentos relevantes aparecerão aqui.');

  const sb=a.source_breakdown||{};
  const sourceLabels={campaign:'Campanhas',automation:'Automações',other:'Outros'};
  document.getElementById('sourceBreakdown').innerHTML=['campaign','automation','other'].map(k=>{const x=sb[k]||{};return `<div class="source-card"><div><span>${sourceLabels[k]}</span><strong>${fmt(x.sent)}</strong><small>enviados</small></div><div class="source-rates"><span>${compactRate(x.delivery_rate)} entrega</span><span>${compactRate(x.open_rate)} abertura</span><span>${compactRate(x.click_rate)} clique</span></div></div>`}).join('');
  renderAlerts('reportAlerts',a.alerts||[]);
  const sel=document.getElementById('reportsPeriod'); if(sel)sel.value=String(state.analyticsDays||30);
}


function domainStatusText(v='') {
  return ({verified:'Verificado',partially_verified:'Parcialmente verificado',pending:'Verificando',not_started:'Não iniciado',provider_unconfigured:'Provedor não configurado',provider_error:'Erro no provedor',failed:'Falhou',valid:'Válido',missing:'Ausente',invalid:'Inválido',timeout:'Timeout',error:'Erro',not_required:'Não exigido'})[v] || v || '—';
}
function domainBadgeClass(v='') {
  if(['verified','valid'].includes(v)) return 'active';
  if(['pending','partially_verified','not_started','provider_unconfigured','not_required'].includes(v)) return 'scheduled';
  return 'cancelled';
}
async function copyText(value) {
  try { await navigator.clipboard.writeText(value); showToast('Copiado.'); }
  catch { showToast('Não foi possível copiar automaticamente.'); }
}
function renderDeliverability() {
  const d=state.deliverability||{};
  const summary=document.getElementById('deliverabilitySummary');
  if(summary){
    const live=d.live_send_ready;
    summary.innerHTML=`<div class="delivery-readiness ${live?'ready':'not-ready'}"><div><span class="small">Prontidão para envio real</span><strong>${live?'Pronto':'Ainda bloqueado'}</strong><p>${live?'Há domínio autenticado e remetente padrão verificado.':'O MailFlow continuará bloqueando envio real até resolver os itens abaixo.'}</p></div><div><span class="badge ${live?'active':'cancelled'}">${live?'ENVIO LIBERADO':'ENVIO BLOQUEADO'}</span> <span class="badge ${d.bulk_marketing_ready?'active':'scheduled'}">${d.bulk_marketing_ready?'MARKETING EM MASSA PRONTO':'MASSA PENDENTE'}</span></div></div>${(d.blockers||[]).length?`<div class="readiness-list"><strong>Bloqueios</strong>${d.blockers.map(x=>`<div>• ${escapeHtml(x)}</div>`).join('')}</div>`:''}${(d.warnings||[]).length?`<div class="readiness-list warning"><strong>Avisos</strong>${d.warnings.map(x=>`<div>• ${escapeHtml(x)}</div>`).join('')}</div>`:''}`;
  }
  const table=document.getElementById('domainsTable');
  if(table){
    table.innerHTML=state.sendingDomains.length?`<table><thead><tr><th>Domínio</th><th>SPF</th><th>DKIM</th><th>DMARC</th><th>Tracking</th><th>Pronto</th><th></th></tr></thead><tbody>${state.sendingDomains.map(x=>`<tr><td><span class="table-title">${escapeHtml(x.name)}</span><span class="table-sub">${escapeHtml(x.region)} • Return-Path: ${escapeHtml(x.custom_return_path)} • ${escapeHtml(domainStatusText(x.provider_status))}</span></td><td><span class="badge ${domainBadgeClass(x.spf_status)}">${escapeHtml(domainStatusText(x.spf_status))}</span></td><td><span class="badge ${domainBadgeClass(x.dkim_status)}">${escapeHtml(domainStatusText(x.dkim_status))}</span></td><td><span class="badge ${domainBadgeClass(x.dmarc_status)}">${escapeHtml(domainStatusText(x.dmarc_status))}</span></td><td><span class="badge ${domainBadgeClass(x.tracking_status)}">${escapeHtml(domainStatusText(x.tracking_status))}</span></td><td><span class="badge ${x.ready_for_sending?'active':'cancelled'}">${x.ready_for_sending?'Sim':'Não'}</span></td><td><button class="action-btn" onclick="openDomainDetails('${x.id}')">DNS</button><button class="action-btn admin-only ${state.user?.role==='admin'?'':'hidden'}" onclick="refreshSendingDomain('${x.id}')">Atualizar</button><button class="action-btn admin-only ${state.user?.role==='admin'?'':'hidden'}" onclick="verifySendingDomain('${x.id}')">Verificar</button></td></tr>`).join('')}</tbody></table>`:empty('Nenhum domínio cadastrado','Adicione um domínio ou subdomínio exclusivo para os envios do MailFlow.');
  }
  const senders=document.getElementById('senderIdentitiesTable');
  if(senders){
    senders.innerHTML=state.senderIdentities.length?`<table><thead><tr><th>Remetente</th><th>Domínio</th><th>Status</th><th>Padrão</th><th></th></tr></thead><tbody>${state.senderIdentities.map(x=>`<tr><td><span class="table-title">${escapeHtml(x.name)}</span><span class="table-sub">${escapeHtml(x.email)}${x.reply_to?` • reply-to: ${escapeHtml(x.reply_to)}`:''}</span></td><td>${escapeHtml(x.domain_name)}</td><td><span class="badge ${x.status==='verified'?'active':(x.status==='inactive'?'neutral':'cancelled')}">${x.status==='verified'?'Verificado':x.status==='inactive'?'Inativo':'Domínio não pronto'}</span></td><td>${x.is_default?'<span class="badge active">Padrão</span>':'—'}</td><td>${state.user?.role==='admin'?`${!x.is_default?`<button class="action-btn" onclick="setDefaultSender('${x.id}')">Tornar padrão</button>`:''}<button class="action-btn" onclick="toggleSenderIdentity('${x.id}',${x.active?'false':'true'})">${x.active?'Desativar':'Ativar'}</button>`:'—'}</td></tr>`).join('')}</tbody></table>`:empty('Nenhum remetente verificado','Cadastre um endereço pertencente a um domínio de envio.');
  }
}
function addDomainModal(){
  openModal(`<div class="modal-head"><div><h2>Adicionar domínio de envio</h2><p class="muted">Prefira um subdomínio dedicado, como email.suaempresa.com.br.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="domainCreateForm" class="form-grid two"><label>Domínio<input name="name" placeholder="email.suaempresa.com.br" required /></label><label>Região<select name="region"><option value="sa-east-1">São Paulo (sa-east-1)</option><option value="us-east-1">N. Virginia (us-east-1)</option><option value="eu-west-1">Irlanda (eu-west-1)</option><option value="ap-northeast-1">Tóquio (ap-northeast-1)</option></select></label><label>Return-Path<input name="custom_return_path" value="send" required /></label><label>Tracking<input name="tracking_subdomain" value="links" required /></label><label>Política DMARC<select name="dmarc_policy"><option value="none">p=none (começar monitorando)</option><option value="quarantine">p=quarantine</option><option value="reject">p=reject</option></select></label><label>E-mail para relatórios DMARC<input name="dmarc_report_email" type="email" placeholder="dmarc@suaempresa.com.br" /></label><label><span>Tracking de abertura</span><select name="open_tracking"><option value="true">Ativado</option><option value="false">Desativado</option></select></label><label><span>Tracking de clique</span><select name="click_tracking"><option value="true">Ativado</option><option value="false">Desativado</option></select></label><label>TLS<select name="tls_mode"><option value="opportunistic">Oportunístico</option><option value="enforced">Obrigatório</option></select></label><div class="modal-footer"><button class="btn btn-secondary" type="button" onclick="closeModal()">Cancelar</button><button class="btn btn-primary" type="submit">Cadastrar domínio</button></div></form>`);
  document.getElementById('domainCreateForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await request('/domains',{method:'POST',body:JSON.stringify({name:f.get('name').trim(),region:f.get('region'),custom_return_path:f.get('custom_return_path').trim(),tracking_subdomain:f.get('tracking_subdomain').trim(),dmarc_policy:f.get('dmarc_policy'),dmarc_report_email:f.get('dmarc_report_email').trim(),open_tracking:f.get('open_tracking')==='true',click_tracking:f.get('click_tracking')==='true',tls_mode:f.get('tls_mode')})});closeModal();await refreshDeliverabilityData();showToast('Domínio cadastrado. Agora publique os registros DNS.');}catch(err){showToast(err.message);}};
}
function openDomainDetails(id){
  const d=state.sendingDomains.find(x=>x.id===id); if(!d)return;
  const records=(d.dns_records||[]).map(r=>`<tr><td>${escapeHtml(r.record||'')}</td><td>${escapeHtml(r.type||'')}</td><td><code>${escapeHtml(r.name||'')}</code></td><td><code class="dns-value">${escapeHtml(r.value||'')}</code>${r.priority!=null?`<span class="table-sub">Prioridade: ${escapeHtml(r.priority)}</span>`:''}</td><td><span class="badge ${domainBadgeClass(r.status)}">${escapeHtml(domainStatusText(r.status))}</span></td><td><button class="action-btn" type="button" onclick="copyText(decodeURIComponent('${encodeURIComponent(String(r.value||''))}'))">Copiar</button></td></tr>`).join('');
  openModal(`<div class="modal-head"><div><h2>DNS de ${escapeHtml(d.name)}</h2><p class="muted">Publique exatamente estes registros no provedor DNS e depois clique em Verificar.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="dns-status-row"><span class="badge ${d.ready_for_sending?'active':'cancelled'}">${d.ready_for_sending?'DOMÍNIO PRONTO':'AINDA NÃO PRONTO'}</span><span class="muted">Última checagem: ${escapeHtml(formatDate(d.last_checked_at))}</span></div><div class="table-wrap"><table><thead><tr><th>Finalidade</th><th>Tipo</th><th>Nome</th><th>Valor</th><th>Status</th><th></th></tr></thead><tbody>${records||'<tr><td colspan="6">Os registros SPF/DKIM aparecerão quando o domínio for registrado no Resend.</td></tr>'}<tr><td>DMARC</td><td>TXT</td><td><code>_dmarc.${escapeHtml(d.name)}</code></td><td><code class="dns-value">${escapeHtml(d.dmarc_value)}</code></td><td><span class="badge ${domainBadgeClass(d.dmarc_status)}">${escapeHtml(domainStatusText(d.dmarc_status))}</span></td><td><button class="action-btn" type="button" onclick="copyText(decodeURIComponent('${encodeURIComponent(String(d.dmarc_value||''))}'))">Copiar</button></td></tr></tbody></table></div>${d.last_error?`<div class="notice">${escapeHtml(d.last_error)}</div>`:''}<form id="dmarcSettingsForm" class="form-grid two" style="margin-top:18px"><label>Política DMARC<select name="dmarc_policy"><option value="none" ${d.dmarc_policy==='none'?'selected':''}>none</option><option value="quarantine" ${d.dmarc_policy==='quarantine'?'selected':''}>quarantine</option><option value="reject" ${d.dmarc_policy==='reject'?'selected':''}>reject</option></select></label><label>Relatórios DMARC<input name="dmarc_report_email" type="email" value="${escapeHtml(d.dmarc_report_email||'')}" placeholder="dmarc@${escapeHtml(d.name)}" /></label><div class="modal-footer"><button class="btn btn-secondary" type="button" onclick="closeModal()">Fechar</button>${state.user?.role==='admin'?'<button class="btn btn-primary" type="submit">Atualizar instrução DMARC</button>':''}</div></form>`);
  const form=document.getElementById('dmarcSettingsForm'); if(form&&state.user?.role==='admin')form.onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await request(`/domains/${id}`,{method:'PATCH',body:JSON.stringify({dmarc_policy:f.get('dmarc_policy'),dmarc_report_email:f.get('dmarc_report_email').trim()})});await refreshDeliverabilityData();openDomainDetails(id);showToast('Configuração DMARC atualizada.');}catch(err){showToast(err.message);}};
}
async function refreshSendingDomain(id){try{await request(`/domains/${id}/refresh`,{method:'POST'});await refreshDeliverabilityData();showToast('Status DNS atualizado.');}catch(err){showToast(err.message);}}
async function verifySendingDomain(id){try{await request(`/domains/${id}/verify`,{method:'POST'});await refreshDeliverabilityData();showToast('Verificação solicitada. O DNS pode levar algum tempo para propagar.');}catch(err){showToast(err.message);}}
function addSenderIdentityModal(){
  const domains=state.sendingDomains; if(!domains.length){showToast('Cadastre um domínio antes de criar remetentes.');return;}
  openModal(`<div class="modal-head"><div><h2>Novo remetente</h2><p class="muted">O endereço precisa pertencer exatamente ao domínio selecionado.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="senderIdentityForm" class="form-grid two"><label>Domínio<select name="domain_id">${domains.map(d=>`<option value="${d.id}">${escapeHtml(d.name)}${d.ready_for_sending?' • verificado':''}</option>`).join('')}</select></label><label>Nome do remetente<input name="name" required placeholder="Sua Marca" /></label><label>E-mail<input name="email" type="email" required placeholder="contato@dominio.com" /></label><label>Responder para<input name="reply_to" type="email" placeholder="suporte@dominio.com" /></label><label><span>Usar como padrão</span><select name="is_default"><option value="true">Sim</option><option value="false">Não</option></select></label><div class="modal-footer"><button class="btn btn-secondary" type="button" onclick="closeModal()">Cancelar</button><button class="btn btn-primary" type="submit">Criar remetente</button></div></form>`);
  document.getElementById('senderIdentityForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await request('/senders',{method:'POST',body:JSON.stringify({domain_id:f.get('domain_id'),name:f.get('name').trim(),email:f.get('email').trim(),reply_to:f.get('reply_to').trim()||null,is_default:f.get('is_default')==='true'})});closeModal();await refreshDeliverabilityData();showToast('Remetente cadastrado.');}catch(err){showToast(err.message);}};
}
async function setDefaultSender(id){try{await request(`/senders/${id}/default`,{method:'POST'});await refreshDeliverabilityData();state.settings=await request('/settings/sender');renderSettings();showToast('Remetente padrão atualizado.');}catch(err){showToast(err.message);}}
async function toggleSenderIdentity(id,active){try{await request(`/senders/${id}`,{method:'PATCH',body:JSON.stringify({active})});await refreshDeliverabilityData();showToast(active?'Remetente ativado.':'Remetente desativado.');}catch(err){showToast(err.message);}}
async function refreshDeliverabilityData(){
  const [sendingDomains,senderIdentities,deliverability]=await Promise.all([request('/domains'),request('/senders'),request('/deliverability/status')]);
  Object.assign(state,{sendingDomains,senderIdentities,deliverability}); renderDeliverability();
}


function suppressionReasonLabel(reason){return ({unsubscribe:'Descadastro',complaint:'Reclamação de spam',hard_bounce:'Hard bounce',manual:'Bloqueio manual',privacy_delete:'Exclusão de dados'})[reason]||reason;}
function renderPrivacy(){
  const summary=document.getElementById('suppressionSummary');
  if(summary) summary.innerHTML=`<div><span>Supressões ativas</span><strong>${fmt(state.suppressions.length)}</strong></div><div><span>Descadastros</span><strong>${fmt(state.suppressions.filter(x=>x.reason==='unsubscribe').length)}</strong></div><div><span>Bounce/spam</span><strong>${fmt(state.suppressions.filter(x=>['hard_bounce','complaint'].includes(x.reason)).length)}</strong></div>`;
  const table=document.getElementById('suppressionsTable');
  if(table) table.innerHTML=state.suppressions.length?`<table><thead><tr><th>E-mail</th><th>Motivo</th><th>Origem</th><th>Data</th><th></th></tr></thead><tbody>${state.suppressions.map(x=>`<tr><td>${escapeHtml(x.email_hint)}</td><td><span class="badge neutral">${escapeHtml(suppressionReasonLabel(x.reason))}</span></td><td>${escapeHtml(x.source||'—')}</td><td>${formatDate(x.created_at)}</td><td>${state.user?.role==='admin'&&x.contact_id?`<button class="action-btn" onclick="releaseSuppressionModal('${x.id}')">Liberar com consentimento</button>`:'—'}</td></tr>`).join('')}</tbody></table>`:empty('Nenhuma supressão ativa','Descadastros, hard bounces, reclamações e bloqueios aparecerão aqui.');
  const consents=document.getElementById('consentsTable');
  if(consents) consents.innerHTML=state.consents.length?`<table><thead><tr><th>Contato</th><th>Ação</th><th>Base registrada</th><th>Origem</th><th>Data</th></tr></thead><tbody>${state.consents.slice(0,100).map(x=>`<tr><td>${escapeHtml(x.email_hint||'—')}</td><td><span class="badge ${x.action==='granted'?'active':'cancelled'}">${x.action==='granted'?'Consentimento':'Revogação'}</span></td><td>${escapeHtml(x.legal_basis||'—')}</td><td>${escapeHtml(x.source||'—')}</td><td>${formatDate(x.created_at)}</td></tr>`).join('')}</tbody></table>`:empty('Sem registros de consentimento','Registre consentimentos e revogações a partir do detalhe do contato.');
}
async function refreshPrivacy(){try{const [suppressions,consents]=await Promise.all([request('/suppressions'),request('/privacy/consents')]);state.suppressions=suppressions;state.consents=consents;renderPrivacy();}catch(err){showToast(err.message);}}
function addSuppressionModal(){openModal(`<div class="modal-head"><div><h2>Bloquear e-mail</h2><p class="muted">A supressão impede novos disparos mesmo após reimportação.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="suppressionForm" class="form-grid"><label>E-mail<input name="email" type="email" required></label><label>Motivo<select name="reason"><option value="manual">Bloqueio manual</option><option value="unsubscribe">Descadastro</option><option value="complaint">Reclamação de spam</option><option value="hard_bounce">Hard bounce</option></select></label><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Bloquear</button></div></form>`);document.getElementById('suppressionForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await request('/suppressions',{method:'POST',body:JSON.stringify({email:f.get('email'),reason:f.get('reason')})});closeModal();await refreshPrivacy();await refreshContactData();showToast('E-mail incluído na supressão global.');}catch(err){showToast(err.message);}};}
window.releaseSuppressionModal=id=>{openModal(`<div class="modal-head"><div><h2>Liberar supressão</h2><p class="muted">Faça isso somente quando houver novo consentimento verificável.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="releaseSuppressionForm" class="form-grid"><label>Origem do novo consentimento<input name="source" required placeholder="Ex.: formulário 11/09/2026"></label><label>Base registrada<input name="legal_basis" value="consent" required></label><label>Versão do aviso<input name="notice_version" placeholder="v1.0"></label><label>Observação<textarea name="note" placeholder="Como o novo opt-in foi obtido"></textarea></label><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Registrar e liberar</button></div></form>`);document.getElementById('releaseSuppressionForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await request(`/suppressions/${id}/release`,{method:'POST',body:JSON.stringify({source:f.get('source'),legal_basis:f.get('legal_basis'),notice_version:f.get('notice_version'),note:f.get('note')})});closeModal();await refreshPrivacy();await refreshContactData();showToast('Supressão liberada com novo registro de consentimento.');}catch(err){showToast(err.message);}};};
async function downloadPrivacyExport(id){try{const res=await fetch(`${API}/privacy/contacts/${id}/export`,{credentials:'include'});if(!res.ok)throw new Error('Não foi possível exportar os dados.');const blob=await res.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`mailflow-privacidade-${id}.json`;a.click();URL.revokeObjectURL(url);}catch(err){showToast(err.message);}}
function consentModal(id){openModal(`<div class="modal-head"><div><h2>Registrar consentimento</h2><p class="muted">Crie uma evidência operacional de concessão ou revogação.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="consentForm" class="form-grid"><label>Ação<select name="action"><option value="granted">Consentimento concedido</option><option value="revoked">Consentimento revogado</option></select></label><label>Base registrada<input name="legal_basis" value="consent"></label><label>Origem<input name="source" required placeholder="Ex.: landing page / checkout"></label><label>Versão do aviso<input name="notice_version" placeholder="v1.0"></label><label class="check-label"><input name="reactivate" type="checkbox"> Reativar contato e remover supressão existente</label><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Registrar</button></div></form>`);document.getElementById('consentForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await request('/privacy/consents',{method:'POST',body:JSON.stringify({contact_id:id,action:f.get('action'),legal_basis:f.get('legal_basis'),source:f.get('source'),notice_version:f.get('notice_version'),reactivate:f.get('reactivate')==='on',evidence:{recorded_by:'mailflow_ui'}})});closeModal();await refreshPrivacy();await refreshContactData();showToast('Registro de consentimento salvo.');}catch(err){showToast(err.message);}};}
async function privacyDeleteContact(id){if(!confirm('Esta ação apaga o perfil do contato e anonimiza o histórico operacional. A supressão será preservada. Continuar?'))return;const confirmation=prompt('Digite EXCLUIR para confirmar:');if(confirmation!=='EXCLUIR')return;try{await request(`/privacy/contacts/${id}`,{method:'DELETE',body:JSON.stringify({confirmation})});closeModal();await refreshPrivacy();await refreshContactData();showToast('Dados pessoais excluídos/anônimos e supressão preservada.');}catch(err){showToast(err.message);}}
function renderSettings() {
  document.getElementById('senderName').value=state.settings.sender_name||'';
  document.getElementById('senderEmail').value=state.settings.sender_email||'';
  document.getElementById('replyTo').value=state.settings.reply_to||'';
  document.getElementById('workspaceName').value=state.workspace?.name||'';
  document.getElementById('accountUserName').textContent=state.user?.name||'—';
  document.getElementById('accountUserEmail').textContent=state.user?.email||'—';
  document.getElementById('accountUserRole').textContent=state.user?.role==='admin'?'Administrador':'Usuário';
  const isAdmin=state.user?.role==='admin';
  document.querySelectorAll('.admin-only').forEach(el=>el.classList.toggle('hidden',!isAdmin));
  document.getElementById('workspaceName').disabled=!isAdmin;
  document.getElementById('usersTable').innerHTML=state.users.length?`<table><thead><tr><th>Usuário</th><th>Perfil</th><th>Status</th><th></th></tr></thead><tbody>${state.users.map(u=>`<tr><td><span class="table-title">${escapeHtml(u.name)}</span><span class="table-sub">${escapeHtml(u.email)}</span></td><td><span class="badge role-${u.role}">${u.role==='admin'?'Administrador':'Usuário'}</span></td><td><span class="badge ${u.active?'active':'neutral'}">${u.active?'Ativo':'Desativado'}</span></td><td>${isAdmin&&u.id!==state.user.id?`<button class="action-btn" onclick="toggleUserRole('${u.id}')">${u.role==='admin'?'Tornar usuário':'Tornar admin'}</button><button class="action-btn" onclick="toggleUserActive('${u.id}')">${u.active?'Desativar':'Ativar'}</button><button class="action-btn" onclick="deleteUser('${u.id}')">Excluir</button>`:'—'}</td></tr>`).join('')}</tbody></table>`:empty('Nenhum usuário','Adicione a primeira pessoa da equipe.');
  const p=state.deliveryProvider||{};
  const panel=document.getElementById('deliveryProviderPanel');
  if(panel){
    const providerName=(p.provider||'console')==='resend'?'Resend':'Console / desenvolvimento';
    const badge=p.live?'<span class="badge active">Conectado • envio real</span>':(p.provider==='resend'?'<span class="badge cancelled">Chave ausente</span>':'<span class="badge scheduled">Modo seguro</span>');
    panel.innerHTML=`<div class="provider"><div><strong>${providerName}</strong><p>${p.live?'API de entrega real habilitada.':'Fila funcional sem saída real para a internet.'}</p></div>${badge}</div><div class="provider"><div><strong>Webhooks Resend</strong><p>Entrega, bounce, reclamação, abertura e clique.</p></div><span class="badge ${p.webhook_configured?'active':'neutral'}">${p.webhook_configured?'Assinatura configurada':'Não configurado'}</span></div><div class="provider"><div><strong>Fila persistente</strong><p>Processada pelo worker em lotes com retry exponencial.</p></div><span class="badge active">Ativa</span></div>`;
    document.getElementById('deliveryProviderNotice').textContent=p.live?'Envio real habilitado. Configure o webhook do Resend para /api/webhooks/resend e mantenha SPF, DKIM e DMARC do domínio válidos.':'MAIL_PROVIDER=console está ativo. Você pode testar todo o pipeline sem disparar e-mails reais; para produção, configure MAIL_PROVIDER=resend e RESEND_API_KEY no servidor.';
  }
  renderAccountHeader();
  renderDeliverability();
  renderPrivacy();
}

let deliveryPollTimer=null;
function openModal(html) { if(deliveryPollTimer){clearInterval(deliveryPollTimer);deliveryPollTimer=null;} const modal=document.getElementById('modal'); modal.className='modal'; modal.innerHTML=html; document.getElementById('modalBackdrop').classList.remove('hidden'); }
function closeModal() { if(deliveryPollTimer){clearInterval(deliveryPollTimer);deliveryPollTimer=null;} document.getElementById('modalBackdrop').classList.add('hidden'); }
window.closeModal=closeModal;
document.getElementById('modalBackdrop').addEventListener('click',e=>{if(e.target.id==='modalBackdrop')closeModal();});

function allTags(){ return state.contactTags.map(t=>t.name); }
function estimateSegment(segment){ if(segment==='Todos os contatos ativos') return state.contactStats.active||0; const tag=segment.replace('Tag: ',''); return state.contactTags.find(t=>t.name===tag)?.count||0; }

function customFieldInput(field,value=''){
  const safe=escapeHtml(value??'');
  if(field.field_type==='boolean') return `<select name="custom:${field.key}"><option value="">—</option><option value="true" ${String(value)==='true'?'selected':''}>Sim</option><option value="false" ${String(value)==='false'?'selected':''}>Não</option></select>`;
  const type=field.field_type==='number'?'number':field.field_type==='date'?'date':'text';
  return `<input name="custom:${field.key}" type="${type}" value="${safe}">`;
}

function contactModal(c={}) {
  const custom=c.custom_fields||{};
  openModal(`<div class="modal-head"><div><h2>${c.id?'Editar contato':'Novo contato'}</h2><p class="muted">Dados, tags e campos personalizados ficam vinculados ao workspace atual.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="contactForm" class="form-grid two"><label>Nome<input name="name" value="${escapeHtml(c.name||'')}"></label><label>Sobrenome<input name="last_name" value="${escapeHtml(c.last_name||'')}"></label><label class="full">E-mail<input name="email" type="email" required value="${escapeHtml(c.email||'')}"></label><label>Telefone<input name="phone" value="${escapeHtml(c.phone||'')}"></label><label>Origem<input name="source" value="${escapeHtml(c.source||'Manual')}"></label><label class="full">Tags (separadas por vírgula)<input name="tags" value="${escapeHtml((c.tags||[]).join(', '))}"></label><label>Status<select name="status">${['active','unsubscribed','bounce','blocked','invalid'].map(st=>`<option value="${st}" ${c.status===st?'selected':''}>${contactStatus(st)}</option>`).join('')}</select></label>${state.customFields.length?`<div class="form-section-title full">Campos personalizados</div>${state.customFields.map(f=>`<label>${escapeHtml(f.label)}${customFieldInput(f,custom[f.key])}</label>`).join('')}`:''}<div class="modal-footer full"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Salvar contato</button></div></form>`);
  document.getElementById('contactForm').addEventListener('submit',async e=>{
    e.preventDefault(); const f=new FormData(e.target); const custom_fields={};
    state.customFields.forEach(field=>{const v=f.get(`custom:${field.key}`);if(v!==null&&String(v)!=='')custom_fields[field.key]=v;});
    const payload={name:(f.get('name')||'').trim(),last_name:(f.get('last_name')||'').trim(),email:f.get('email').trim(),phone:(f.get('phone')||'').trim()||null,tags:(f.get('tags')||'').split(',').map(x=>x.trim()).filter(Boolean),custom_fields,source:(f.get('source')||'').trim()||'Manual',status:f.get('status')};
    try { if(c.id) await request(`/contacts/${c.id}`,{method:'PATCH',body:JSON.stringify(payload)}); else await request('/contacts',{method:'POST',body:JSON.stringify(payload)}); closeModal(); state.selectedContacts.delete(c.id); await refreshContactData(); showToast('Contato salvo.'); } catch(err){showToast(err.message);}
  });
}

window.editContact=id=>{const c=state.contacts.find(x=>x.id===id);if(c)contactModal(c);};
window.viewContact=async id=>{
  try{
    const detail=await request(`/contacts/${id}`); const c=detail.contact;
    const customEntries=state.customFields.map(f=>[f.label,(c.custom_fields||{})[f.key]]).filter(([,v])=>v!==undefined&&v!=='');
    openModal(`<div class="modal-head"><div><h2>${escapeHtml(([c.name,c.last_name].filter(Boolean).join(' '))||c.email)}</h2><p class="muted">${escapeHtml(c.email)}</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="contact-detail-grid"><div><span class="small">Status</span><strong><span class="badge ${c.status}">${contactStatus(c.status)}</span></strong></div><div><span class="small">Origem</span><strong>${escapeHtml(c.source||'—')}</strong></div><div><span class="small">Telefone</span><strong>${escapeHtml(c.phone||'—')}</strong></div><div><span class="small">Cadastro</span><strong>${formatDate(c.created_at)}</strong></div></div><div class="detail-section"><h3>Tags</h3><div>${(c.tags||[]).map(t=>`<span class="badge neutral">${escapeHtml(t)}</span>`).join(' ')||'<span class="muted">Sem tags</span>'}</div></div>${customEntries.length?`<div class="detail-section"><h3>Campos personalizados</h3><div class="custom-detail-list">${customEntries.map(([l,v])=>`<div><span>${escapeHtml(l)}</span><strong>${escapeHtml(v)}</strong></div>`).join('')}</div></div>`:''}<div class="detail-section"><div class="panel-head"><div><h3>Histórico</h3><p>Últimos eventos registrados para este contato.</p></div></div><div class="timeline">${detail.history.length?detail.history.map(h=>`<div class="timeline-item"><span class="timeline-dot"></span><div><strong>${escapeHtml(h.description)}</strong><small>${formatDate(h.created_at)}</small></div></div>`).join(''):empty('Sem histórico','Os próximos eventos aparecerão aqui.')}</div></div><div class="modal-footer"><button class="btn btn-secondary" onclick="downloadPrivacyExport('${c.id}')">Exportar dados</button>${state.user?.role==='admin'?`<button class="btn btn-secondary" onclick="consentModal('${c.id}')">Consentimento</button><button class="btn btn-secondary" onclick="privacyDeleteContact('${c.id}')">Excluir dados</button>`:''}<button class="btn btn-secondary" onclick="closeModal()">Fechar</button><button class="btn btn-primary" onclick="closeModal();editContact('${c.id}')">Editar contato</button></div>`);
  }catch(err){showToast(err.message);}
};
window.deleteContact=async id=>{if(!confirm('Excluir este contato e seu histórico?'))return;try{await request(`/contacts/${id}`,{method:'DELETE'});state.selectedContacts.delete(id);await refreshContactData();showToast('Contato excluído.');}catch(err){showToast(err.message);}};
document.getElementById('addContactBtn').onclick=()=>contactModal({status:'active',custom_fields:{}});

async function refreshContactData(){
  const [dashboard]=await Promise.all([request('/dashboard'),refreshContacts({meta:true}),refreshAudienceData(false)]);
  state.dashboard=dashboard;renderDashboard();renderSegments();renderCampaigns();
}

function bulkTagsModal(action){
  const adding=action==='add_tags';
  openModal(`<div class="modal-head"><div><h2>${adding?'Adicionar tags':'Remover tags'}</h2><p class="muted">A ação será aplicada a ${fmt(state.selectedContacts.size)} contatos selecionados.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="bulkTagsForm" class="form-grid"><label>Tags<input name="tags" required placeholder="Ex.: cliente, conferencia-setembro"></label><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Aplicar</button></div></form>`);
  document.getElementById('bulkTagsForm').onsubmit=async e=>{e.preventDefault();const tags=new FormData(e.target).get('tags').split(',').map(x=>x.trim()).filter(Boolean);try{await request('/contacts/bulk',{method:'POST',body:JSON.stringify({ids:[...state.selectedContacts],action,tags})});closeModal();state.selectedContacts.clear();await refreshContactData();showToast('Tags atualizadas.');}catch(err){showToast(err.message);}};
}
document.getElementById('bulkAddTagBtn').onclick=()=>bulkTagsModal('add_tags');
document.getElementById('bulkRemoveTagBtn').onclick=()=>bulkTagsModal('remove_tags');
document.getElementById('bulkStatusBtn').onclick=()=>{
  openModal(`<div class="modal-head"><div><h2>Alterar status</h2><p class="muted">Aplicar a ${fmt(state.selectedContacts.size)} contatos.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="bulkStatusForm" class="form-grid"><label>Novo status<select name="status">${['active','unsubscribed','bounce','blocked','invalid'].map(st=>`<option value="${st}">${contactStatus(st)}</option>`).join('')}</select></label><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Aplicar</button></div></form>`);
  document.getElementById('bulkStatusForm').onsubmit=async e=>{e.preventDefault();const status=new FormData(e.target).get('status');try{await request('/contacts/bulk',{method:'POST',body:JSON.stringify({ids:[...state.selectedContacts],action:'set_status',status})});closeModal();state.selectedContacts.clear();await refreshContactData();showToast('Status atualizado.');}catch(err){showToast(err.message);}};
};
document.getElementById('bulkDeleteBtn').onclick=async()=>{if(!confirm(`Excluir ${state.selectedContacts.size} contatos selecionados?`))return;try{await request('/contacts/bulk',{method:'POST',body:JSON.stringify({ids:[...state.selectedContacts],action:'delete'})});state.selectedContacts.clear();await refreshContactData();showToast('Contatos excluídos.');}catch(err){showToast(err.message);}};
document.getElementById('clearSelectionBtn').onclick=()=>{state.selectedContacts.clear();renderContacts();};

function customFieldsModal(){
  openModal(`<div class="modal-head"><div><h2>Campos personalizados</h2><p class="muted">Crie dados adicionais para contatos, importações e filtros.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="custom-fields-list">${state.customFields.length?state.customFields.map(f=>`<div class="custom-field-row"><div><strong>${escapeHtml(f.label)}</strong><span class="table-sub">{{${escapeHtml(f.key)}}} • ${escapeHtml(f.field_type)}</span></div><button class="action-btn danger-action" onclick="deleteCustomField('${f.id}')">Excluir</button></div>`).join(''):empty('Nenhum campo personalizado','Crie o primeiro campo abaixo.')}</div><form id="customFieldForm" class="form-grid two custom-field-form"><label>Nome do campo<input name="label" required placeholder="Ex.: Cidade"></label><label>Tipo<select name="field_type"><option value="text">Texto</option><option value="number">Número</option><option value="date">Data</option><option value="boolean">Sim/Não</option></select></label><div class="modal-footer full"><button type="button" class="btn btn-secondary" onclick="closeModal()">Fechar</button><button class="btn btn-primary">Criar campo</button></div></form>`);
  document.getElementById('customFieldForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await request('/contacts/custom-fields',{method:'POST',body:JSON.stringify({label:f.get('label').trim(),field_type:f.get('field_type')})});state.customFields=await request('/contacts/custom-fields');customFieldsModal();showToast('Campo criado.');}catch(err){showToast(err.message);}};
}
document.getElementById('customFieldsBtn').onclick=customFieldsModal;
window.deleteCustomField=async id=>{if(!confirm('Excluir este campo e remover seus valores dos contatos?'))return;try{await request(`/contacts/custom-fields/${id}`,{method:'DELETE'});state.customFields=await request('/contacts/custom-fields');customFieldsModal();await refreshContacts({meta:true});showToast('Campo removido.');}catch(err){showToast(err.message);}};

function audienceCount(type='all', id=null) {
  if (type === 'list') return state.lists.find(x=>x.id===id)?.active_member_count || 0;
  if (type === 'segment') return state.segments.find(x=>x.id===id)?.active_count || 0;
  return state.contactStats.active || 0;
}

function audienceLabel(type='all', id=null) {
  if (type === 'list') return state.lists.find(x=>x.id===id)?.name || 'Lista';
  if (type === 'segment') return state.segments.find(x=>x.id===id)?.name || 'Segmento';
  return 'Todos os contatos ativos';
}

function renderSegments() {
  document.getElementById('listsTotal').textContent=fmt(state.lists.length);
  document.getElementById('segmentsTotal').textContent=fmt(state.segments.length);
  document.getElementById('audienceActiveContacts').textContent=fmt(state.contactStats.active);
  const largest=Math.max(0,...state.lists.map(x=>x.active_member_count||0),...state.segments.map(x=>x.active_count||0));
  document.getElementById('largestAudience').textContent=fmt(largest);

  document.getElementById('listsGrid').innerHTML=state.lists.length?state.lists.map(item=>`
    <div class="audience-card">
      <div class="audience-card-head"><div><span class="badge neutral">Lista estática</span><h4>${escapeHtml(item.name)}</h4></div><strong>${fmt(item.active_member_count)}</strong></div>
      <p>${escapeHtml(item.description||'Sem descrição.')}</p>
      <div class="audience-meta"><span>${fmt(item.member_count)} membros</span><span>${fmt(item.active_member_count)} ativos</span><span>Atualizada ${formatDate(item.updated_at)}</span></div>
      <div class="audience-actions"><button class="action-btn" onclick="manageList('${item.id}')">Gerenciar membros</button><button class="action-btn" onclick="editList('${item.id}')">Editar</button><button class="action-btn danger-action" onclick="deleteList('${item.id}')">Excluir</button></div>
    </div>`).join(''):empty('Nenhuma lista','Crie uma lista para selecionar contatos manualmente.');

  document.getElementById('segmentsGrid').innerHTML=state.segments.length?state.segments.map(item=>`
    <div class="audience-card">
      <div class="audience-card-head"><div><span class="badge active">Segmento dinâmico</span><h4>${escapeHtml(item.name)}</h4></div><strong>${fmt(item.active_count)}</strong></div>
      <p>${escapeHtml(item.description||'Sem descrição.')}</p>
      <div class="rule-chips">${item.rules.slice(0,3).map(rule=>`<span>${escapeHtml(ruleSummary(rule))}</span>`).join('')}${item.rules.length>3?`<span>+${item.rules.length-3} regras</span>`:''}</div>
      <div class="audience-meta"><span>${fmt(item.matching_count)} correspondem</span><span>${fmt(item.active_count)} ativos</span><span>${item.match_mode==='all'?'Todas as regras':'Qualquer regra'}</span></div>
      <div class="audience-actions"><button class="action-btn" onclick="previewSegment('${item.id}')">Ver público</button><button class="action-btn" onclick="editSegment('${item.id}')">Editar</button><button class="action-btn danger-action" onclick="deleteSegment('${item.id}')">Excluir</button></div>
    </div>`).join(''):empty('Nenhum segmento','Crie regras para formar uma audiência dinâmica.');
}

function listModal(item={}) {
  openModal(`<div class="modal-head"><div><h2>${item.id?'Editar lista':'Nova lista'}</h2><p class="muted">Listas são públicos fixos. Os membros só mudam quando você adiciona ou remove contatos.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="listForm" class="form-grid"><label>Nome da lista<input name="name" required maxlength="180" value="${escapeHtml(item.name||'')}"></label><label>Descrição<textarea name="description" maxlength="500" placeholder="Ex.: Compradores da Conferência de Setembro">${escapeHtml(item.description||'')}</textarea></label><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Salvar lista</button></div></form>`);
  document.getElementById('listForm').onsubmit=async e=>{
    e.preventDefault(); const f=new FormData(e.target); const payload={name:f.get('name').trim(),description:f.get('description').trim()};
    try{
      const saved=item.id?await request(`/lists/${item.id}`,{method:'PATCH',body:JSON.stringify(payload)}):await request('/lists',{method:'POST',body:JSON.stringify(payload)});
      closeModal(); await refreshAudienceData(); showToast(item.id?'Lista atualizada.':'Lista criada.');
      if(!item.id) manageList(saved.id);
    }catch(err){showToast(err.message);}
  };
}
window.editList=id=>{const item=state.lists.find(x=>x.id===id);if(item)listModal(item);};
window.deleteList=async id=>{if(!confirm('Excluir esta lista? Os contatos não serão excluídos.'))return;try{await request(`/lists/${id}`,{method:'DELETE'});await refreshAudienceData();showToast('Lista excluída.');}catch(err){showToast(err.message);}};

document.getElementById('newListBtn').onclick=()=>listModal();
document.getElementById('newListInlineBtn').onclick=()=>listModal();

async function manageList(id, search='') {
  const item=state.lists.find(x=>x.id===id); if(!item)return;
  try{
    const [members, candidates]=await Promise.all([
      request(`/lists/${id}/members?page=1&page_size=100`),
      request(`/contacts/search?page=1&page_size=50${search?`&q=${encodeURIComponent(search)}`:''}`)
    ]);
    const memberIds=new Set(members.items.map(x=>x.id));
    const available=candidates.items.filter(x=>!memberIds.has(x.id));
    openModal(`<div class="modal-head"><div><h2>${escapeHtml(item.name)}</h2><p class="muted">${fmt(members.total)} membros • ${fmt(item.active_member_count)} ativos para campanhas</p></div><button class="modal-close" onclick="closeModal()">×</button></div>
      <div class="list-manager-grid">
        <div class="list-manager-col"><div class="panel-head"><div><h3>Membros atuais</h3><p>Até 100 contatos exibidos nesta tela.</p></div></div><div class="member-list">${members.items.length?members.items.map(c=>`<div class="member-row"><div><strong>${escapeHtml(([c.name,c.last_name].filter(Boolean).join(' '))||'Sem nome')}</strong><small>${escapeHtml(c.email)}</small></div><div><span class="badge ${c.status}">${contactStatus(c.status)}</span><button class="action-btn danger-action" onclick="removeFromList('${id}','${c.id}','${escapeHtml(search)}')">Remover</button></div></div>`).join(''):empty('Lista vazia','Adicione contatos pela coluna ao lado.')}</div></div>
        <div class="list-manager-col"><div class="panel-head"><div><h3>Adicionar contatos</h3><p>Pesquise na sua base.</p></div></div><form id="listSearchForm" class="inline-search"><input name="q" placeholder="Nome ou e-mail" value="${escapeHtml(search)}"><button class="btn btn-secondary">Buscar</button></form><div class="member-list">${available.length?available.map(c=>`<div class="member-row"><div><strong>${escapeHtml(([c.name,c.last_name].filter(Boolean).join(' '))||'Sem nome')}</strong><small>${escapeHtml(c.email)}</small></div><button class="action-btn" onclick="addToList('${id}','${c.id}','${escapeHtml(search)}')">Adicionar</button></div>`).join(''):empty('Nenhum contato disponível','Altere a busca ou importe novos contatos.')}</div></div>
      </div><div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Concluir</button></div>`);
    document.getElementById('listSearchForm').onsubmit=e=>{e.preventDefault();manageList(id,new FormData(e.target).get('q').trim());};
  }catch(err){showToast(err.message);}
}
window.manageList=manageList;
window.addToList=async(listId,contactId,search='')=>{try{await request(`/lists/${listId}/members`,{method:'POST',body:JSON.stringify({contact_ids:[contactId]})});await refreshAudienceData(false);await manageList(listId,search);showToast('Contato adicionado à lista.');}catch(err){showToast(err.message);}};
window.removeFromList=async(listId,contactId,search='')=>{try{await request(`/lists/${listId}/members/remove`,{method:'POST',body:JSON.stringify({contact_ids:[contactId]})});await refreshAudienceData(false);await manageList(listId,search);showToast('Contato removido da lista.');}catch(err){showToast(err.message);}};

function fieldLabel(rule){
  const labels={status:'Status',tag:'Tag',source:'Origem',email:'E-mail',name:'Nome',phone:'Telefone',created_at:'Data de cadastro'};
  if(rule.field==='custom') return state.customFields.find(x=>x.key===rule.custom_key)?.label||`Campo ${rule.custom_key||''}`;
  return labels[rule.field]||rule.field;
}
function operatorLabel(op){return ({equals:'=',not_equals:'≠',contains:'contém',not_contains:'não contém',starts_with:'começa com',ends_with:'termina com',is_set:'está preenchido',not_set:'não está preenchido',before:'antes de',after:'depois de'})[op]||op;}
function ruleSummary(rule){return `${fieldLabel(rule)} ${operatorLabel(rule.operator)}${['is_set','not_set'].includes(rule.operator)?'':` ${rule.field==='status'?contactStatus(rule.value):rule.value||''}`}`;}
function segmentFieldOptions(rule={}){
  const selected=rule.field==='custom'?`custom:${rule.custom_key}`:rule.field||'tag';
  const options=[['tag','Tag'],['status','Status'],['source','Origem'],['email','E-mail'],['name','Nome'],['phone','Telefone'],['created_at','Data de cadastro'],...state.customFields.map(f=>[`custom:${f.key}`,`Campo: ${f.label}`])];
  return options.map(([v,l])=>`<option value="${escapeHtml(v)}" ${selected===v?'selected':''}>${escapeHtml(l)}</option>`).join('');
}
function operatorsForField(field){
  if(field==='status')return [['equals','='],['not_equals','≠']];
  if(field==='tag')return [['contains','contém'],['not_contains','não contém'],['is_set','tem alguma tag'],['not_set','não tem tags']];
  if(field==='created_at')return [['after','depois de'],['before','antes de'],['equals','na data']];
  return [['contains','contém'],['not_contains','não contém'],['equals','='],['not_equals','≠'],['starts_with','começa com'],['ends_with','termina com'],['is_set','está preenchido'],['not_set','não está preenchido']];
}
function segmentOperatorOptions(field, selected){return operatorsForField(field).map(([v,l])=>`<option value="${v}" ${v===selected?'selected':''}>${l}</option>`).join('');}
function ruleValueControl(field, operator, value=''){
  if(['is_set','not_set'].includes(operator)) return `<input class="rule-value" disabled value="Não exige valor">`;
  if(field==='status') return `<select class="rule-value">${['active','unsubscribed','bounce','blocked','invalid'].map(v=>`<option value="${v}" ${v===value?'selected':''}>${contactStatus(v)}</option>`).join('')}</select>`;
  if(field==='tag') return `<input class="rule-value" list="segmentTagsList" value="${escapeHtml(value||'')}" placeholder="Ex.: comprador">`;
  if(field==='source') return `<input class="rule-value" list="segmentSourcesList" value="${escapeHtml(value||'')}" placeholder="Ex.: Meta Ads">`;
  if(field==='created_at') return `<input class="rule-value" type="date" value="${escapeHtml(value||'')}">`;
  return `<input class="rule-value" value="${escapeHtml(value||'')}" placeholder="Valor da regra">`;
}
function segmentRuleRow(rule={field:'tag',operator:'contains',value:''}){
  const fieldValue=rule.field==='custom'?`custom:${rule.custom_key}`:rule.field||'tag';
  return `<div class="segment-rule-row"><select class="rule-field">${segmentFieldOptions(rule)}</select><select class="rule-operator">${segmentOperatorOptions(rule.field||'tag',rule.operator||'contains')}</select><div class="rule-value-wrap">${ruleValueControl(rule.field||'tag',rule.operator||'contains',rule.value||'')}</div><button type="button" class="action-btn danger-action remove-rule-btn">Remover</button></div>`;
}
function wireRuleRows(){
  document.querySelectorAll('.segment-rule-row').forEach(row=>{
    const field=row.querySelector('.rule-field'), op=row.querySelector('.rule-operator'), wrap=row.querySelector('.rule-value-wrap');
    field.onchange=()=>{const raw=field.value;const base=raw.startsWith('custom:')?'custom':raw;const opts=operatorsForField(base);op.innerHTML=opts.map(([v,l])=>`<option value="${v}">${l}</option>`).join('');wrap.innerHTML=ruleValueControl(base,op.value,'');};
    op.onchange=()=>{const raw=field.value;const base=raw.startsWith('custom:')?'custom':raw;const old=wrap.querySelector('.rule-value')?.value||'';wrap.innerHTML=ruleValueControl(base,op.value,old);};
    row.querySelector('.remove-rule-btn').onclick=()=>{if(document.querySelectorAll('.segment-rule-row').length<=1){showToast('Um segmento precisa ter pelo menos uma regra.');return;}row.remove();};
  });
}
function collectSegmentRules(){
  return [...document.querySelectorAll('.segment-rule-row')].map(row=>{
    const raw=row.querySelector('.rule-field').value; const field=raw.startsWith('custom:')?'custom':raw; const custom_key=raw.startsWith('custom:')?raw.split(':',2)[1]:null; const operator=row.querySelector('.rule-operator').value; const input=row.querySelector('.rule-value');
    return {field,operator,value:['is_set','not_set'].includes(operator)?null:(input?.value||'').trim(),custom_key};
  });
}
function renderSegmentPreview(result){
  const box=document.getElementById('segmentPreviewBox'); if(!box)return;
  box.innerHTML=`<div class="segment-preview-metrics"><div><span>Correspondem</span><strong>${fmt(result.matching_count)}</strong></div><div><span>Ativos para campanha</span><strong>${fmt(result.active_count)}</strong></div></div>${result.sample.length?`<div class="preview-contact-list">${result.sample.slice(0,8).map(c=>`<span>${escapeHtml(([c.name,c.last_name].filter(Boolean).join(' '))||c.email)} <small>${escapeHtml(c.email)}</small></span>`).join('')}</div>`:'<p class="muted">Nenhum contato corresponde às regras atuais.</p>'}`;
}
async function previewCurrentSegment(){
  try{const form=document.getElementById('segmentForm');const payload={match_mode:new FormData(form).get('match_mode'),rules:collectSegmentRules()};const result=await request('/segments/preview',{method:'POST',body:JSON.stringify(payload)});renderSegmentPreview(result);}catch(err){showToast(err.message);}
}
function segmentModal(item={}){
  const rules=item.rules?.length?item.rules:[{field:'tag',operator:'contains',value:''}];
  openModal(`<div class="modal-head"><div><h2>${item.id?'Editar segmento':'Novo segmento'}</h2><p class="muted">Segmentos são recalculados automaticamente sempre que os dados dos contatos mudam.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="segmentForm" class="form-grid"><label>Nome<input name="name" required maxlength="180" value="${escapeHtml(item.name||'')}"></label><label>Descrição<textarea name="description" maxlength="500" placeholder="Ex.: Interessados que ainda não compraram">${escapeHtml(item.description||'')}</textarea></label><label>Combinação<select name="match_mode"><option value="all" ${item.match_mode!=='any'?'selected':''}>Todas as regras devem ser verdadeiras (E)</option><option value="any" ${item.match_mode==='any'?'selected':''}>Qualquer regra pode ser verdadeira (OU)</option></select></label><div class="segment-builder"><div class="form-section-title">Regras do segmento</div><div id="segmentRules">${rules.map(segmentRuleRow).join('')}</div><button type="button" class="btn btn-secondary" id="addSegmentRuleBtn">+ Adicionar regra</button><datalist id="segmentTagsList">${state.contactTags.map(t=>`<option value="${escapeHtml(t.name)}">`).join('')}</datalist><datalist id="segmentSourcesList">${state.contactSources.map(v=>`<option value="${escapeHtml(v)}">`).join('')}</datalist></div><div class="segment-preview-box" id="segmentPreviewBox"><p class="muted">Clique em “Testar regras” para ver quantos contatos entram no segmento.</p></div><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button type="button" class="btn btn-secondary" id="previewSegmentRulesBtn">Testar regras</button><button class="btn btn-primary">Salvar segmento</button></div></form>`);
  wireRuleRows();
  document.getElementById('addSegmentRuleBtn').onclick=()=>{document.getElementById('segmentRules').insertAdjacentHTML('beforeend',segmentRuleRow());wireRuleRows();};
  document.getElementById('previewSegmentRulesBtn').onclick=previewCurrentSegment;
  document.getElementById('segmentForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const payload={name:f.get('name').trim(),description:f.get('description').trim(),match_mode:f.get('match_mode'),rules:collectSegmentRules()};if(payload.rules.some(r=>!['is_set','not_set'].includes(r.operator)&&!r.value)){showToast('Preencha o valor de todas as regras.');return;}try{if(item.id)await request(`/segments/${item.id}`,{method:'PATCH',body:JSON.stringify(payload)});else await request('/segments',{method:'POST',body:JSON.stringify(payload)});closeModal();await refreshAudienceData();showToast(item.id?'Segmento atualizado.':'Segmento criado.');}catch(err){showToast(err.message);}};
  if(item.id) setTimeout(previewCurrentSegment,0);
}
window.editSegment=id=>{const item=state.segments.find(x=>x.id===id);if(item)segmentModal(item);};
window.deleteSegment=async id=>{if(!confirm('Excluir este segmento? Campanhas antigas manterão o histórico do nome, mas não poderão recalcular esse público.'))return;try{await request(`/segments/${id}`,{method:'DELETE'});await refreshAudienceData();showToast('Segmento excluído.');}catch(err){showToast(err.message);}};
window.previewSegment=async id=>{try{const item=state.segments.find(x=>x.id===id);const result=await request(`/segments/${id}/preview`);openModal(`<div class="modal-head"><div><h2>${escapeHtml(item?.name||'Segmento')}</h2><p class="muted">Prévia dinâmica calculada agora.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="segment-preview-metrics large"><div><span>Correspondem às regras</span><strong>${fmt(result.matching_count)}</strong></div><div><span>Ativos para campanhas</span><strong>${fmt(result.active_count)}</strong></div></div><div class="detail-section"><h3>Amostra do público</h3>${result.sample.length?`<div class="member-list">${result.sample.map(c=>`<div class="member-row"><div><strong>${escapeHtml(([c.name,c.last_name].filter(Boolean).join(' '))||'Sem nome')}</strong><small>${escapeHtml(c.email)}</small></div><span class="badge ${c.status}">${contactStatus(c.status)}</span></div>`).join('')}</div>`:empty('Nenhum contato','As regras atuais não encontraram correspondências.')}</div><div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Fechar</button><button class="btn btn-primary" onclick="closeModal();editSegment('${id}')">Editar regras</button></div>`);}catch(err){showToast(err.message);}};

document.getElementById('newSegmentBtn').onclick=()=>segmentModal();
document.getElementById('newSegmentInlineBtn').onclick=()=>segmentModal();

async function refreshAudienceData(render=true){
  const [lists,segments]=await Promise.all([request('/lists'),request('/segments')]);
  state.lists=lists; state.segments=segments;
  if(render){renderSegments();renderCampaigns();}
}


function defaultEmailDesign(){
  return [
    {type:'heading',data:{text:'Está chegando o dia',level:'h2',align:'left',font_size:28,color:'#16181d'}},
    {type:'text',data:{text:'Olá, {{nome|Olá}}.\n\nEscreva aqui a mensagem principal da sua campanha.',align:'left',font_size:16,color:'#3f4350'}},
    {type:'button',data:{text:'Clique em saiba mais',url:'https://',align:'left',bg_color:'#2427d8',text_color:'#ffffff',radius:8}}
  ];
}

function emailInitial(source={}){
  const hasDesign=Array.isArray(source.design_json)&&source.design_json.length;
  return {
    editor_mode:source.editor_mode||'visual',
    design_json:hasDesign?source.design_json:(source.body?[{type:'text',data:{text:source.body,align:'left',font_size:16,color:'#3f4350'}}]:defaultEmailDesign()),
    html_body:source.html_body||'',
    body:source.body||''
  };
}

function senderOptions(currentId){
  const active=state.senderIdentities.filter(x=>x.active);
  if(!active.length) return '<option value="">Remetente padrão / desenvolvimento</option>';
  return `<option value="">Usar remetente padrão</option>${active.map(x=>`<option value="${x.id}" ${currentId===x.id?'selected':''}>${escapeHtml(x.name)} &lt;${escapeHtml(x.email)}&gt;${x.domain_ready?' • pronto':' • domínio não pronto'}</option>`).join('')}`;
}

function multiOptions(items, selected=[]){
  const set=new Set(selected||[]);
  return items.map(x=>`<option value="${x.id}" ${set.has(x.id)?'selected':''}>${escapeHtml(x.name)}</option>`).join('');
}

function campaignModal(c={}, template=null) {
  const seed=template||{};
  const base=c.id?c:{name:'',subject:seed.subject||'',preheader:seed.preheader||'',segment:'Todos os contatos ativos',audience_type:'all',audience_id:null,status:'draft',scheduled_at:null,sender_id:null,exclude_list_ids:[],exclude_segment_ids:[],exclude_tags:[],utm_enabled:false,utm_source:'mailflow',utm_medium:'email',utm_campaign:'',utm_content:'',utm_term:'',...emailInitial(seed)};
  const localDate=base.scheduled_at?new Date(base.scheduled_at).toISOString().slice(0,16):'';
  const currentValue=base.audience_type==='list'?`list:${base.audience_id}`:base.audience_type==='segment'?`segment:${base.audience_id}`:'all:';
  const audienceOptions=`<option value="all:" ${currentValue==='all:'?'selected':''}>Todos os contatos</option>${state.lists.length?`<optgroup label="Listas estáticas">${state.lists.map(x=>`<option value="list:${x.id}" ${currentValue===`list:${x.id}`?'selected':''}>${escapeHtml(x.name)} • ${fmt(x.active_member_count)} ativos</option>`).join('')}</optgroup>`:''}${state.segments.length?`<optgroup label="Segmentos dinâmicos">${state.segments.map(x=>`<option value="segment:${x.id}" ${currentValue===`segment:${x.id}`?'selected':''}>${escapeHtml(x.name)} • ${fmt(x.active_count)} ativos</option>`).join('')}</optgroup>`:''}`;
  openModal(`<div class="modal-head"><div><h2>${c.id?'Editar campanha':'Nova campanha'}</h2><p class="muted">Defina audiência, exclusões, remetente e conteúdo. O envio será revisado antes da confirmação.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="campaignForm" class="form-grid two"><label>Nome interno<input name="name" required value="${escapeHtml(base.name||'')}"></label><label>Público<select name="audience">${audienceOptions}</select></label><label class="full">Assunto<input name="subject" required maxlength="250" value="${escapeHtml(base.subject||'')}" placeholder="Ex.: Está chegando o dia, {{nome|Olá}}"></label><label class="full">Preheader<input name="preheader" maxlength="250" value="${escapeHtml(base.preheader||'')}" placeholder="Texto curto que aparece ao lado do assunto"></label><label>Remetente<select name="sender_id">${senderOptions(base.sender_id)}</select></label><label>Excluir tags<input name="exclude_tags" value="${escapeHtml((base.exclude_tags||[]).join(', '))}" placeholder="comprador, aluno"></label><label>Excluir listas<select name="exclude_list_ids" multiple size="4">${multiOptions(state.lists,base.exclude_list_ids)}</select><small>Use Ctrl/Cmd para selecionar várias.</small></label><label>Excluir segmentos<select name="exclude_segment_ids" multiple size="4">${multiOptions(state.segments,base.exclude_segment_ids)}</select><small>Use Ctrl/Cmd para selecionar vários.</small></label><label>Status<select name="status"><option value="draft" ${base.status==='draft'?'selected':''}>Enviar manualmente</option><option value="scheduled" ${base.status==='scheduled'?'selected':''}>Agendar</option></select></label><label>Data e hora<input name="date" type="datetime-local" value="${localDate}"></label><div class="form-section-title full">UTM e atribuição</div><label class="check-label full"><input name="utm_enabled" type="checkbox" ${base.utm_enabled?'checked':''}> Adicionar UTMs automaticamente aos links HTTP/HTTPS</label><label>utm_source<input name="utm_source" value="${escapeHtml(base.utm_source||'mailflow')}" placeholder="mailflow"></label><label>utm_medium<input name="utm_medium" value="${escapeHtml(base.utm_medium||'email')}" placeholder="email"></label><label>utm_campaign<input name="utm_campaign" value="${escapeHtml(base.utm_campaign||'')}" placeholder="Se vazio, usa o nome da campanha"></label><label>utm_content<input name="utm_content" value="${escapeHtml(base.utm_content||'')}" placeholder="Ex.: botao-principal"></label><label>utm_term<input name="utm_term" value="${escapeHtml(base.utm_term||'')}" placeholder="Opcional"></label><div class="segment-preview full">Estimativa inicial do público: <strong id="segmentCount">${fmt(audienceCount(base.audience_type,base.audience_id))}</strong> contatos ativos. A revisão final recalcula exclusões e supressões. <button type="button" class="link-btn" id="openAudienceModuleBtn">Gerenciar públicos</button></div><div class="full"><div class="form-section-title">Conteúdo do e-mail</div><p class="muted email-editor-intro">Use blocos para montar o e-mail. Variáveis são substituídas individualmente no envio.</p><div id="campaignEmailEditor"></div></div><div class="modal-footer full"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Salvar campanha</button></div></form>`);
  document.getElementById('modal').classList.add('modal-wide');
  const form=document.getElementById('campaignForm');
  const editor=MailFlowEmailEditor.mount(document.getElementById('campaignEmailEditor'),emailInitial(base),{customFields:state.customFields,metadata:()=>({subject:form.elements.subject.value,preheader:form.elements.preheader.value})});
  const updateCount=()=>{const [type,id]=form.elements.audience.value.split(':');document.getElementById('segmentCount').textContent=fmt(audienceCount(type,id||null));};
  form.elements.audience.addEventListener('change',updateCount);
  form.elements.subject.addEventListener('input',()=>editor.setMetadata());
  form.elements.preheader.addEventListener('input',()=>editor.setMetadata());
  document.getElementById('openAudienceModuleBtn').onclick=()=>{editor.destroy();closeModal();navigate('segments');};
  form.addEventListener('submit',async e=>{
    e.preventDefault(); const f=new FormData(form); const date=f.get('date'); const [audience_type,audienceId]=f.get('audience').split(':');
    const payload={name:f.get('name').trim(),subject:f.get('subject').trim(),preheader:f.get('preheader').trim(),audience_type,audience_id:audienceId||null,status:f.get('status'),scheduled_at:date?new Date(date).toISOString():null,sender_id:f.get('sender_id')||null,exclude_list_ids:f.getAll('exclude_list_ids'),exclude_segment_ids:f.getAll('exclude_segment_ids'),exclude_tags:(f.get('exclude_tags')||'').split(',').map(x=>x.trim()).filter(Boolean),utm_enabled:f.get('utm_enabled')==='on',utm_source:(f.get('utm_source')||'mailflow').trim(),utm_medium:(f.get('utm_medium')||'email').trim(),utm_campaign:(f.get('utm_campaign')||'').trim(),utm_content:(f.get('utm_content')||'').trim(),utm_term:(f.get('utm_term')||'').trim(),...editor.getValue()};
    if(payload.status==='scheduled'&&!payload.scheduled_at){showToast('Defina a data de envio.');return;}
    try { const saved=c.id?await request(`/campaigns/${c.id}`,{method:'PATCH',body:JSON.stringify(payload)}):await request('/campaigns',{method:'POST',body:JSON.stringify(payload)}); editor.destroy(); closeModal(); navigate('campaigns'); await refreshData(); showToast('Campanha salva. Revise antes de enviar.'); if(!c.id) setTimeout(()=>reviewCampaign(saved.id),120); } catch(err){showToast(err.message);}
  });
}
window.editCampaign=id=>campaignModal(state.campaigns.find(c=>c.id===id));

function reviewIssueList(items,kind){
  if(!items?.length) return '';
  return `<div class="review-issues ${kind}">${items.map(x=>`<div><strong>${kind==='blocker'?'Bloqueio':'Atenção'}</strong><span>${escapeHtml(x)}</span></div>`).join('')}</div>`;
}

window.reviewCampaign=async id=>{
  try{
    const c=state.campaigns.find(x=>x.id===id); if(!c)return;
    const r=await request(`/campaigns/${id}/review`);
    const scheduled=c.status==='scheduled'&&c.scheduled_at&&new Date(c.scheduled_at)>new Date();
    const phrase=scheduled?'AGENDAR':'ENVIAR';
    const sender=r.sender?`${escapeHtml(r.sender.name)} &lt;${escapeHtml(r.sender.email)}&gt;`:'Não definido';
    openModal(`<div class="modal-head"><div><h2>Revisão pré-disparo</h2><p class="muted">Confira exatamente quem receberá e como o envio será feito.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="review-hero"><div><span>Campanha</span><strong>${escapeHtml(c.name)}</strong><small>${escapeHtml(c.subject)}</small></div><div><span>${scheduled?'Agendamento':'Operação'}</span><strong>${scheduled?formatDate(c.scheduled_at):(r.live?'ENVIO REAL':'MODO DESENVOLVIMENTO')}</strong><small>${escapeHtml(String(r.provider).toUpperCase())}</small></div></div><div class="review-metrics"><div><span>Público-base</span><strong>${fmt(r.base_audience)}</strong></div><div><span>Suprimidos/excluídos</span><strong>${fmt(r.excluded_total)}</strong></div><div class="highlight"><span>Receberão</span><strong>${fmt(r.eligible)}</strong></div></div><div class="review-grid"><section><h3>Exclusões aplicadas</h3><div class="exclusion-breakdown"><div><span>Status não ativo</span><strong>${fmt(r.exclusions.inactive_status)}</strong></div><div><span>Supressão global</span><strong>${fmt(r.exclusions.suppression||0)}</strong></div><div><span>Listas excluídas</span><strong>${fmt(r.exclusions.lists)}</strong></div><div><span>Segmentos excluídos</span><strong>${fmt(r.exclusions.segments)}</strong></div><div><span>Tags excluídas</span><strong>${fmt(r.exclusions.tags)}</strong></div></div></section><section><h3>Remetente</h3><div class="sender-review"><strong>${sender}</strong><span>${r.sender?.reply_to?`Responder para: ${escapeHtml(r.sender.reply_to)}`:'Sem Reply-To específico'}</span></div></section></div>${reviewIssueList(r.blockers,'blocker')}${reviewIssueList(r.warnings,'warning')}<div class="review-sample"><h3>Amostra da audiência</h3><div>${r.sample.length?r.sample.slice(0,8).map(x=>`<span>${escapeHtml(([x.name,x.last_name].filter(Boolean).join(' '))||x.email)}<small>${escapeHtml(x.email)}</small></span>`).join(''):'Nenhum contato elegível.'}</div></div><div class="confirm-zone"><label>Para confirmar, digite <strong>${phrase}</strong><input id="campaignConfirmPhrase" autocomplete="off" placeholder="${phrase}" ${r.can_send?'':'disabled'}></label><p>${scheduled?`O MailFlow ficará armado para ${formatDate(c.scheduled_at)}.`:`Serão criados ${fmt(r.eligible)} itens na fila de envio.`}</p></div><div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Voltar</button><button class="btn btn-secondary" onclick="sendTest('${id}')">Enviar teste</button><button class="btn btn-primary" id="confirmCampaignSend" ${r.can_send?'':'disabled'}>${scheduled?'Ativar agendamento':'Confirmar envio'}</button></div>`);
    document.getElementById('modal').classList.add('modal-wide');
    const btn=document.getElementById('confirmCampaignSend');
    btn.onclick=async()=>{
      const value=document.getElementById('campaignConfirmPhrase').value.trim().toUpperCase();
      if(value!==phrase){showToast(`Digite ${phrase} para confirmar.`);return;}
      btn.disabled=true;
      try{const result=await request(`/campaigns/${id}/send`,{method:'POST',body:JSON.stringify({review_token:r.review_token,expected_recipients:r.eligible,confirmation:phrase})});closeModal();await refreshData();showToast(result.status==='scheduled'?'Agendamento ativado com sucesso.':`${fmt(result.queued)} e-mails adicionados à fila.`);if(result.status!=='scheduled')setTimeout(()=>viewDeliveries(id),150);}catch(err){btn.disabled=false;showToast(err.message);}
    };
  }catch(err){showToast(err.message);}
};
window.sendCampaign=id=>reviewCampaign(id);
window.sendTest=async id=>{
  const email=prompt('Para qual e-mail deseja enviar o teste?'); if(!email)return;
  try{const result=await request(`/campaigns/${id}/send-test`,{method:'POST',body:JSON.stringify({email:email.trim()})});showToast(result.status==='sent'?(state.deliveryProvider.live?'E-mail de teste enviado.':'Teste processado em modo desenvolvimento.'):`Teste: ${result.status}`);}catch(err){showToast(err.message);}
};
window.pauseCampaign=async id=>{if(!confirm('Pausar esta campanha? Os itens pendentes ficarão preservados na fila.'))return;try{const r=await request(`/campaigns/${id}/pause`,{method:'POST'});await refreshData();showToast(`Campanha pausada. ${fmt(r.pending_jobs)} itens aguardando.`);}catch(err){showToast(err.message);}};
window.resumeCampaign=async id=>{try{const r=await request(`/campaigns/${id}/resume`,{method:'POST'});await refreshData();showToast(r.status==='scheduled'?'Agendamento reativado.':`Envio retomado com ${fmt(r.pending_jobs)} itens pendentes.`);if(r.status==='sending')setTimeout(()=>viewDeliveries(id),120);}catch(err){showToast(err.message);}};
window.cancelCampaign=async id=>{if(!confirm('Cancelar definitivamente esta campanha/agendamento? Os e-mails ainda não processados serão cancelados.'))return;try{const r=await request(`/campaigns/${id}/cancel`,{method:'POST'});await refreshData();showToast(`${r.cancelled_jobs||0} itens pendentes cancelados.`);}catch(err){showToast(err.message);}};

function deliveryModalHtml(c,d){
  return `<div class="modal-head"><div><h2>Acompanhamento do envio</h2><p class="muted">${escapeHtml(c?.name||'Campanha')} • atualização automática enquanto o modal estiver aberto.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="progress-shell"><div class="progress-head"><span>Processamento da fila</span><strong>${String(d.progress_pct||0).replace('.',',')}%</strong></div><div class="progress-track"><span style="width:${Math.min(100,d.progress_pct||0)}%"></span></div><small>${fmt(d.processed)} processados • ${fmt(d.pending)} pendentes • ${fmt(d.cancelled)} cancelados</small></div><div class="delivery-summary"><div><span>Total</span><strong>${fmt(d.total)}</strong></div><div><span>Fila / retry</span><strong>${fmt(d.queued+d.retry+d.processing)}</strong></div><div><span>Enviados</span><strong>${fmt(d.sent+d.delivered)}</strong></div><div><span>Entregues</span><strong>${fmt(d.delivered)}</strong></div><div><span>Bounces</span><strong>${fmt(d.bounced)}</strong></div><div><span>Falhas</span><strong>${fmt(d.failed)}</strong></div></div><div class="table-wrap delivery-table">${d.items.length?`<table><thead><tr><th>Destinatário</th><th>Status</th><th>Tentativas</th><th>ID provedor</th><th>Último evento</th></tr></thead><tbody>${d.items.map(x=>`<tr><td><span class="table-title">${escapeHtml(x.recipient_name||x.recipient_email)}</span><span class="table-sub">${escapeHtml(x.recipient_email)}</span></td><td><span class="badge ${escapeHtml(x.status)}">${escapeHtml(x.status)}</span>${x.last_error?`<span class="table-sub">${escapeHtml(x.last_error)}</span>`:''}</td><td>${x.attempt_count}/${x.max_attempts}</td><td><span class="table-sub">${escapeHtml(x.provider_message_id||'—')}</span></td><td>${escapeHtml(x.last_event_type||'—')}</td></tr>`).join('')}</tbody></table>`:empty('Sem itens','A campanha ainda não foi adicionada à fila.')}</div><div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Fechar</button><button class="btn btn-secondary" onclick="viewDeliveries('${c?.id||''}')">Atualizar agora</button></div>`;
}
window.viewDeliveries=async id=>{
  try{
    const c=state.campaigns.find(x=>x.id===id);
    const d=await request(`/campaigns/${id}/deliveries?limit=100`);
    openModal(deliveryModalHtml(c,d)); document.getElementById('modal').classList.add('modal-wide');
    if(c?.status==='sending'){
      deliveryPollTimer=setInterval(async()=>{try{const latest=await request(`/campaigns/${id}/deliveries?limit=100`);const modal=document.getElementById('modal');if(document.getElementById('modalBackdrop').classList.contains('hidden'))return;modal.innerHTML=deliveryModalHtml(state.campaigns.find(x=>x.id===id),latest);if(latest.pending===0){clearInterval(deliveryPollTimer);deliveryPollTimer=null;await refreshData();}}catch{}},5000);
    }
  }catch(err){showToast(err.message);}
};
function reportMetric(label,value,sub=''){return `<div class="report-kpi"><span>${escapeHtml(label)}</span><strong>${escapeHtml(String(value))}</strong>${sub?`<small>${escapeHtml(sub)}</small>`:''}</div>`;}
window.viewCampaignReport=async id=>{
  try{
    const r=await request(`/campaigns/${id}/report?recipient_limit=100`); const s=r.summary;
    const linkRows=r.links.length?r.links.map(x=>`<tr><td><span class="table-title">${escapeHtml(x.host||'Link')}</span><span class="table-sub report-url">${escapeHtml(x.url)}</span></td><td>${fmt(x.unique_clicks)}</td><td>${fmt(x.total_clicks)}</td><td>${String(x.ctr).replace('.',',')}%</td></tr>`).join(''):'<tr><td colspan="4">Nenhum clique registrado.</td></tr>';
    const recipientRows=r.recipients.length?r.recipients.map(x=>`<tr><td><span class="table-title">${escapeHtml(x.name||x.email)}</span><span class="table-sub">${escapeHtml(x.email)}</span></td><td>${x.delivered_at?'✓':'—'}</td><td>${x.opened_at?`✓ ${fmt(x.open_events)}`:'—'}</td><td>${x.clicked_at?`✓ ${fmt(x.click_events)}`:'—'}</td><td class="report-url">${escapeHtml(x.last_clicked_url||'—')}</td></tr>`).join(''):'<tr><td colspan="5">Nenhum destinatário na fila.</td></tr>';
    openModal(`<div class="modal-head"><div><h2>Relatório • ${escapeHtml(r.campaign_name)}</h2><p class="muted">${escapeHtml(r.subject)}</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="report-kpi-grid">${reportMetric('Enviados',fmt(s.sent))}${reportMetric('Entregues',fmt(s.delivered),`${String(s.delivery_rate).replace('.',',')}%`)}${reportMetric('Aberturas únicas',fmt(s.unique_opens),`${String(s.open_rate).replace('.',',')}% • ${fmt(s.open_events)} eventos`)}${reportMetric('Cliques únicos',fmt(s.unique_clicks),`${String(s.click_rate).replace('.',',')}% • ${fmt(s.click_events)} eventos`)}${reportMetric('CTOR',`${String(s.click_to_open_rate).replace('.',',')}%`,'cliques ÷ aberturas')}${reportMetric('Bounces',fmt(s.bounces),`${String(s.bounce_rate).replace('.',',')}%`)}${reportMetric('Spam',fmt(s.complaints),`${String(s.complaint_rate).replace('.',',')}%`)}</div><div class="report-utm"><strong>UTM:</strong> ${r.utm.enabled?`${escapeHtml(r.utm.source)} / ${escapeHtml(r.utm.medium)} / ${escapeHtml(r.utm.campaign)}`:'desativada'}</div><div class="detail-section"><h3>Links clicados</h3><div class="table-wrap"><table><thead><tr><th>URL</th><th>Cliques únicos</th><th>Cliques totais</th><th>CTR</th></tr></thead><tbody>${linkRows}</tbody></table></div></div><div class="detail-section"><h3>Engajamento por destinatário</h3><div class="table-wrap"><table><thead><tr><th>Contato</th><th>Entregue</th><th>Abriu</th><th>Clicou</th><th>Último link</th></tr></thead><tbody>${recipientRows}</tbody></table></div></div><div class="notice">Aberturas podem ser afetadas por bloqueio de imagens e mecanismos de privacidade dos clientes de e-mail. Cliques tendem a ser um sinal de engajamento mais forte.</div><div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Fechar</button></div>`);
    document.getElementById('modal').classList.add('modal-wide');
  }catch(err){showToast(err.message);}
};
window.previewCampaign=async id=>{try{const result=await request(`/email/campaigns/${id}/render`);openModal(`<div class="modal-head"><div><h2>Prévia da campanha</h2><p class="muted">Renderização final com dados de exemplo.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="render-preview-head"><span>Assunto</span><strong>${escapeHtml(result.subject)}</strong><span>Preheader</span><p>${escapeHtml(result.preheader||'—')}</p></div><div class="mail-preview-stage standalone"><iframe id="standaloneEmailPreview" sandbox="" title="Prévia do e-mail" class="mail-preview-frame"></iframe></div><div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Fechar</button></div>`);document.getElementById('modal').classList.add('modal-wide');document.getElementById('standaloneEmailPreview').srcdoc=result.html;}catch(err){showToast(err.message);}};
document.getElementById('newCampaignBtn').onclick=()=>campaignModal();
document.getElementById('quickCampaignBtn').onclick=()=>campaignModal();
document.getElementById('heroCampaignBtn').onclick=()=>campaignModal();

function templateModal() {
  const base={name:'',type:'Personalizado',subject:'',preheader:'',...emailInitial({})};
  openModal(`<div class="modal-head"><div><h2>Novo template</h2><p class="muted">Crie um modelo reutilizável com o mesmo editor das campanhas.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="templateForm" class="form-grid two"><label>Nome<input name="name" required></label><label>Categoria<input name="type" value="Personalizado"></label><label class="full">Assunto<input name="subject" required></label><label class="full">Preheader<input name="preheader"></label><div class="full"><div class="form-section-title">Conteúdo do template</div><div id="templateEmailEditor"></div></div><div class="modal-footer full"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Salvar template</button></div></form>`);
  document.getElementById('modal').classList.add('modal-wide');
  const form=document.getElementById('templateForm');
  const editor=MailFlowEmailEditor.mount(document.getElementById('templateEmailEditor'),emailInitial(base),{customFields:state.customFields,metadata:()=>({subject:form.elements.subject.value,preheader:form.elements.preheader.value})});
  form.elements.subject.addEventListener('input',()=>editor.setMetadata());form.elements.preheader.addEventListener('input',()=>editor.setMetadata());
  form.addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.target);try{await request('/templates',{method:'POST',body:JSON.stringify({name:f.get('name').trim(),type:f.get('type').trim()||'Personalizado',subject:f.get('subject').trim(),preheader:f.get('preheader').trim(),...editor.getValue()})});editor.destroy();closeModal();await refreshData();showToast('Template criado com conteúdo editável.');}catch(err){showToast(err.message);}});
}
document.getElementById('createTemplateBtn').onclick=templateModal;
window.useTemplate=id=>campaignModal({},state.templates.find(x=>x.id===id));
window.deleteTemplate=async id=>{if(!confirm('Excluir este template?'))return;try{await request(`/templates/${id}`,{method:'DELETE'});await refreshData();showToast('Template excluído.');}catch(err){showToast(err.message);}};

let automationBuilderSteps=[];
function automationStepDefault(type){
  if(type==='send_email') return {type:'send_email',template_id:state.templates[0]?.id||''};
  if(type==='wait') return {type:'wait',amount:1,unit:'days'};
  if(type==='condition') return {type:'condition',rules:[{field:'tag',operator:'contains',value:'',custom_key:null}],match_mode:'all',on_false:'stop'};
  if(type==='add_tag') return {type:'add_tag',tag:''};
  return {type:'remove_tag',tag:''};
}
function renderAutomationTriggerConfig(existing={}){
  const type=document.querySelector('#automationForm [name="trigger_type"]')?.value;
  const box=document.getElementById('automationTriggerConfig'); if(!box)return;
  if(type==='tag_added') box.innerHTML=`<label class="full">Tag que dispara<input name="trigger_tag" value="${escapeHtml(existing.tag||'')}" placeholder="ex.: interessado-pos" required></label>`;
  else if(type==='list_joined') box.innerHTML=`<label class="full">Lista<select name="trigger_list_id" required><option value="">Selecione</option>${state.lists.map(x=>`<option value="${x.id}" ${x.id===existing.list_id?'selected':''}>${escapeHtml(x.name)}</option>`).join('')}</select></label>`;
  else if(type==='email_clicked') box.innerHTML=`<label>Campanha (opcional)<select name="trigger_campaign_id"><option value="">Qualquer campanha</option>${state.campaigns.map(x=>`<option value="${x.id}" ${x.id===existing.campaign_id?'selected':''}>${escapeHtml(x.name)}</option>`).join('')}</select></label><label>URL contém (opcional)<input name="trigger_url_contains" value="${escapeHtml(existing.url_contains||'')}" placeholder="/oferta"></label>`;
  else if(type==='status_changed') box.innerHTML=`<label class="full">Novo status<select name="trigger_status"><option value="">Qualquer status</option>${['active','unsubscribed','bounce','blocked','invalid'].map(x=>`<option value="${x}" ${x===existing.to?'selected':''}>${contactStatus(x)}</option>`).join('')}</select></label>`;
  else box.innerHTML='<p class="muted full">Este gatilho não exige configuração adicional.</p>';
}
function renderAutomationBuilder(){
  const box=document.getElementById('automationStepBuilder'); if(!box)return;
  box.innerHTML=automationBuilderSteps.length?automationBuilderSteps.map((step,i)=>{
    let fields='';
    if(step.type==='send_email') fields=`<label>Template<select onchange="updateAutomationStep(${i},'template_id',this.value)"><option value="">Selecione</option>${state.templates.map(t=>`<option value="${t.id}" ${t.id===step.template_id?'selected':''}>${escapeHtml(t.name)}</option>`).join('')}</select></label>`;
    if(step.type==='wait') fields=`<label>Quantidade<input type="number" min="1" value="${step.amount||1}" onchange="updateAutomationStep(${i},'amount',Number(this.value))"></label><label>Unidade<select onchange="updateAutomationStep(${i},'unit',this.value)">${[['minutes','Minutos'],['hours','Horas'],['days','Dias']].map(([v,l])=>`<option value="${v}" ${step.unit===v?'selected':''}>${l}</option>`).join('')}</select></label>`;
    if(step.type==='condition'){const r=(step.rules||[])[0]||{};fields=`<label>Campo<select onchange="updateAutomationCondition(${i},'field',this.value)">${[['tag','Tag'],['status','Status'],['source','Origem'],['email','E-mail'],['name','Nome'],['phone','Telefone']].map(([v,l])=>`<option value="${v}" ${r.field===v?'selected':''}>${l}</option>`).join('')}</select></label><label>Operador<select onchange="updateAutomationCondition(${i},'operator',this.value)">${[['contains','Contém'],['not_contains','Não contém'],['equals','Igual'],['not_equals','Diferente'],['is_set','Preenchido'],['not_set','Não preenchido']].map(([v,l])=>`<option value="${v}" ${r.operator===v?'selected':''}>${l}</option>`).join('')}</select></label><label>Valor<input value="${escapeHtml(r.value||'')}" onchange="updateAutomationCondition(${i},'value',this.value)"></label><label>Se for falsa<select onchange="updateAutomationStep(${i},'on_false',this.value)"><option value="stop" ${step.on_false==='stop'?'selected':''}>Encerrar fluxo</option><option value="skip_next" ${step.on_false==='skip_next'?'selected':''}>Pular próxima etapa</option></select></label>`;}
    if(step.type==='add_tag'||step.type==='remove_tag') fields=`<label>Tag<input value="${escapeHtml(step.tag||'')}" onchange="updateAutomationStep(${i},'tag',this.value)" placeholder="nome-da-tag"></label>`;
    return `<div class="automation-step-builder"><div class="automation-step-head"><strong>${i+1}. ${escapeHtml(automationStepText(step))}</strong><div><button type="button" class="action-btn" onclick="moveAutomationStep(${i},-1)">↑</button><button type="button" class="action-btn" onclick="moveAutomationStep(${i},1)">↓</button><button type="button" class="action-btn danger-text" onclick="removeAutomationStep(${i})">Excluir</button></div></div><div class="form-grid two">${fields}</div></div>`;
  }).join(''):'<div class="empty"><strong>Nenhuma etapa</strong>Adicione pelo menos uma etapa.</div>';
}
window.updateAutomationStep=(i,key,value)=>{automationBuilderSteps[i][key]=value;renderAutomationBuilder();};
window.updateAutomationCondition=(i,key,value)=>{automationBuilderSteps[i].rules=automationBuilderSteps[i].rules||[{}];automationBuilderSteps[i].rules[0][key]=value;};
window.addAutomationStep=type=>{automationBuilderSteps.push(automationStepDefault(type));renderAutomationBuilder();};
window.removeAutomationStep=i=>{automationBuilderSteps.splice(i,1);renderAutomationBuilder();};
window.moveAutomationStep=(i,dir)=>{const j=i+dir;if(j<0||j>=automationBuilderSteps.length)return;[automationBuilderSteps[i],automationBuilderSteps[j]]=[automationBuilderSteps[j],automationBuilderSteps[i]];renderAutomationBuilder();};
function automationModal(existing=null) {
  const a=existing||{name:'',trigger_type:'contact_created',trigger_config:{},steps:[automationStepDefault('send_email'),automationStepDefault('wait'),automationStepDefault('send_email')],reentry_policy:'once',sender_id:null};
  automationBuilderSteps=JSON.parse(JSON.stringify(a.steps||[]));
  openModal(`<div class="modal-head"><div><h2>${existing?'Editar':'Nova'} automação</h2><p class="muted">Gatilho → ações → esperas → condições, processados pelo worker.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="automationForm" class="form-grid two"><label>Nome<input name="name" value="${escapeHtml(a.name||'')}" required></label><label>Gatilho<select name="trigger_type"><option value="contact_created" ${a.trigger_type==='contact_created'?'selected':''}>Contato entra na base</option><option value="tag_added" ${a.trigger_type==='tag_added'?'selected':''}>Tag adicionada</option><option value="list_joined" ${a.trigger_type==='list_joined'?'selected':''}>Contato entra em lista</option><option value="email_clicked" ${a.trigger_type==='email_clicked'?'selected':''}>Clique em campanha</option><option value="status_changed" ${a.trigger_type==='status_changed'?'selected':''}>Status alterado</option><option value="manual" ${a.trigger_type==='manual'?'selected':''}>Manual</option></select></label><div id="automationTriggerConfig" class="full form-grid two"></div><label>Reentrada<select name="reentry_policy"><option value="once" ${a.reentry_policy==='once'?'selected':''}>Somente uma vez por contato</option><option value="reenter" ${a.reentry_policy==='reenter'?'selected':''}>Permitir novas entradas</option></select></label><label>Remetente<select name="sender_id"><option value="">Remetente padrão</option>${state.senderIdentities.filter(x=>x.active).map(x=>`<option value="${x.id}" ${x.id===a.sender_id?'selected':''}>${escapeHtml(x.name)} &lt;${escapeHtml(x.email)}&gt;</option>`).join('')}</select></label><div class="full"><div class="form-section-title">Etapas</div><div class="automation-add-actions"><button type="button" class="btn btn-secondary" onclick="addAutomationStep('send_email')">+ E-mail</button><button type="button" class="btn btn-secondary" onclick="addAutomationStep('wait')">+ Espera</button><button type="button" class="btn btn-secondary" onclick="addAutomationStep('condition')">+ Condição</button><button type="button" class="btn btn-secondary" onclick="addAutomationStep('add_tag')">+ Adicionar tag</button><button type="button" class="btn btn-secondary" onclick="addAutomationStep('remove_tag')">+ Remover tag</button></div><div id="automationStepBuilder"></div></div><div class="modal-footer full"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Salvar automação</button></div></form>`);
  document.getElementById('modal').classList.add('modal-wide');
  const form=document.getElementById('automationForm');
  renderAutomationTriggerConfig(a.trigger_config||{});renderAutomationBuilder();
  form.elements.trigger_type.addEventListener('change',()=>renderAutomationTriggerConfig({}));
  form.addEventListener('submit',async e=>{e.preventDefault();if(!automationBuilderSteps.length){showToast('Adicione pelo menos uma etapa.');return;}const f=new FormData(form);const type=f.get('trigger_type');let trigger_config={};if(type==='tag_added')trigger_config={tag:(f.get('trigger_tag')||'').trim()};if(type==='list_joined')trigger_config={list_id:f.get('trigger_list_id')};if(type==='email_clicked')trigger_config={campaign_id:f.get('trigger_campaign_id')||'',url_contains:(f.get('trigger_url_contains')||'').trim()};if(type==='status_changed')trigger_config={to:f.get('trigger_status')||''};const payload={name:f.get('name').trim(),trigger_type:type,trigger_config,steps:automationBuilderSteps,reentry_policy:f.get('reentry_policy'),sender_id:f.get('sender_id')||null};try{await request(existing?`/automations/${existing.id}`:'/automations',{method:existing?'PATCH':'POST',body:JSON.stringify(payload)});closeModal();await refreshData();showToast(existing?'Automação atualizada.':'Automação criada.');}catch(err){showToast(err.message);}});
}
document.getElementById('newAutomationBtn').onclick=()=>automationModal();
window.editAutomation=id=>automationModal(state.automations.find(x=>x.id===id));
window.toggleAutomation=async id=>{try{await request(`/automations/${id}/toggle`,{method:'PATCH'});await refreshData();showToast('Status da automação atualizado.');}catch(err){showToast(err.message);}};
window.deleteAutomation=async id=>{if(!confirm('Excluir esta automação?'))return;try{await request(`/automations/${id}`,{method:'DELETE'});await refreshData();showToast('Automação excluída.');}catch(err){showToast(err.message);}};
window.viewAutomationRuns=async id=>{try{const a=state.automations.find(x=>x.id===id);const runs=await request(`/automations/${id}/runs`);openModal(`<div class="modal-head"><div><h2>Execuções • ${escapeHtml(a?.name||'Automação')}</h2><p class="muted">Histórico recente por contato.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="table-wrap">${runs.length?`<table><thead><tr><th>Contato</th><th>Status</th><th>Progresso</th><th>Próxima execução</th><th>Início</th></tr></thead><tbody>${runs.map(r=>`<tr><td>${escapeHtml(r.contact_email||'Contato removido')}</td><td><span class="badge ${r.status==='completed'?'active':r.status==='failed'?'cancelled':'neutral'}">${escapeHtml(r.status)}</span></td><td>${r.current_step}/${r.total_steps}</td><td>${formatDate(r.next_run_at)}</td><td>${formatDate(r.started_at)}</td></tr>`).join('')}</tbody></table>`:empty('Sem execuções','Nenhum contato entrou nesta automação ainda.')}</div>`);document.getElementById('modal').classList.add('modal-wide');}catch(err){showToast(err.message);}};

document.getElementById('workspaceForm').addEventListener('submit',async e=>{
  e.preventDefault();
  if(state.user?.role!=='admin') return;
  try{ state.workspace=await request('/workspace',{method:'PATCH',body:JSON.stringify({name:document.getElementById('workspaceName').value.trim()})}); renderSettings(); showToast('Nome da empresa atualizado.'); }catch(err){showToast(err.message);}
});

function userModal(){
  openModal(`<div class="modal-head"><div><h2>Novo usuário</h2><p class="muted">Crie um acesso dentro do mesmo workspace.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="userForm" class="form-grid"><label>Nome<input name="name" required minlength="2"></label><label>E-mail<input name="email" type="email" required></label><label>Senha inicial<input name="password" type="password" required minlength="8" placeholder="Mínimo 8 caracteres, letra e número"></label><label>Perfil<select name="role"><option value="user">Usuário</option><option value="admin">Administrador</option></select></label><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Criar usuário</button></div></form>`);
  document.getElementById('userForm').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.target);try{await request('/users',{method:'POST',body:JSON.stringify({name:f.get('name').trim(),email:f.get('email').trim(),password:f.get('password'),role:f.get('role')})});closeModal();await refreshData();showToast('Usuário criado.');}catch(err){showToast(err.message);}});
}
document.getElementById('addUserBtn').onclick=userModal;
window.toggleUserRole=async id=>{const u=state.users.find(x=>x.id===id);if(!u)return;try{await request(`/users/${id}`,{method:'PATCH',body:JSON.stringify({role:u.role==='admin'?'user':'admin'})});await refreshData();showToast('Perfil atualizado.');}catch(err){showToast(err.message);}};
window.toggleUserActive=async id=>{const u=state.users.find(x=>x.id===id);if(!u)return;try{await request(`/users/${id}`,{method:'PATCH',body:JSON.stringify({active:!u.active})});await refreshData();showToast('Status atualizado.');}catch(err){showToast(err.message);}};
window.deleteUser=async id=>{if(!confirm('Excluir este usuário e revogar o acesso?'))return;try{await request(`/users/${id}`,{method:'DELETE'});await refreshData();showToast('Usuário removido.');}catch(err){showToast(err.message);}};

document.getElementById('addDomainBtn')?.addEventListener('click',addDomainModal);
document.getElementById('addSenderIdentityBtn')?.addEventListener('click',addSenderIdentityModal);
document.getElementById('addSuppressionBtn')?.addEventListener('click',addSuppressionModal);
document.getElementById('senderForm').addEventListener('submit',async e=>{e.preventDefault();try{state.settings=await request('/settings/sender',{method:'PUT',body:JSON.stringify({sender_name:document.getElementById('senderName').value.trim(),sender_email:document.getElementById('senderEmail').value.trim(),reply_to:document.getElementById('replyTo').value.trim()})});renderSettings();showToast('Identidade salva no banco.');}catch(err){showToast(err.message);}});
document.getElementById('processQueueBtn').addEventListener('click',async()=>{try{const r=await request('/delivery/process-once',{method:'POST'});await refreshData();showToast(`Fila processada: ${r.processed} item(ns), ${r.failed} falha(s).`);}catch(err){showToast(err.message);}});

let pendingImportFile=null;
function openImport(){document.getElementById('csvInput').click();}
document.getElementById('importContactsBtn').onclick=openImport;
document.getElementById('quickImportBtn').onclick=openImport;

function splitCsv(line,sep){const out=[];let cur='';let quoted=false;for(let i=0;i<line.length;i++){const ch=line[i];if(ch==='"'){if(quoted&&line[i+1]==='"'){cur+='"';i++;}else quoted=!quoted;}else if(ch===sep&&!quoted){out.push(cur);cur='';}else cur+=ch;}out.push(cur);return out;}
function normalizeHeader(v){return String(v||'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');}
function autoHeader(headers,aliases){const norm=headers.map(normalizeHeader);const idx=norm.findIndex(h=>aliases.includes(h));return idx>=0?headers[idx]:'';}
function mappingSelect(target,label,headers,aliases=[],required=false){const auto=autoHeader(headers,aliases);return `<label>${escapeHtml(label)}${required?' *':''}<select name="map:${target}" ${required?'required':''}><option value="">Ignorar</option>${headers.map(h=>`<option value="${escapeHtml(h)}" ${h===auto?'selected':''}>${escapeHtml(h)}</option>`).join('')}</select></label>`;}

function importMappingModal(file,headers,sampleRows){
  pendingImportFile=file;
  openModal(`<div class="modal-head"><div><h2>Importar contatos</h2><p class="muted">${escapeHtml(file.name)} • Mapeie as colunas antes de gravar a base.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="import-preview"><strong>Prévia do arquivo</strong><div class="table-wrap"><table><thead><tr>${headers.slice(0,6).map(h=>`<th>${escapeHtml(h)}</th>`).join('')}</tr></thead><tbody>${sampleRows.slice(0,3).map(row=>`<tr>${headers.slice(0,6).map((_,i)=>`<td>${escapeHtml(row[i]||'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div><form id="importForm" class="form-grid two"><div class="form-section-title full">Mapeamento</div>${mappingSelect('email','E-mail',headers,['email','e_mail'],true)}${mappingSelect('name','Nome',headers,['nome','name','primeiro_nome','first_name'])}${mappingSelect('last_name','Sobrenome',headers,['sobrenome','last_name','ultimo_nome'])}${mappingSelect('phone','Telefone',headers,['telefone','phone','celular','whatsapp'])}${mappingSelect('tags','Tags',headers,['tags','tag'])}${mappingSelect('source','Origem',headers,['origem','source','fonte'])}${state.customFields.map(f=>mappingSelect(`custom:${f.key}`,f.label,headers,[normalizeHeader(f.label),f.key])).join('')}<div class="form-section-title full">Regras da importação</div><label>Duplicados existentes<select name="duplicate_strategy"><option value="skip">Ignorar duplicados</option><option value="update">Atualizar contato existente</option></select></label><label>Origem padrão<input name="default_source" value="Importação CSV"></label><label class="full">Tags padrão<input name="default_tags" placeholder="Ex.: conferencia, setembro"></label><div class="notice full">O MailFlow deduplica por e-mail dentro do workspace. Linhas inválidas e e-mails repetidos no mesmo arquivo são ignorados.</div><div class="modal-footer full"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Importar contatos</button></div></form>`);
  document.getElementById('importForm').onsubmit=async e=>{
    e.preventDefault(); const f=new FormData(e.target); const mapping={};
    for(const [k,v] of f.entries()) if(k.startsWith('map:')&&v) mapping[k.slice(4)]=v;
    if(!mapping.email){showToast('Mapeie a coluna de e-mail.');return;}
    const body=new FormData();body.append('file',pendingImportFile);body.append('mapping',JSON.stringify(mapping));body.append('duplicate_strategy',f.get('duplicate_strategy'));body.append('default_source',(f.get('default_source')||'').trim()||'Importação CSV');body.append('default_tags',JSON.stringify((f.get('default_tags')||'').split(',').map(x=>x.trim()).filter(Boolean)));
    try{
      const result=await request('/contacts/import',{method:'POST',body});
      await refreshContactData();
      openModal(`<div class="modal-head"><div><h2>Importação concluída</h2><p class="muted">Resultado processado pelo backend.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="import-result-grid"><div><span>Linhas</span><strong>${fmt(result.rows_found)}</strong></div><div><span>Válidos</span><strong>${fmt(result.valid)}</strong></div><div><span>Criados</span><strong>${fmt(result.created)}</strong></div><div><span>Atualizados</span><strong>${fmt(result.updated)}</strong></div><div><span>Duplicados</span><strong>${fmt(result.duplicates_existing+result.duplicates_in_file)}</strong></div><div><span>Inválidos</span><strong>${fmt(result.invalid)}</strong></div></div>${result.errors.length?`<div class="notice"><strong>Primeiros avisos:</strong><br>${result.errors.map(escapeHtml).join('<br>')}</div>`:''}<div class="modal-footer"><button class="btn btn-primary" onclick="closeModal()">Concluir</button></div>`);
    }catch(err){showToast(err.message);}
  };
}

document.getElementById('csvInput').addEventListener('change',async e=>{
  const file=e.target.files[0]; if(!file)return;
  if(file.size>20*1024*1024){showToast('O CSV excede 20 MB.');e.target.value='';return;}
  const text=await file.text(); const lines=text.split(/\r?\n/).filter(x=>x.trim()).slice(0,8); if(!lines.length){showToast('CSV vazio.');return;}
  const sep=(lines[0].match(/;/g)||[]).length>(lines[0].match(/,/g)||[]).length?';':',';
  const headers=splitCsv(lines[0],sep).map(h=>h.trim());
  if(!headers.length){showToast('CSV sem cabeçalho.');return;}
  const rows=lines.slice(1).map(line=>splitCsv(line,sep));
  e.target.value=''; importMappingModal(file,headers,rows);
});

document.getElementById('exportContactsBtn').onclick=async()=>{
  try{
    const p=appendContactFilters(new URLSearchParams());if(state.selectedContacts.size)p.set('ids',[...state.selectedContacts].join(','));
    const res=await fetch(`${API}/contacts/export?${p.toString()}`,{credentials:'include'});if(!res.ok)throw new Error('Não foi possível exportar os contatos.');
    const blob=await res.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='mailflow-contatos.csv';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);showToast(state.selectedContacts.size?'Contatos selecionados exportados.':'Exportação concluída.');
  }catch(err){showToast(err.message);}
};


// Passo 13 — Eventos e Lançamentos
function eventStatusLabel(status){return ({draft:'Rascunho',planned:'Planejado',live:'Ao vivo',completed:'Concluído',archived:'Arquivado'})[status]||status;}
function eventTypeLabel(type){return ({online_event:'Evento online',conference:'Conferência',webinar:'Webinar',immersion:'Imersão',launch:'Lançamento',class:'Aula',other:'Outro'})[type]||type;}
function eventPhaseLabel(phase){return ({registration:'Inscrição',pre_event:'Pré-evento',live:'Ao vivo',offer:'Oferta',post_event:'Pós-evento'})[phase]||phase;}
function toDateTimeLocal(value){if(!value)return '';const d=new Date(value);if(isNaN(d))return '';const pad=n=>String(n).padStart(2,'0');return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;}
function isoFromLocal(value){if(!value)return null;const d=new Date(value);return isNaN(d)?null:d.toISOString();}
function eventAudienceOptions(type,selected=''){
  if(type==='list') return `<option value="">Selecione uma lista</option>${state.lists.map(x=>`<option value="${x.id}" ${x.id===selected?'selected':''}>${escapeHtml(x.name)}</option>`).join('')}`;
  if(type==='segment') return `<option value="">Selecione um segmento</option>${state.segments.map(x=>`<option value="${x.id}" ${x.id===selected?'selected':''}>${escapeHtml(x.name)}</option>`).join('')}`;
  return '<option value="">Todos os contatos ativos</option>';
}
function eventReadinessHtml(r){
  const blockers=(r?.blockers||[]).map(x=>`<div>${escapeHtml(x)}</div>`).join('');
  const warnings=(r?.warnings||[]).map(x=>`<div>${escapeHtml(x)}</div>`).join('');
  return `${blockers?`<div class="readiness-list"><strong>Bloqueios</strong>${blockers}</div>`:''}${warnings?`<div class="readiness-list warning"><strong>Avisos</strong>${warnings}</div>`:''}`;
}
function renderEvents(){
  const box=document.getElementById('eventGrid'); if(!box)return;
  box.innerHTML=state.events.length?state.events.map(e=>{
    const r=e.readiness||{};const m=e.metrics||{};const ready=r.ready_to_prepare;
    return `<article class="event-card"><div class="event-card-top"><div><span class="badge ${e.effective_status==='live'?'active':e.effective_status==='completed'?'sent':e.effective_status==='planned'?'scheduled':'neutral'}">${escapeHtml(eventStatusLabel(e.effective_status))}</span><span class="event-type">${escapeHtml(eventTypeLabel(e.event_type))}</span><h3>${escapeHtml(e.name)}</h3><p>${escapeHtml(e.audience_label)}</p></div><div class="event-date"><strong>${escapeHtml(formatDate(e.start_at))}</strong><span>até ${escapeHtml(formatDate(e.end_at))}</span></div></div><div class="event-kpis"><span><strong>${fmt(r.communications_enabled)}</strong> comunicações</span><span><strong>${fmt(r.campaigns_prepared)}</strong> preparadas</span><span><strong>${fmt(r.campaigns_armed)}</strong> armadas</span><span><strong>${fmt(m.sent)}</strong> envios</span></div><div class="event-readiness-chip ${ready?'ready':'not-ready'}"><span>${ready?'✓ Estrutura pronta para preparar campanhas':'! Configuração pendente'}</span>${(r.blockers||[]).length?`<small>${escapeHtml(r.blockers[0])}</small>`:''}</div><div class="event-actions"><button class="btn btn-primary" onclick="viewEvent('${e.id}')">Abrir operação</button><button class="btn btn-secondary" onclick="editEvent('${e.id}')">Editar</button><button class="btn btn-secondary" onclick="prepareEventCampaigns('${e.id}',false)">Preparar campanhas</button></div></article>`;
  }).join(''):empty('Nenhum evento cadastrado','Crie um evento para organizar a régua completa de comunicação.');
}

function openEventForm(existing=null){
  const e=existing||{};const audienceType=e.audience_type||'all';
  openModal(`<div class="modal-head"><div><h2>${existing?'Editar evento':'Novo evento'}</h2><p class="muted">O evento organiza cronograma, audiência, oferta e campanhas vinculadas.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="eventForm" class="form-grid two"><label class="full">Nome<input name="name" value="${escapeHtml(e.name||'')}" required></label><label>Tipo<select name="event_type"><option value="online_event">Evento online</option><option value="conference">Conferência</option><option value="webinar">Webinar</option><option value="immersion">Imersão</option><option value="launch">Lançamento</option><option value="class">Aula</option><option value="other">Outro</option></select></label><label>Status<select name="status"><option value="draft">Rascunho</option><option value="planned">Planejado</option><option value="archived">Arquivado</option></select></label><label>Início<input name="start_at" type="datetime-local" value="${toDateTimeLocal(e.start_at)}" required></label><label>Término<input name="end_at" type="datetime-local" value="${toDateTimeLocal(e.end_at)}" required></label><label>Fuso horário<input name="timezone" value="${escapeHtml(e.timezone||'America/Belem')}" required></label><label>Plataforma<input name="platform" value="${escapeHtml(e.platform||'Zoom')}" placeholder="Zoom"></label><label class="full">Link de acesso<input name="access_url" type="url" value="${escapeHtml(e.access_url||'')}" placeholder="https://..."></label><label>Público<select name="audience_type"><option value="all">Todos os ativos</option><option value="list">Lista estática</option><option value="segment">Segmento dinâmico</option></select></label><label>Lista / segmento<select name="audience_id" id="eventAudienceId">${eventAudienceOptions(audienceType,e.audience_id||'')}</select></label><label>Remetente<select name="sender_id"><option value="">Usar remetente padrão</option>${state.senderIdentities.filter(x=>x.active).map(x=>`<option value="${x.id}" ${x.id===e.sender_id?'selected':''}>${escapeHtml(x.name)} &lt;${escapeHtml(x.email)}&gt;</option>`).join('')}</select></label><label>Oferta abre<input name="offer_open_at" type="datetime-local" value="${toDateTimeLocal(e.offer_open_at)}"></label><label>Oferta encerra<input name="offer_close_at" type="datetime-local" value="${toDateTimeLocal(e.offer_close_at)}"></label><label class="full">Descrição<textarea name="description">${escapeHtml(e.description||'')}</textarea></label><label class="full">Notas internas<textarea name="notes">${escapeHtml(e.notes||'')}</textarea></label><div class="notice full">Variáveis disponíveis nos templates preparados pelo evento: <code>{{evento_nome}}</code>, <code>{{evento_inicio}}</code>, <code>{{evento_fim}}</code>, <code>{{evento_link}}</code>, <code>{{evento_plataforma}}</code>, <code>{{oferta_abre}}</code> e <code>{{oferta_fecha}}</code>.</div><div class="modal-footer full"><button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button><button class="btn btn-primary">Salvar evento</button></div></form>`);
  document.getElementById('modal').classList.add('modal-wide');
  const form=document.getElementById('eventForm');form.elements.event_type.value=e.event_type||'online_event';form.elements.status.value=['draft','planned','archived'].includes(e.status)?e.status:'planned';form.elements.audience_type.value=audienceType;
  form.elements.audience_type.onchange=()=>{document.getElementById('eventAudienceId').innerHTML=eventAudienceOptions(form.elements.audience_type.value,'');};
  form.onsubmit=async ev=>{ev.preventDefault();const f=new FormData(form);const type=f.get('audience_type');const payload={name:f.get('name'),event_type:f.get('event_type'),status:f.get('status'),start_at:isoFromLocal(f.get('start_at')),end_at:isoFromLocal(f.get('end_at')),timezone:f.get('timezone'),platform:f.get('platform'),access_url:f.get('access_url'),audience_type:type,audience_id:type==='all'?null:(f.get('audience_id')||null),sender_id:f.get('sender_id')||null,offer_open_at:isoFromLocal(f.get('offer_open_at')),offer_close_at:isoFromLocal(f.get('offer_close_at')),description:f.get('description'),notes:f.get('notes')};try{await request(existing?`/events/${e.id}`:'/events',{method:existing?'PATCH':'POST',body:JSON.stringify(payload)});closeModal();await refreshData();showToast(existing?'Evento atualizado.':'Evento criado.');}catch(err){showToast(err.message);}};
}
window.editEvent=id=>openEventForm(state.events.find(x=>x.id===id));

function communicationStatus(c){if(!c.campaign_id)return 'Sem campanha';if(c.needs_review)return 'Precisa revisar';if(c.campaign_send_armed)return 'Agendada e armada';return c.campaign_status==='scheduled'?'Preparada • revisar':statusLabel(c.campaign_status||'draft');}
window.viewEvent=async id=>{try{const d=await request(`/events/${id}`);const e=d.event;const r=e.readiness;const m=e.metrics;const rows=d.communications.map(c=>`<tr><td><span class="table-title">${escapeHtml(c.name)}</span><span class="table-sub">${escapeHtml(eventPhaseLabel(c.phase))}</span></td><td>${escapeHtml(formatDate(c.scheduled_at))}</td><td>${escapeHtml(c.template_name||'—')}</td><td>${escapeHtml(communicationStatus(c))}</td><td><button class="action-btn" onclick="editEventCommunication('${id}','${c.id}')">Editar</button>${c.campaign_id?`<button class="action-btn primary-action" onclick="closeModal();navigate('campaigns');setTimeout(()=>reviewCampaign('${c.campaign_id}'),0)">Revisar campanha</button>`:''}<button class="action-btn danger-text" onclick="deleteEventCommunication('${id}','${c.id}')">Excluir</button></td></tr>`).join('');openModal(`<div class="modal-head"><div><h2>${escapeHtml(e.name)}</h2><p class="muted">${escapeHtml(eventTypeLabel(e.event_type))} • ${escapeHtml(e.audience_label)} • ${escapeHtml(e.sender_label)}</p></div><button class="modal-close" onclick="closeModal()">×</button></div><div class="event-detail-hero"><div><span>Início</span><strong>${escapeHtml(formatDate(e.start_at))}</strong><small>${escapeHtml(e.timezone)}</small></div><div><span>Plataforma</span><strong>${escapeHtml(e.platform||'—')}</strong><small>${e.access_url?`<a href="${escapeHtml(e.access_url)}" target="_blank" rel="noopener">Abrir link</a>`:'Sem link'}</small></div><div><span>Campanhas preparadas</span><strong>${fmt(r.campaigns_prepared)}/${fmt(r.communications_enabled)}</strong><small>${fmt(r.campaigns_armed)} armadas</small></div><div><span>Resultados</span><strong>${fmt(m.delivered)} entregues</strong><small>${fmt(m.opens)} aberturas • ${fmt(m.clicks)} cliques</small></div></div>${eventReadinessHtml(r)}<div class="event-operation-actions"><button class="btn btn-secondary" onclick="recommendedEventPlan('${id}')">Criar plano sugerido</button><button class="btn btn-secondary" onclick="newEventCommunication('${id}')">+ Comunicação</button><button class="btn btn-primary" onclick="prepareEventCampaigns('${id}',true)">Preparar / sincronizar campanhas</button>${e.audience_type==='list'?`<button class="btn btn-secondary" onclick="eventConfirmationAutomation('${id}')">Confirmação de inscrição</button>`:''}<button class="btn btn-secondary" onclick="editEvent('${id}')">Editar evento</button></div><div class="detail-section"><h3>Cronograma de comunicação</h3><div class="table-wrap">${rows?`<table><thead><tr><th>Comunicação</th><th>Quando</th><th>Template</th><th>Situação</th><th></th></tr></thead><tbody>${rows}</tbody></table>`:empty('Sem comunicações','Use o plano sugerido ou adicione a primeira comunicação.')}</div></div><div class="event-variable-help"><strong>Variáveis do evento</strong><code>{{evento_nome}}</code><code>{{evento_inicio}}</code><code>{{evento_link}}</code><code>{{oferta_fecha}}</code></div><div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Fechar</button><button class="btn btn-secondary danger-text" onclick="deleteEvent('${id}')">Excluir evento</button></div>`);document.getElementById('modal').classList.add('modal-wide');}catch(err){showToast(err.message);}};

window.recommendedEventPlan=async id=>{try{const r=await request(`/events/${id}/recommended-plan`,{method:'POST'});showToast(r.created?`${r.created} comunicações adicionadas ao plano.`:'O plano sugerido já estava criado.');await refreshData();await viewEvent(id);}catch(err){showToast(err.message);}};
window.prepareEventCampaigns=async(id,reopen=true)=>{try{const r=await request(`/events/${id}/prepare-campaigns`,{method:'POST'});const msg=`${r.prepared} criada(s), ${r.updated} atualizada(s), ${r.skipped} ignorada(s), ${r.blocked} bloqueada(s).`;showToast(msg);await refreshData();if(reopen)await viewEvent(id);}catch(err){showToast(err.message);}};
window.deleteEvent=async id=>{if(!confirm('Excluir este evento? Campanhas já preparadas serão mantidas, mas perderão o vínculo com o evento.'))return;try{await request(`/events/${id}`,{method:'DELETE'});closeModal();await refreshData();showToast('Evento excluído.');}catch(err){showToast(err.message);}};

function openCommunicationForm(eventId,comm=null){
  const c=comm||{};openModal(`<div class="modal-head"><div><h2>${comm?'Editar':'Nova'} comunicação</h2><p class="muted">O horário é calculado a partir dos marcos do evento. A campanha só é enviada depois da revisão do Passo 9.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="eventCommunicationForm" class="form-grid two"><label class="full">Nome<input name="name" value="${escapeHtml(c.name||'')}" required></label><label>Fase<select name="phase"><option value="registration">Inscrição</option><option value="pre_event">Pré-evento</option><option value="live">Ao vivo</option><option value="offer">Oferta</option><option value="post_event">Pós-evento</option></select></label><label>Referência<select name="relative_to"><option value="event_start">Início do evento</option><option value="event_end">Fim do evento</option><option value="offer_open">Abertura da oferta</option><option value="offer_close">Encerramento da oferta</option><option value="absolute">Data absoluta</option></select></label><label>Deslocamento em minutos<input name="offset_minutes" type="number" value="${Number(c.offset_minutes||0)}" min="-525600" max="525600"><small>Ex.: -1440 = 24h antes; -60 = 1h antes; 30 = 30 min depois.</small></label><label>Data absoluta<input name="scheduled_at" type="datetime-local" value="${c.relative_to==='absolute'?toDateTimeLocal(c.scheduled_at):''}"></label><label class="full">Template<select name="template_id"><option value="">Selecione depois</option>${state.templates.map(t=>`<option value="${t.id}" ${t.id===c.template_id?'selected':''}>${escapeHtml(t.name)} • ${escapeHtml(t.subject)}</option>`).join('')}</select></label><label class="check-label full"><input name="enabled" type="checkbox" ${c.enabled===false?'':'checked'}> Comunicação habilitada</label><div class="modal-footer full"><button type="button" class="btn btn-secondary" onclick="viewEvent('${eventId}')">Cancelar</button><button class="btn btn-primary">Salvar comunicação</button></div></form>`);
  const form=document.getElementById('eventCommunicationForm');form.elements.phase.value=c.phase||'pre_event';form.elements.relative_to.value=c.relative_to||'event_start';
  form.onsubmit=async ev=>{ev.preventDefault();const f=new FormData(form);const relative=f.get('relative_to');const payload={name:f.get('name'),phase:f.get('phase'),relative_to:relative,offset_minutes:Number(f.get('offset_minutes')||0),scheduled_at:relative==='absolute'?isoFromLocal(f.get('scheduled_at')):null,template_id:f.get('template_id')||null,enabled:f.get('enabled')==='on'};try{await request(comm?`/events/${eventId}/communications/${c.id}`:`/events/${eventId}/communications`,{method:comm?'PATCH':'POST',body:JSON.stringify(payload)});await refreshData();await viewEvent(eventId);showToast('Comunicação salva.');}catch(err){showToast(err.message);}};
}
window.newEventCommunication=id=>openCommunicationForm(id,null);
window.editEventCommunication=async(eventId,commId)=>{try{const d=await request(`/events/${eventId}`);openCommunicationForm(eventId,d.communications.find(x=>x.id===commId));}catch(err){showToast(err.message);}};
window.deleteEventCommunication=async(eventId,commId)=>{if(!confirm('Excluir esta comunicação do plano?'))return;try{await request(`/events/${eventId}/communications/${commId}`,{method:'DELETE'});await refreshData();await viewEvent(eventId);showToast('Comunicação excluída.');}catch(err){showToast(err.message);}};

window.eventConfirmationAutomation=async id=>{const e=state.events.find(x=>x.id===id);if(e?.registration_automation_id){showToast('Este evento já possui automação de confirmação vinculada.');return;}openModal(`<div class="modal-head"><div><h2>Confirmação de inscrição</h2><p class="muted">Cria uma automação “entrou na lista → enviar e-mail”. Ela nasce pausada por padrão para revisão.</p></div><button class="modal-close" onclick="closeModal()">×</button></div><form id="eventConfirmationForm" class="form-grid"><label>Template<select name="template_id" required><option value="">Selecione</option>${state.templates.map(t=>`<option value="${t.id}">${escapeHtml(t.name)} • ${escapeHtml(t.subject)}</option>`).join('')}</select></label><label class="check-label"><input name="active" type="checkbox"> Ativar imediatamente (use apenas se o template e o remetente já foram revisados)</label><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="viewEvent('${id}')">Cancelar</button><button class="btn btn-primary">Criar automação</button></div></form>`);document.getElementById('eventConfirmationForm').onsubmit=async ev=>{ev.preventDefault();const f=new FormData(ev.target);try{await request(`/events/${id}/confirmation-automation`,{method:'POST',body:JSON.stringify({template_id:f.get('template_id'),active:f.get('active')==='on'})});await refreshData();await viewEvent(id);showToast('Automação de confirmação criada.');}catch(err){showToast(err.message);}};};

document.getElementById('newEventBtn')?.addEventListener('click',()=>openEventForm());

async function refreshAnalytics(days=state.analyticsDays||30){
  state.analyticsDays=Number(days)||30;
  state.analytics=await request(`/reports/overview?days=${state.analyticsDays}`);
  renderDashboard(); renderReports();
  return state.analytics;
}

document.getElementById('dashboardPeriod')?.addEventListener('change',async e=>{try{await refreshAnalytics(Number(e.target.value));document.getElementById('reportsPeriod').value=e.target.value;}catch(err){showToast(err.message);}});
document.getElementById('reportsPeriod')?.addEventListener('change',async e=>{try{await refreshAnalytics(Number(e.target.value));document.getElementById('dashboardPeriod').value=e.target.value;}catch(err){showToast(err.message);}});
document.getElementById('refreshReportsBtn')?.addEventListener('click',async()=>{try{await refreshAnalytics();showToast('Relatórios atualizados.');}catch(err){showToast(err.message);}});

async function refreshData(){
  try {
    const [dashboard,analytics,campaigns,templates,automations,events,settings,users,workspace,lists,segments,deliveryProvider,sendingDomains,senderIdentities,deliverability,suppressions,consents]=await Promise.all([request('/dashboard'),request(`/reports/overview?days=${state.analyticsDays||30}`),request('/campaigns'),request('/templates'),request('/automations'),request('/events'),request('/settings/sender'),request('/users'),request('/workspace'),request('/lists'),request('/segments'),request('/delivery/provider'),request('/domains'),request('/senders'),request('/deliverability/status'),request('/suppressions'),request('/privacy/consents')]);
    Object.assign(state,{dashboard,analytics,campaigns,templates,automations,events,settings,users,workspace,lists,segments,deliveryProvider,sendingDomains,senderIdentities,deliverability,suppressions,consents});
    await refreshContacts({meta:true});
    renderAll();
  } catch(err) {
    if(err.message.includes('login') || err.message.includes('sessão') || err.message.includes('expirou')) { showAuth('login'); }
    throw err;
  }
}

const resetTokenFromUrl=new URLSearchParams(window.location.search).get('reset_token');
if(resetTokenFromUrl){
  const tokenField=document.querySelector('#resetForm [name="token"]');
  if(tokenField)tokenField.value=resetTokenFromUrl;
  showAuth('reset');
}else{
  loadAll();
}
