import os
import sys
from pathlib import Path

import pytest
from fastapi import HTTPException

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

# Reuse the integration database initialized by the main test module when the
# whole suite runs. If this file runs alone, initialize its own migrated DB.
TEST_DB = Path('/tmp/mailflow_v15_hardening.db')
if 'DATABASE_URL' not in os.environ:
    if TEST_DB.exists():
        TEST_DB.unlink()
    os.environ['DATABASE_URL'] = f'sqlite:///{TEST_DB}'
    from alembic import command
    from alembic.config import Config
    cfg = Config(str(BACKEND_DIR / 'alembic.ini'))
    cfg.set_main_option('sqlalchemy.url', os.environ['DATABASE_URL'])
    command.upgrade(cfg, 'head')

from app.database import SessionLocal  # noqa: E402
from app.health_service import readiness, record_heartbeat  # noqa: E402
from app.models import ServiceHeartbeat  # noqa: E402
from app.rate_limit import consume, reset  # noqa: E402
from app.security import create_csrf_token, verify_csrf_token  # noqa: E402


def test_signed_csrf_token_is_bound_to_session():
    session_a = 'session-A-super-secret'
    session_b = 'session-B-super-secret'
    token = create_csrf_token(session_a)
    assert verify_csrf_token(session_a, token) is True
    assert verify_csrf_token(session_b, token) is False
    assert verify_csrf_token(session_a, token + 'tampered') is False


def test_database_backed_rate_limit_blocks_and_can_be_reset(monkeypatch):
    monkeypatch.setenv('MAILFLOW_RATE_LIMIT_ENABLED', 'true')
    action = 'pytest_login_account'
    identity = 'rate-limit@example.com'
    with SessionLocal() as db:
        reset(db, action=action, identity=identity)
        consume(db, action=action, identity=identity, limit=2, window_seconds=300, block_seconds=60)
        consume(db, action=action, identity=identity, limit=2, window_seconds=300, block_seconds=60)
        with pytest.raises(HTTPException) as exc:
            consume(db, action=action, identity=identity, limit=2, window_seconds=300, block_seconds=60)
        assert exc.value.status_code == 429
        reset(db, action=action, identity=identity)
        consume(db, action=action, identity=identity, limit=2, window_seconds=300, block_seconds=60)


def test_health_database_and_service_heartbeat():
    record_heartbeat('worker', status='ok', details={'test': True})
    with SessionLocal() as db:
        row = db.get(ServiceHeartbeat, 'worker')
        assert row is not None
        assert row.status == 'ok'
        assert row.details['test'] is True
    ok, checks = readiness()
    assert ok is True
    assert checks['database'] == 'ok'


def test_legacy_scrypt_hash_remains_compatible():
    import hashlib
    password = "SenhaLegada123"
    salt = bytes.fromhex("00112233445566778899aabbccddeeff")
    derived = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)
    encoded = f"scrypt$16384$8$1${salt.hex()}${derived.hex()}"
    from app.security import verify_password
    assert verify_password(password, encoded) is True
    assert verify_password("senha-errada", encoded) is False
