import os
import sys
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

TEST_DB = Path('/tmp/mailflow_v3_pytest.db')
if TEST_DB.exists():
    TEST_DB.unlink()
os.environ['DATABASE_URL'] = f'sqlite:///{TEST_DB}'
os.environ['MAILFLOW_EXPOSE_RESET_TOKEN'] = 'true'
os.environ['MAILFLOW_CSRF_ENABLED'] = 'false'
os.environ['MAILFLOW_ORIGIN_CHECK_ENABLED'] = 'false'
os.environ['MAILFLOW_RATE_LIMIT_ENABLED'] = 'false'

from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402
_cfg = Config(str(BACKEND_DIR / 'alembic.ini'))
_cfg.set_main_option('sqlalchemy.url', os.environ['DATABASE_URL'])
command.upgrade(_cfg, 'head')

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402


def reviewed_send(client, campaign_id):
    review_response = client.get(f"/api/campaigns/{campaign_id}/review")
    assert review_response.status_code == 200, review_response.text
    review = review_response.json()
    campaign = next(x for x in client.get('/api/campaigns').json() if x['id'] == campaign_id)
    from datetime import datetime, timezone
    phrase = 'ENVIAR'
    if campaign['status'] == 'scheduled' and campaign.get('scheduled_at'):
        dt = datetime.fromisoformat(campaign['scheduled_at'].replace('Z', '+00:00'))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        if dt > datetime.now(timezone.utc):
            phrase = 'AGENDAR'
    return client.post(f"/api/campaigns/{campaign_id}/send", json={
        'review_token': review['review_token'],
        'expected_recipients': review['eligible'],
        'confirmation': phrase,
    })


def test_auth_workspace_isolation_team_and_reset():
    with TestClient(app) as company_a, TestClient(app) as company_b:
        ra = company_a.post('/api/auth/register', json={
            'workspace_name': 'Empresa A', 'name': 'Admin A',
            'email': 'admina@example.com', 'password': 'Senha123'
        })
        assert ra.status_code == 201
        workspace_a = ra.json()['workspace']['id']

        rc = company_a.post('/api/contacts', json={
            'name': 'Lead A', 'email': 'lead@example.com', 'tags': ['A'],
            'status': 'active', 'source': 'Teste'
        })
        assert rc.status_code == 201
        contact_a = rc.json()['id']

        rb = company_b.post('/api/auth/register', json={
            'workspace_name': 'Empresa B', 'name': 'Admin B',
            'email': 'adminb@example.com', 'password': 'Senha123'
        })
        assert rb.status_code == 201
        assert rb.json()['workspace']['id'] != workspace_a
        assert company_b.get('/api/contacts').json() == []
        assert company_b.patch(f'/api/contacts/{contact_a}', json={'name': 'Inválido'}).status_code == 404
        assert company_b.delete(f'/api/contacts/{contact_a}').status_code == 404

        ru = company_a.post('/api/users', json={
            'name': 'Operador A', 'email': 'operador@example.com',
            'password': 'Operador123', 'role': 'user'
        })
        assert ru.status_code == 201

        with TestClient(app) as operator:
            assert operator.post('/api/auth/login', json={
                'email': 'operador@example.com', 'password': 'Operador123'
            }).status_code == 200
            assert len(operator.get('/api/contacts').json()) == 1
            assert operator.post('/api/users', json={
                'name': 'Proibido', 'email': 'blocked@example.com',
                'password': 'Senha123', 'role': 'user'
            }).status_code == 403

        forgot = company_a.post('/api/auth/forgot-password', json={'email': 'admina@example.com'})
        token = forgot.json()['reset_token']
        assert token
        assert company_a.post('/api/auth/reset-password', json={
            'token': token, 'new_password': 'NovaSenha456'
        }).status_code == 200
        assert company_a.get('/api/auth/me').status_code == 401
        assert company_a.post('/api/auth/login', json={
            'email': 'admina@example.com', 'password': 'Senha123'
        }).status_code == 401
        assert company_a.post('/api/auth/login', json={
            'email': 'admina@example.com', 'password': 'NovaSenha456'
        }).status_code == 200


def test_contacts_module_step4_end_to_end():
    import json

    with TestClient(app) as client:
        register = client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Passo 4', 'name': 'Admin Contatos',
            'email': 'passo4admin@example.com', 'password': 'Senha123'
        })
        assert register.status_code == 201

        custom = client.post('/api/contacts/custom-fields', json={
            'label': 'Cidade', 'field_type': 'text'
        })
        assert custom.status_code == 201
        city_key = custom.json()['key']

        c1 = client.post('/api/contacts', json={
            'name': 'Ana', 'last_name': 'Silva', 'email': 'ana@example.com',
            'phone': '91999990000', 'tags': ['Conferência'], 'status': 'active',
            'source': 'Meta Ads', 'custom_fields': {city_key: 'Belém'}
        })
        assert c1.status_code == 201
        c1_id = c1.json()['id']

        c2 = client.post('/api/contacts', json={
            'name': 'Bruno', 'email': 'bruno@example.com', 'tags': ['Lead'],
            'status': 'active', 'source': 'Orgânico'
        })
        assert c2.status_code == 201
        c2_id = c2.json()['id']

        search = client.get('/api/contacts/search', params={'tag': 'Conferência', 'page': 1, 'page_size': 10})
        assert search.status_code == 200
        assert search.json()['total'] == 1
        assert search.json()['items'][0]['email'] == 'ana@example.com'

        custom_search = client.get('/api/contacts/search', params={'custom_key': city_key, 'custom_value': 'bel'})
        assert custom_search.status_code == 200
        assert custom_search.json()['total'] == 1

        bulk = client.post('/api/contacts/bulk', json={
            'ids': [c1_id, c2_id], 'action': 'add_tags', 'tags': ['Comprador']
        })
        assert bulk.status_code == 200
        assert bulk.json()['affected'] == 2

        detail = client.get(f'/api/contacts/{c1_id}')
        assert detail.status_code == 200
        descriptions = [x['description'] for x in detail.json()['history']]
        assert any('Tags adicionadas' in d for d in descriptions)
        assert any('Contato criado manualmente' in d for d in descriptions)

        csv_data = 'nome;email;cidade;tags\nCarla;carla@example.com;Santarém;Evento\nAna Atualizada;ana@example.com;Ananindeua;VIP\nRepetida;carla@example.com;X;Y\nInválido;email-invalido;X;Y\n'
        mapping = {
            'name': 'nome', 'email': 'email', 'tags': 'tags', f'custom:{city_key}': 'cidade'
        }
        imported = client.post(
            '/api/contacts/import',
            files={'file': ('contatos.csv', csv_data.encode('utf-8'), 'text/csv')},
            data={
                'mapping': json.dumps(mapping), 'duplicate_strategy': 'update',
                'default_tags': json.dumps(['Setembro']), 'default_source': 'CSV Teste'
            },
        )
        assert imported.status_code == 200, imported.text
        result = imported.json()
        assert result['created'] == 1
        assert result['updated'] == 1
        assert result['duplicates_in_file'] == 1
        assert result['invalid'] == 1

        ana = client.get(f'/api/contacts/{c1_id}').json()['contact']
        assert ana['name'] == 'Ana Atualizada'
        assert 'VIP' in ana['tags']
        assert 'Setembro' in ana['tags']
        assert ana['custom_fields'][city_key] == 'Ananindeua'

        stats = client.get('/api/contacts/stats')
        assert stats.status_code == 200
        assert stats.json()['total'] == 3

        exported = client.get('/api/contacts/export', params={'tag': 'Comprador'})
        assert exported.status_code == 200
        assert 'text/csv' in exported.headers['content-type']
        export_text = exported.content.decode('utf-8-sig')
        assert 'ana@example.com' in export_text
        assert 'bruno@example.com' in export_text
        assert 'carla@example.com' not in export_text


def test_lists_segments_and_campaign_audience_step5():
    with TestClient(app) as client, TestClient(app) as outsider:
        assert client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Segmentos', 'name': 'Admin Segmentos',
            'email': 'segmentos@example.com', 'password': 'Senha123'
        }).status_code == 201

        contacts = []
        payloads = [
            {'name': 'Ana', 'email': 'ana-seg@example.com', 'tags': ['conferencia-setembro'], 'status': 'active', 'source': 'Meta Ads'},
            {'name': 'Bruno', 'email': 'bruno-seg@example.com', 'tags': ['conferencia-setembro', 'comprador'], 'status': 'active', 'source': 'Meta Ads'},
            {'name': 'Carla', 'email': 'carla-seg@example.com', 'tags': ['conferencia-setembro'], 'status': 'unsubscribed', 'source': 'Orgânico'},
            {'name': 'Diego', 'email': 'diego-seg@example.com', 'tags': ['lead'], 'status': 'active', 'source': 'Orgânico'},
        ]
        for payload in payloads:
            response = client.post('/api/contacts', json=payload)
            assert response.status_code == 201, response.text
            contacts.append(response.json())

        static_list = client.post('/api/lists', json={
            'name': 'VIP Conferência', 'description': 'Público escolhido manualmente.'
        })
        assert static_list.status_code == 201
        list_id = static_list.json()['id']
        added = client.post(f'/api/lists/{list_id}/members', json={
            'contact_ids': [contacts[0]['id'], contacts[2]['id']]
        })
        assert added.status_code == 200
        assert added.json()['affected'] == 2
        lists = client.get('/api/lists').json()
        assert lists[0]['member_count'] == 2
        assert lists[0]['active_member_count'] == 1

        ana_detail = client.get(f"/api/contacts/{contacts[0]['id']}").json()
        assert any("Adicionado à lista 'VIP Conferência'" in e['description'] for e in ana_detail['history'])

        rules = [
            {'field': 'tag', 'operator': 'contains', 'value': 'conferencia-setembro'},
            {'field': 'status', 'operator': 'equals', 'value': 'active'},
            {'field': 'tag', 'operator': 'not_contains', 'value': 'comprador'},
        ]
        preview = client.post('/api/segments/preview', json={'match_mode': 'all', 'rules': rules})
        assert preview.status_code == 200, preview.text
        assert preview.json()['matching_count'] == 1
        assert preview.json()['active_count'] == 1
        assert preview.json()['sample'][0]['email'] == 'ana-seg@example.com'

        segment = client.post('/api/segments', json={
            'name': 'Interessados não compradores',
            'description': 'Conferência, ativos e ainda não compradores.',
            'match_mode': 'all', 'rules': rules,
        })
        assert segment.status_code == 201, segment.text
        segment_id = segment.json()['id']
        assert segment.json()['active_count'] == 1

        campaign = client.post('/api/campaigns', json={
            'name': 'Oferta Conferência', 'subject': 'Condição especial',
            'body': 'Conteúdo', 'audience_type': 'segment', 'audience_id': segment_id,
        })
        assert campaign.status_code == 201, campaign.text
        campaign_id = campaign.json()['id']
        assert campaign.json()['segment'] == 'Segmento: Interessados não compradores'
        audience = client.get(f'/api/campaigns/{campaign_id}/audience')
        assert audience.status_code == 200
        assert audience.json()['count'] == 1
        sent = client.post(f'/api/campaigns/{campaign_id}/simulate-send')
        assert sent.status_code == 200
        assert sent.json()['sent'] == 1

        list_campaign = client.post('/api/campaigns', json={
            'name': 'Lista VIP', 'subject': 'Olá VIP', 'body': 'Conteúdo',
            'audience_type': 'list', 'audience_id': list_id,
        })
        assert list_campaign.status_code == 201
        assert client.get(f"/api/campaigns/{list_campaign.json()['id']}/audience").json()['count'] == 1

        # O segmento é dinâmico: ao virar comprador, Ana sai automaticamente do público.
        ana = contacts[0]
        changed = client.patch(f"/api/contacts/{ana['id']}", json={'tags': ['conferencia-setembro', 'comprador']})
        assert changed.status_code == 200
        refreshed = client.get(f'/api/segments/{segment_id}/preview')
        assert refreshed.status_code == 200
        assert refreshed.json()['matching_count'] == 0
        assert refreshed.json()['active_count'] == 0

        # Isolamento entre workspaces vale também para listas e segmentos.
        assert outsider.post('/api/auth/register', json={
            'workspace_name': 'Outra Empresa', 'name': 'Outro Admin',
            'email': 'outra-seg@example.com', 'password': 'Senha123'
        }).status_code == 201
        assert outsider.get('/api/lists').json() == []
        assert outsider.get('/api/segments').json() == []
        assert outsider.post(f'/api/lists/{list_id}/members', json={'contact_ids': [contacts[3]['id']]}).status_code == 404
        assert outsider.get(f'/api/segments/{segment_id}/preview').status_code == 404


def test_email_editor_step6_visual_html_templates_and_variables():
    with TestClient(app) as client:
        assert client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Editor', 'name': 'Admin Editor',
            'email': 'editor@example.com', 'password': 'Senha123'
        }).status_code == 201

        contact = client.post('/api/contacts', json={
            'name': 'Maria', 'last_name': 'Souza', 'email': 'maria-editor@example.com',
            'status': 'active', 'source': 'Teste', 'custom_fields': {'cidade': 'Belém'}
        })
        assert contact.status_code == 201
        contact_id = contact.json()['id']

        blocks = [
            {'type': 'heading', 'data': {'text': 'Olá, {{nome|amigo}}!', 'level': 'h2', 'align': 'center', 'font_size': 30, 'color': '#16181d'}},
            {'type': 'text', 'data': {'text': 'Você está em {{cidade}}.', 'align': 'left', 'font_size': 16, 'color': '#3f4350'}},
            {'type': 'button', 'data': {'text': 'Clique em saiba mais', 'url': 'https://example.com', 'align': 'center', 'bg_color': '#2427d8', 'text_color': '#ffffff', 'radius': 8}},
        ]
        campaign = client.post('/api/campaigns', json={
            'name': 'Campanha Editor Visual',
            'subject': 'Convite para {{nome|você}}',
            'preheader': 'Uma mensagem da {{empresa}}',
            'editor_mode': 'visual',
            'design_json': blocks,
            'audience_type': 'all',
        })
        assert campaign.status_code == 201, campaign.text
        data = campaign.json()
        assert data['editor_mode'] == 'visual'
        assert len(data['design_json']) == 3
        assert '<table' in data['html_body'].lower()
        assert 'Clique em saiba mais' in data['body']

        rendered = client.get(f"/api/email/campaigns/{data['id']}/render", params={'contact_id': contact_id})
        assert rendered.status_code == 200, rendered.text
        rendered_data = rendered.json()
        assert rendered_data['subject'] == 'Convite para Maria'
        assert 'Empresa Editor' in rendered_data['preheader']
        assert 'Olá, Maria!' in rendered_data['html']
        assert 'Você está em Belém.' in rendered_data['html']

        preview = client.post('/api/email/preview', json={
            'subject': 'Oi {{nome|pessoa}}',
            'preheader': 'Teste',
            'editor_mode': 'visual',
            'design_json': [{'type': 'text', 'data': {'text': 'Olá {{nome|pessoa}}'}}],
            'sample': {'name': ''},
        })
        assert preview.status_code == 200
        assert preview.json()['subject'] == 'Oi pessoa'
        assert 'Olá pessoa' in preview.json()['html']

        html_campaign = client.post('/api/campaigns', json={
            'name': 'Campanha HTML', 'subject': 'HTML para {{nome|você}}',
            'editor_mode': 'html',
            'html_body': '<div><h1>Olá {{nome|você}}</h1><p>Conteúdo HTML livre.</p></div>',
            'audience_type': 'all',
        })
        assert html_campaign.status_code == 201, html_campaign.text
        html_data = html_campaign.json()
        assert html_data['editor_mode'] == 'html'
        assert '<!doctype html>' in html_data['html_body'].lower()
        assert 'Conteúdo HTML livre.' in html_data['body']
        assert 'Olá Maria' in client.get(f"/api/email/campaigns/{html_data['id']}/render", params={'contact_id': contact_id}).json()['html']

        template = client.post('/api/templates', json={
            'name': 'Convite Visual', 'type': 'Evento', 'subject': 'Seu convite, {{nome|Olá}}',
            'preheader': 'Template do editor', 'editor_mode': 'visual', 'design_json': blocks,
        })
        assert template.status_code == 201, template.text
        tdata = template.json()
        assert tdata['editor_mode'] == 'visual'
        assert len(tdata['design_json']) == 3
        assert '<table' in tdata['html_body'].lower()


def test_delivery_step7_queue_worker_resend_contract_and_webhooks():
    import base64
    import hashlib
    import hmac
    import json
    import time
    from datetime import datetime, timedelta, timezone
    from unittest.mock import patch

    from app.database import SessionLocal
    from app.email_provider import ResendProvider
    from app.models import EmailDelivery

    os.environ['MAIL_PROVIDER'] = 'console'

    with TestClient(app) as client:
        assert client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Entrega', 'name': 'Admin Entrega',
            'email': 'entrega@example.com', 'password': 'Senha123'
        }).status_code == 201
        assert client.put('/api/settings/sender', json={
            'sender_name': 'Empresa Entrega', 'sender_email': 'mail@example.com', 'reply_to': 'reply@example.com'
        }).status_code == 200

        recipients = []
        for name, email in [('Ana', 'ana-delivery@example.com'), ('Bruno', 'bruno-delivery@example.com')]:
            r = client.post('/api/contacts', json={
                'name': name, 'email': email, 'status': 'active', 'source': 'Teste'
            })
            assert r.status_code == 201, r.text
            recipients.append(r.json())
        assert client.post('/api/contacts', json={
            'name': 'Fora', 'email': 'fora-delivery@example.com', 'status': 'unsubscribed', 'source': 'Teste'
        }).status_code == 201

        campaign = client.post('/api/campaigns', json={
            'name': 'Campanha Entrega', 'subject': 'Olá {{nome}}',
            'editor_mode': 'html', 'html_body': '<p>Mensagem para {{nome}}</p>',
            'audience_type': 'all', 'status': 'draft'
        })
        assert campaign.status_code == 201, campaign.text
        campaign_id = campaign.json()['id']

        provider = client.get('/api/delivery/provider')
        assert provider.status_code == 200
        assert provider.json()['provider'] == 'console'
        assert provider.json()['live'] is False

        queued = reviewed_send(client, campaign_id)
        assert queued.status_code == 200, queued.text
        assert queued.json()['queued'] == 2
        assert queued.json()['status'] == 'sending'

        deliveries = client.get(f'/api/campaigns/{campaign_id}/deliveries').json()
        assert deliveries['total'] == 2
        assert deliveries['queued'] == 2
        assert deliveries['items'][0]['subject_snapshot'].startswith('Olá') if 'subject_snapshot' in deliveries['items'][0] else True

        processed = client.post('/api/delivery/process-once')
        assert processed.status_code == 200, processed.text
        assert processed.json()['processed'] == 2
        refreshed = next(x for x in client.get('/api/campaigns').json() if x['id'] == campaign_id)
        assert refreshed['status'] == 'sent'
        assert refreshed['sent'] == 2
        assert refreshed['delivered'] == 0

        after = client.get(f'/api/campaigns/{campaign_id}/deliveries').json()
        assert after['sent'] == 2
        assert all(x['provider_message_id'].startswith('console_') for x in after['items'])
        assert all(x['attempt_count'] == 1 for x in after['items'])

        test_send = client.post(f'/api/campaigns/{campaign_id}/send-test', json={'email': 'teste@example.com'})
        assert test_send.status_code == 200, test_send.text
        assert test_send.json()['is_test'] is True
        assert test_send.json()['status'] == 'sent'

        future = datetime.now(timezone.utc) + timedelta(hours=1)
        scheduled = client.post('/api/campaigns', json={
            'name': 'Agendada Segura', 'subject': 'Depois', 'body': 'Mensagem',
            'status': 'scheduled', 'scheduled_at': future.isoformat(), 'audience_type': 'all'
        })
        assert scheduled.status_code == 201
        sid = scheduled.json()['id']
        armed = reviewed_send(client, sid)
        assert armed.status_code == 200
        assert armed.json()['status'] == 'scheduled'
        current = next(x for x in client.get('/api/campaigns').json() if x['id'] == sid)
        assert current['send_armed'] is True
        scheduled_deliveries = client.get(f'/api/campaigns/{sid}/deliveries').json()
        assert scheduled_deliveries['total'] == 2
        assert scheduled_deliveries['queued'] == 2
        cancelled = client.post(f'/api/campaigns/{sid}/cancel')
        assert cancelled.status_code == 200

        # Contrato do provider Resend sem internet: payload e Idempotency-Key são validados via mock.
        os.environ['RESEND_API_KEY'] = 're_test_key'
        resend = ResendProvider()
        class FakeResponse:
            status_code = 200
            def json(self): return {'id': 'resend_mock_id'}
            text = ''
        with patch('app.email_provider.httpx.post', return_value=FakeResponse()) as post:
            result = resend.send(
                from_name='Empresa', from_email='mail@example.com', to_email='dest@example.com',
                subject='Assunto', html='<p>HTML</p>', text='Texto', reply_to='reply@example.com',
                idempotency_key='campaign/x/contact/y'
            )
            assert result.message_id == 'resend_mock_id'
            kwargs = post.call_args.kwargs
            assert kwargs['headers']['Idempotency-Key'] == 'campaign/x/contact/y'
            assert kwargs['json']['to'] == ['dest@example.com']
            assert kwargs['json']['reply_to'] == 'reply@example.com'
        os.environ.pop('RESEND_API_KEY', None)

        # Simula callbacks assinados do Resend em dois itens já processados.
        secret_bytes = b'segredo-webhook-mailflow'
        os.environ['RESEND_WEBHOOK_SECRET'] = 'whsec_' + base64.b64encode(secret_bytes).decode('ascii')
        with SessionLocal() as db:
            jobs = list(db.query(EmailDelivery).filter(
                EmailDelivery.campaign_id == campaign_id,
                EmailDelivery.is_test.is_(False),
            ).order_by(EmailDelivery.recipient_email.asc()))
            jobs[0].provider = 'resend'; jobs[0].provider_message_id = 'resend_delivery_1'
            jobs[1].provider = 'resend'; jobs[1].provider_message_id = 'resend_delivery_2'
            db.commit()

        def signed_post(event_id, payload):
            raw = json.dumps(payload, separators=(',', ':')).encode('utf-8')
            ts = str(int(time.time()))
            signed = f'{event_id}.{ts}.'.encode('utf-8') + raw
            sig = base64.b64encode(hmac.new(secret_bytes, signed, hashlib.sha256).digest()).decode('ascii')
            return client.post('/api/webhooks/resend', content=raw, headers={
                'content-type': 'application/json', 'svix-id': event_id,
                'svix-timestamp': ts, 'svix-signature': f'v1,{sig}'
            })

        delivered = signed_post('evt_delivered_1', {'type': 'email.delivered', 'data': {'email_id': 'resend_delivery_1'}})
        assert delivered.status_code == 200, delivered.text
        assert delivered.json()['processed'] is True
        duplicate = signed_post('evt_delivered_1', {'type': 'email.delivered', 'data': {'email_id': 'resend_delivery_1'}})
        assert duplicate.status_code == 200
        assert duplicate.json()['duplicate'] is True

        opened = signed_post('evt_open_1', {'type': 'email.opened', 'data': {'email_id': 'resend_delivery_1'}})
        clicked = signed_post('evt_click_1', {'type': 'email.clicked', 'data': {'email_id': 'resend_delivery_1'}})
        assert opened.status_code == 200 and clicked.status_code == 200

        bounced = signed_post('evt_bounce_2', {'type': 'email.bounced', 'data': {'email_id': 'resend_delivery_2'}})
        assert bounced.status_code == 200, bounced.text
        metrics = next(x for x in client.get('/api/campaigns').json() if x['id'] == campaign_id)
        assert metrics['delivered'] == 1
        assert metrics['opens'] == 1
        assert metrics['clicks'] == 1
        assert metrics['bounces'] == 1
        bounced_contact = client.get(f"/api/contacts/{recipients[1]['id']}").json()['contact']
        assert bounced_contact['status'] == 'bounce'
        history = client.get(f"/api/contacts/{recipients[1]['id']}").json()['history']
        assert any('bounce pelo provedor' in event['description'] for event in history)

        bad = client.post('/api/webhooks/resend', content=b'{}', headers={
            'content-type': 'application/json', 'svix-id': 'evt_bad',
            'svix-timestamp': str(int(time.time())), 'svix-signature': 'v1,invalida'
        })
        assert bad.status_code == 400
        os.environ.pop('RESEND_WEBHOOK_SECRET', None)


def test_delivery_step7_retry_then_success():
    from unittest.mock import patch
    from app.email_provider import ProviderError, ProviderResult

    os.environ['MAIL_PROVIDER'] = 'console'
    os.environ['MAILFLOW_RETRY_BASE_SECONDS'] = '0'

    with TestClient(app) as client:
        assert client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Retry', 'name': 'Admin Retry',
            'email': 'retry@example.com', 'password': 'Senha123'
        }).status_code == 201
        assert client.post('/api/contacts', json={
            'name': 'Lead Retry', 'email': 'lead-retry@example.com', 'status': 'active', 'source': 'Teste'
        }).status_code == 201
        campaign = client.post('/api/campaigns', json={
            'name': 'Retry', 'subject': 'Teste retry', 'body': 'Mensagem', 'audience_type': 'all'
        }).json()
        assert reviewed_send(client, campaign['id']).status_code == 200

        class FlakyProvider:
            name = 'console'
            configured = True
            live = False
            calls = 0
            def send(self, **kwargs):
                self.calls += 1
                if self.calls == 1:
                    raise ProviderError('falha temporária', retryable=True, status_code=503)
                return ProviderResult(message_id='retry_success_id', raw={'id': 'retry_success_id'})

        flaky = FlakyProvider()
        with patch('app.delivery_service.get_provider', return_value=flaky):
            first = client.post('/api/delivery/process-once')
            assert first.status_code == 200
            delivery = client.get(f"/api/campaigns/{campaign['id']}/deliveries").json()['items'][0]
            assert delivery['status'] == 'retry'
            assert delivery['attempt_count'] == 1
            assert 'temporária' in delivery['last_error']

            second = client.post('/api/delivery/process-once')
            assert second.status_code == 200
            delivery = client.get(f"/api/campaigns/{campaign['id']}/deliveries").json()['items'][0]
            assert delivery['status'] == 'sent'
            assert delivery['attempt_count'] == 2
            assert delivery['provider_message_id'] == 'retry_success_id'

    os.environ.pop('MAILFLOW_RETRY_BASE_SECONDS', None)


def test_deliverability_step8_domain_dns_sender_and_live_blocker():
    from unittest.mock import patch

    os.environ['MAIL_PROVIDER'] = 'resend'
    os.environ['RESEND_API_KEY'] = 're_step8_test'

    class FakeResponse:
        def __init__(self, data, status_code=200):
            self._data = data
            self.status_code = status_code
            self.text = ''
            self.content = b'{}'
        def json(self):
            return self._data

    domain_payload = {
        'id': 'dom_step8_verified',
        'name': 'mail.example.com',
        'status': 'verified',
        'region': 'sa-east-1',
        'open_tracking': True,
        'click_tracking': True,
        'tracking_subdomain': 'links',
        'records': [
            {'record': 'SPF', 'name': 'send', 'type': 'MX', 'value': 'feedback-smtp.sa-east-1.amazonses.com', 'status': 'verified', 'ttl': 'Auto', 'priority': 10},
            {'record': 'SPF', 'name': 'send', 'type': 'TXT', 'value': 'v=spf1 include:amazonses.com ~all', 'status': 'verified', 'ttl': 'Auto'},
            {'record': 'DKIM', 'name': 'resend._domainkey', 'type': 'TXT', 'value': 'p=publickey', 'status': 'verified', 'ttl': 'Auto'},
            {'record': 'Tracking', 'name': 'links.mail.example.com', 'type': 'CNAME', 'value': 'links1.resend-dns.com', 'status': 'verified', 'ttl': 'Auto'},
        ],
    }
    calls = []
    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs.get('json')))
        if method == 'POST' and url.endswith('/domains'):
            return FakeResponse(domain_payload)
        if method == 'PATCH':
            return FakeResponse({'object': 'domain', 'id': 'dom_step8_verified'})
        if method == 'GET':
            return FakeResponse(domain_payload)
        if method == 'POST' and url.endswith('/verify'):
            return FakeResponse({'object': 'domain', 'id': 'dom_step8_verified'})
        raise AssertionError((method, url))

    with patch('app.domain_provider.httpx.request', side_effect=fake_request), \
         patch('app.deliverability.check_dmarc_dns', return_value={
             'status': 'valid', 'values': ['v=DMARC1; p=none;'], 'policy': 'none', 'error': ''
         }):
        with TestClient(app) as client:
            assert client.post('/api/auth/register', json={
                'workspace_name': 'Empresa Domínio', 'name': 'Admin Domínio',
                'email': 'dominio@example.com', 'password': 'Senha123'
            }).status_code == 201

            blocked = client.get('/api/deliverability/status').json()
            assert blocked['live_send_ready'] is False
            assert blocked['blockers']

            created = client.post('/api/domains', json={
                'name': 'mail.example.com', 'region': 'sa-east-1',
                'custom_return_path': 'send', 'tracking_subdomain': 'links',
                'open_tracking': True, 'click_tracking': True,
                'tls_mode': 'enforced', 'dmarc_policy': 'none',
                'dmarc_report_email': 'dmarc@example.com',
            })
            assert created.status_code == 201, created.text
            domain = created.json()
            assert domain['provider_domain_id'] == 'dom_step8_verified'
            assert domain['spf_status'] == 'verified'
            assert domain['dkim_status'] == 'verified'
            assert domain['dmarc_status'] == 'valid'
            assert domain['ready_for_sending'] is True
            assert 'rua=mailto:dmarc@example.com' in domain['dmarc_value']

            create_call = next(x for x in calls if x[0] == 'POST' and x[1].endswith('/domains'))
            assert create_call[2]['custom_return_path'] == 'send'
            assert create_call[2]['tracking_subdomain'] == 'links'
            patch_call = next(x for x in calls if x[0] == 'PATCH')
            assert patch_call[2]['tls'] == 'enforced'

            mismatch = client.post('/api/senders', json={
                'domain_id': domain['id'], 'name': 'Errado', 'email': 'contato@example.com', 'is_default': True
            })
            assert mismatch.status_code == 422

            sender = client.post('/api/senders', json={
                'domain_id': domain['id'], 'name': 'Empresa Domínio',
                'email': 'campanhas@mail.example.com', 'reply_to': 'suporte@example.com', 'is_default': True
            })
            assert sender.status_code == 201, sender.text
            assert sender.json()['status'] == 'verified'
            assert sender.json()['is_default'] is True

            ready = client.get('/api/deliverability/status').json()
            assert ready['live_send_ready'] is True
            assert ready['ready_domains'] == 1
            assert ready['ready_sender_identities'] == 1
            assert ready['bulk_marketing_ready'] is False

            assert client.post('/api/contacts', json={
                'name': 'Lead', 'email': 'lead-step8@example.com', 'status': 'active', 'source': 'Teste'
            }).status_code == 201
            campaign = client.post('/api/campaigns', json={
                'name': 'Campanha Live', 'subject': 'Teste', 'body': 'Mensagem', 'audience_type': 'all'
            }).json()
            queued = reviewed_send(client, campaign['id'])
            assert queued.status_code == 200, queued.text
            assert queued.json()['queued'] == 1
            delivery = client.get(f"/api/campaigns/{campaign['id']}/deliveries").json()['items'][0]
            # O snapshot do job usa a identidade verificada, não o fallback antigo.
            from app.database import SessionLocal
            from app.models import EmailDelivery
            with SessionLocal() as db:
                job = db.get(EmailDelivery, delivery['id'])
                assert job.sender_email_snapshot == 'campanhas@mail.example.com'
                assert job.sender_name_snapshot == 'Empresa Domínio'

    os.environ['MAIL_PROVIDER'] = 'console'
    os.environ.pop('RESEND_API_KEY', None)


def test_deliverability_step8_dmarc_missing_blocks_live_send():
    from unittest.mock import patch
    from app.database import SessionLocal
    from app.models import SenderIdentity, SendingDomain

    os.environ['MAIL_PROVIDER'] = 'resend'
    os.environ['RESEND_API_KEY'] = 're_step8_missing_dmarc'

    with TestClient(app) as client:
        reg = client.post('/api/auth/register', json={
            'workspace_name': 'Empresa DMARC', 'name': 'Admin DMARC',
            'email': 'dmarc-admin@example.com', 'password': 'Senha123'
        })
        assert reg.status_code == 201
        wid = reg.json()['workspace']['id']
        with SessionLocal() as db:
            domain = SendingDomain(
                workspace_id=wid, provider='resend', provider_domain_id='dom_missing_dmarc',
                name='news.example.com', provider_status='verified',
                dns_records=[], spf_status='verified', dkim_status='verified', tracking_status='not_required',
                dmarc_status='missing', ready_for_sending=False,
                dmarc_value='v=DMARC1; p=none; adkim=r; aspf=r; pct=100;'
            )
            db.add(domain); db.flush()
            db.add(SenderIdentity(
                workspace_id=wid, domain_id=domain.id, name='Empresa DMARC',
                email='envios@news.example.com', active=True, is_default=True
            ))
            db.commit()

        assert client.post('/api/contacts', json={
            'name': 'Lead', 'email': 'lead-dmarc@example.com', 'status': 'active', 'source': 'Teste'
        }).status_code == 201
        campaign = client.post('/api/campaigns', json={
            'name': 'Campanha Bloqueada', 'subject': 'Teste', 'body': 'Mensagem', 'audience_type': 'all'
        }).json()
        result = reviewed_send(client, campaign['id'])
        assert result.status_code == 422
        assert 'SPF, DKIM e DMARC' in result.json()['detail']
        status = client.get('/api/deliverability/status').json()
        assert status['live_send_ready'] is False
        assert status['ready_domains'] == 0

    os.environ['MAIL_PROVIDER'] = 'console'
    os.environ.pop('RESEND_API_KEY', None)


def test_campaign_operations_step9_review_exclusions_pause_resume_and_schedule_snapshot():
    from datetime import datetime, timedelta, timezone

    os.environ['MAIL_PROVIDER'] = 'console'

    with TestClient(app) as client:
        reg = client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Passo 9', 'name': 'Admin Passo 9',
            'email': 'passo9@example.com', 'password': 'Senha123'
        })
        assert reg.status_code == 201

        contacts = {}
        for key, payload in {
            'ana': {'name': 'Ana', 'email': 'ana-p9@example.com', 'tags': ['evento'], 'status': 'active', 'source': 'Meta'},
            'bruno': {'name': 'Bruno', 'email': 'bruno-p9@example.com', 'tags': ['evento', 'comprador'], 'status': 'active', 'source': 'Meta'},
            'carla': {'name': 'Carla', 'email': 'carla-p9@example.com', 'tags': ['evento'], 'status': 'unsubscribed', 'source': 'Meta'},
            'diego': {'name': 'Diego', 'email': 'diego-p9@example.com', 'tags': ['lead'], 'status': 'active', 'source': 'Orgânico'},
        }.items():
            res = client.post('/api/contacts', json=payload)
            assert res.status_code == 201, res.text
            contacts[key] = res.json()

        audience_list = client.post('/api/lists', json={'name': 'Evento', 'description': 'Público base'}).json()
        exclude_list = client.post('/api/lists', json={'name': 'Compradores', 'description': 'Excluir compradores'}).json()
        assert client.post(f"/api/lists/{audience_list['id']}/members", json={
            'contact_ids': [contacts['ana']['id'], contacts['bruno']['id'], contacts['carla']['id']]
        }).status_code == 200
        assert client.post(f"/api/lists/{exclude_list['id']}/members", json={
            'contact_ids': [contacts['bruno']['id']]
        }).status_code == 200

        campaign = client.post('/api/campaigns', json={
            'name': 'Revisão Passo 9', 'subject': 'Convite', 'preheader': 'Prévia', 'body': 'Mensagem',
            'audience_type': 'list', 'audience_id': audience_list['id'],
            'exclude_list_ids': [exclude_list['id']], 'status': 'draft'
        })
        assert campaign.status_code == 201, campaign.text
        cid = campaign.json()['id']

        review = client.get(f'/api/campaigns/{cid}/review')
        assert review.status_code == 200, review.text
        r = review.json()
        assert r['base_audience'] == 3
        assert r['exclusions']['inactive_status'] == 1
        assert r['exclusions']['lists'] == 1
        assert r['eligible'] == 1
        assert r['sample'][0]['email'] == 'ana-p9@example.com'
        assert r['can_send'] is True

        # Uma edição material invalida a revisão já apresentada ao usuário.
        assert client.patch(f'/api/campaigns/{cid}', json={'preheader': 'Prévia alterada'}).status_code == 200
        stale = client.post(f'/api/campaigns/{cid}/send', json={
            'review_token': r['review_token'], 'expected_recipients': r['eligible'], 'confirmation': 'ENVIAR'
        })
        assert stale.status_code == 409
        assert 'mudou após a revisão' in stale.json()['detail']

        fresh = client.get(f'/api/campaigns/{cid}/review').json()
        queued = client.post(f'/api/campaigns/{cid}/send', json={
            'review_token': fresh['review_token'], 'expected_recipients': fresh['eligible'], 'confirmation': 'ENVIAR'
        })
        assert queued.status_code == 200, queued.text
        assert queued.json()['queued'] == 1

        paused = client.post(f'/api/campaigns/{cid}/pause')
        assert paused.status_code == 200
        assert paused.json()['pending_jobs'] == 1
        client.post('/api/delivery/process-once')
        paused_delivery = client.get(f'/api/campaigns/{cid}/deliveries').json()['items'][0]
        assert paused_delivery['status'] == 'queued'
        resumed = client.post(f'/api/campaigns/{cid}/resume')
        assert resumed.status_code == 200
        assert resumed.json()['status'] == 'sending'
        client.post('/api/delivery/process-once')
        resumed_delivery = client.get(f'/api/campaigns/{cid}/deliveries').json()['items'][0]
        assert resumed_delivery['status'] == 'sent'
        done = next(x for x in client.get('/api/campaigns').json() if x['id'] == cid)
        assert done['status'] == 'sent'

        # Em agendamentos, a audiência é congelada em jobs no momento da aprovação.
        future = datetime.now(timezone.utc) + timedelta(hours=2)
        scheduled = client.post('/api/campaigns', json={
            'name': 'Agendamento Passo 9', 'subject': 'Agendado', 'preheader': 'Depois', 'body': 'Mensagem',
            'audience_type': 'all', 'exclude_tags': ['comprador'],
            'status': 'scheduled', 'scheduled_at': future.isoformat()
        })
        assert scheduled.status_code == 201, scheduled.text
        sid = scheduled.json()['id']
        sreview = client.get(f'/api/campaigns/{sid}/review').json()
        expected = sreview['eligible']
        armed = client.post(f'/api/campaigns/{sid}/send', json={
            'review_token': sreview['review_token'], 'expected_recipients': expected, 'confirmation': 'AGENDAR'
        })
        assert armed.status_code == 200, armed.text
        assert armed.json()['status'] == 'scheduled'
        scheduled_jobs = client.get(f'/api/campaigns/{sid}/deliveries').json()
        assert scheduled_jobs['total'] == expected
        assert scheduled_jobs['queued'] == expected

        assert client.post('/api/contacts', json={
            'name': 'Novo depois', 'email': 'novo-depois-p9@example.com', 'status': 'active', 'source': 'Depois'
        }).status_code == 201
        assert client.get(f'/api/campaigns/{sid}/deliveries').json()['total'] == expected

        # Editar campanha já armada remove snapshots pendentes e exige nova revisão.
        edited = client.patch(f'/api/campaigns/{sid}', json={'subject': 'Agendado revisado'})
        assert edited.status_code == 200, edited.text
        assert edited.json()['send_armed'] is False
        assert client.get(f'/api/campaigns/{sid}/deliveries').json()['total'] == 0


def test_tracking_step10_utm_unique_metrics_links_and_recipient_report():
    import base64
    import hashlib
    import hmac
    import json
    import time

    from app.database import SessionLocal
    from app.models import EmailDelivery

    os.environ['MAIL_PROVIDER'] = 'console'

    with TestClient(app) as client:
        assert client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Tracking', 'name': 'Admin Tracking',
            'email': 'tracking@example.com', 'password': 'Senha123'
        }).status_code == 201
        contact = client.post('/api/contacts', json={
            'name': 'Ana', 'email': 'ana-tracking@example.com', 'status': 'active', 'source': 'Teste'
        })
        assert contact.status_code == 201
        contact_id = contact.json()['id']

        campaign = client.post('/api/campaigns', json={
            'name': 'Conferência Setembro',
            'subject': 'Convite para {{nome}}',
            'preheader': 'Veja os detalhes',
            'editor_mode': 'html',
            'html_body': '<p>Olá {{nome}}</p><a href="https://example.com/oferta?ref=mail">Oferta</a><a href="https://example.com/aula">Aula</a><a href="mailto:suporte@example.com">Suporte</a>',
            'audience_type': 'all',
            'utm_enabled': True,
            'utm_source': 'mailflow',
            'utm_medium': 'email',
            'utm_campaign': 'conferencia-setembro',
            'utm_content': 'campanha-principal',
        })
        assert campaign.status_code == 201, campaign.text
        cid = campaign.json()['id']
        queued = reviewed_send(client, cid)
        assert queued.status_code == 200, queued.text

        with SessionLocal() as db:
            job = db.query(EmailDelivery).filter(
                EmailDelivery.campaign_id == cid,
                EmailDelivery.is_test.is_(False),
            ).one()
            assert 'utm_source=mailflow' in job.html_snapshot
            assert 'utm_medium=email' in job.html_snapshot
            assert 'utm_campaign=conferencia-setembro' in job.html_snapshot
            assert 'utm_content=campanha-principal' in job.html_snapshot
            assert 'ref=mail' in job.html_snapshot
            assert 'mailto:suporte@example.com' in job.html_snapshot

        assert client.post('/api/delivery/process-once').status_code == 200

        secret_bytes = b'segredo-step10-tracking'
        os.environ['RESEND_WEBHOOK_SECRET'] = 'whsec_' + base64.b64encode(secret_bytes).decode('ascii')
        with SessionLocal() as db:
            job = db.query(EmailDelivery).filter(
                EmailDelivery.campaign_id == cid,
                EmailDelivery.is_test.is_(False),
            ).one()
            job.provider = 'resend'
            job.provider_message_id = 'resend_tracking_1'
            db.commit()

        def signed_post(event_id, payload):
            raw = json.dumps(payload, separators=(',', ':')).encode('utf-8')
            ts = str(int(time.time()))
            signed = f'{event_id}.{ts}.'.encode('utf-8') + raw
            sig = base64.b64encode(hmac.new(secret_bytes, signed, hashlib.sha256).digest()).decode('ascii')
            return client.post('/api/webhooks/resend', content=raw, headers={
                'content-type': 'application/json', 'svix-id': event_id,
                'svix-timestamp': ts, 'svix-signature': f'v1,{sig}'
            })

        assert signed_post('evt_t10_delivered', {
            'type': 'email.delivered', 'data': {'email_id': 'resend_tracking_1'}
        }).status_code == 200
        assert signed_post('evt_t10_open_1', {
            'type': 'email.opened', 'created_at': '2026-09-10T23:00:00Z',
            'data': {'email_id': 'resend_tracking_1'}
        }).status_code == 200
        assert signed_post('evt_t10_open_2', {
            'type': 'email.opened', 'created_at': '2026-09-10T23:05:00Z',
            'data': {'email_id': 'resend_tracking_1'}
        }).status_code == 200

        clicked_url = 'https://example.com/oferta?ref=mail&utm_source=mailflow&utm_medium=email&utm_campaign=conferencia-setembro&utm_content=campanha-principal'
        for event_id, url, timestamp in [
            ('evt_t10_click_1', clicked_url, '2026-09-10T23:10:00Z'),
            ('evt_t10_click_2', clicked_url, '2026-09-10T23:11:00Z'),
            ('evt_t10_click_3', 'https://example.com/aula?utm_source=mailflow&utm_medium=email&utm_campaign=conferencia-setembro&utm_content=campanha-principal', '2026-09-10T23:12:00Z'),
        ]:
            response = signed_post(event_id, {
                'type': 'email.clicked',
                'data': {
                    'email_id': 'resend_tracking_1',
                    'click': {
                        'link': url, 'timestamp': timestamp,
                        'ipAddress': '127.0.0.1', 'userAgent': 'MailFlow Test'
                    }
                }
            })
            assert response.status_code == 200, response.text

        report = client.get(f'/api/campaigns/{cid}/report').json()
        assert report['summary']['sent'] == 1
        assert report['summary']['delivered'] == 1
        assert report['summary']['unique_opens'] == 1
        assert report['summary']['open_events'] == 2
        assert report['summary']['unique_clicks'] == 1
        assert report['summary']['click_events'] == 3
        assert report['summary']['open_rate'] == 100.0
        assert report['summary']['click_rate'] == 100.0
        assert report['summary']['click_to_open_rate'] == 100.0
        assert report['utm']['enabled'] is True
        assert report['utm']['campaign'] == 'conferencia-setembro'
        assert report['links'][0]['total_clicks'] == 2
        assert report['links'][0]['unique_clicks'] == 1
        assert report['recipients'][0]['email'] == 'ana-tracking@example.com'
        assert report['recipients'][0]['open_events'] == 2
        assert report['recipients'][0]['click_events'] == 3

        events = client.get(f'/api/campaigns/{cid}/engagement-events').json()
        assert len(events) == 5
        assert sum(1 for x in events if x['event_type'] == 'open') == 2
        assert sum(1 for x in events if x['event_type'] == 'click') == 3

        campaign_after = next(x for x in client.get('/api/campaigns').json() if x['id'] == cid)
        assert campaign_after['opens'] == 1
        assert campaign_after['clicks'] == 1
        assert campaign_after['open_events'] == 2
        assert campaign_after['click_events'] == 3

        detail = client.get(f'/api/contacts/{contact_id}').json()
        assert any(e['event_type'] == 'email_opened' for e in detail['history'])
        assert any(e['event_type'] == 'email_clicked' for e in detail['history'])

        os.environ.pop('RESEND_WEBHOOK_SECRET', None)


def test_privacy_step11_one_click_suppression_consent_and_delete():
    import re
    from app.database import SessionLocal
    from app.models import Contact, EmailDelivery

    os.environ['MAIL_PROVIDER'] = 'console'
    os.environ['MAILFLOW_PUBLIC_BASE_URL'] = 'https://mail.example.com'
    os.environ['MAILFLOW_UNSUBSCRIBE_SECRET'] = 'unsubscribe-secret-step11-strong-value'
    os.environ['MAILFLOW_SUPPRESSION_SECRET'] = 'suppression-secret-step11-strong-value'

    with TestClient(app) as client:
        reg = client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Privacidade', 'name': 'Admin Privacidade',
            'email': 'privacidade@example.com', 'password': 'Senha123'
        })
        assert reg.status_code == 201
        contact = client.post('/api/contacts', json={
            'name': 'Ana', 'email': 'ana-privacy@example.com', 'status': 'active', 'source': 'Landing page'
        }).json()

        consent = client.post('/api/privacy/consents', json={
            'contact_id': contact['id'], 'action': 'granted', 'legal_basis': 'consent',
            'source': 'landing-page-v1', 'notice_version': 'v1', 'evidence': {'form': 'lp'}, 'reactivate': False
        })
        assert consent.status_code == 200, consent.text

        campaign = client.post('/api/campaigns', json={
            'name': 'Campanha Privacidade', 'subject': 'Olá', 'body': 'Mensagem',
            'editor_mode': 'html', 'html_body': '<p>Mensagem</p>', 'audience_type': 'all'
        }).json()
        sent = reviewed_send(client, campaign['id'])
        assert sent.status_code == 200, sent.text

        with SessionLocal() as db:
            job = db.query(EmailDelivery).filter(EmailDelivery.campaign_id == campaign['id']).one()
            assert 'data-mailflow-unsubscribe="true"' in job.html_snapshot
            assert 'https://mail.example.com/api/unsubscribe/' in job.html_snapshot
            match = re.search(r'https://mail\.example\.com/api/unsubscribe/([^"<]+)', job.html_snapshot)
            assert match
            token = match.group(1)

        page = client.get(f'/api/unsubscribe/{token}')
        assert page.status_code == 200
        assert 'Cancelar inscrição' in page.text
        one_click = client.post(
            f'/api/unsubscribe/{token}',
            content='List-Unsubscribe=One-Click',
            headers={'content-type': 'application/x-www-form-urlencoded'},
        )
        assert one_click.status_code == 200

        suppressions = client.get('/api/suppressions').json()
        assert len(suppressions) == 1
        assert suppressions[0]['reason'] == 'unsubscribe'
        assert suppressions[0]['email_hint'].endswith('@example.com')
        assert 'ana-privacy' not in suppressions[0]['email_hint']

        detail = client.get(f"/api/contacts/{contact['id']}").json()
        assert detail['contact']['status'] == 'unsubscribed'

        # Mesmo se alguém alterar o status diretamente, a supressão independente continua bloqueando.
        with SessionLocal() as db:
            c = db.get(Contact, contact['id'])
            c.status = 'active'
            db.commit()
        second = client.post('/api/campaigns', json={
            'name': 'Campanha Bloqueada', 'subject': 'Teste', 'body': 'Mensagem', 'audience_type': 'all'
        }).json()
        review = client.get(f"/api/campaigns/{second['id']}/review").json()
        assert review['eligible'] == 0
        assert review['exclusions']['suppression'] == 1

        # Novo consentimento explícito pode reativar e liberar a supressão.
        reconsent = client.post('/api/privacy/consents', json={
            'contact_id': contact['id'], 'action': 'granted', 'legal_basis': 'consent',
            'source': 'double-optin-2026-09-11', 'notice_version': 'v2', 'evidence': {'double_opt_in': True},
            'reactivate': True
        })
        assert reconsent.status_code == 200, reconsent.text
        assert client.get('/api/suppressions').json() == []
        review2 = client.get(f"/api/campaigns/{second['id']}/review").json()
        assert review2['eligible'] == 1

        export = client.get(f"/api/privacy/contacts/{contact['id']}/export")
        assert export.status_code == 200
        exported = export.json()
        assert exported['contact']['email'] == 'ana-privacy@example.com'
        assert len(exported['consents']) >= 2

        deleted = client.request('DELETE', f"/api/privacy/contacts/{contact['id']}", json={'confirmation': 'EXCLUIR'})
        assert deleted.status_code == 200, deleted.text
        assert deleted.json()['suppression_preserved'] is True
        assert client.get(f"/api/contacts/{contact['id']}").status_code == 404
        privacy_suppressions = client.get('/api/suppressions').json()
        assert len(privacy_suppressions) == 1
        assert privacy_suppressions[0]['reason'] == 'privacy_delete'

    for key in ['MAILFLOW_PUBLIC_BASE_URL', 'MAILFLOW_UNSUBSCRIBE_SECRET', 'MAILFLOW_SUPPRESSION_SECRET']:
        os.environ.pop(key, None)


def test_privacy_step11_resend_custom_unsubscribe_headers_contract():
    from unittest.mock import patch
    from app.email_provider import ResendProvider

    os.environ['RESEND_API_KEY'] = 're_step11_headers'

    class FakeResponse:
        status_code = 200
        text = ''
        def json(self): return {'id': 'email_step11'}

    with patch('app.email_provider.httpx.post', return_value=FakeResponse()) as post:
        provider = ResendProvider()
        result = provider.send(
            from_name='Marca', from_email='campanhas@example.com', to_email='lead@example.com',
            subject='Teste', html='<p>Olá</p>', text='Olá', reply_to='', idempotency_key='step11/test',
            headers={
                'List-Unsubscribe': '<https://example.com/api/unsubscribe/token>',
                'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click',
            }
        )
        assert result.message_id == 'email_step11'
        payload = post.call_args.kwargs['json']
        assert payload['headers']['List-Unsubscribe'].startswith('<https://')
        assert payload['headers']['List-Unsubscribe-Post'] == 'List-Unsubscribe=One-Click'

    os.environ.pop('RESEND_API_KEY', None)


def test_automations_step12_trigger_wait_condition_email_and_persistence():
    from datetime import datetime, timedelta, timezone
    from app.database import SessionLocal
    from app.models import AutomationRun, Contact

    os.environ['MAIL_PROVIDER'] = 'console'
    os.environ['MAILFLOW_PUBLIC_BASE_URL'] = 'https://mail.example.com'
    os.environ['MAILFLOW_UNSUBSCRIBE_SECRET'] = 'automation-unsub-step12-strong-secret'
    os.environ['MAILFLOW_SUPPRESSION_SECRET'] = 'automation-suppress-step12-strong-secret'

    with TestClient(app) as client:
        assert client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Automação', 'name': 'Admin Automação',
            'email': 'automacao@example.com', 'password': 'Senha123'
        }).status_code == 201

        template = client.post('/api/templates', json={
            'name': 'Boas-vindas', 'type': 'Automação',
            'subject': 'Olá {{nome|você}}', 'preheader': 'Automação MailFlow',
            'editor_mode': 'html', 'html_body': '<p>Bem-vindo, {{nome|você}}.</p>'
        })
        assert template.status_code == 201, template.text
        template_id = template.json()['id']

        contact = client.post('/api/contacts', json={
            'name': 'Ana', 'email': 'ana-auto@example.com', 'tags': ['vip'],
            'status': 'active', 'source': 'Landing page'
        })
        assert contact.status_code == 201
        contact_id = contact.json()['id']

        automation = client.post('/api/automations', json={
            'name': 'Nutrição VIP',
            'trigger_type': 'tag_added',
            'trigger_config': {'tag': 'iniciar-fluxo'},
            'reentry_policy': 'once',
            'active': True,
            'steps': [
                {'type': 'send_email', 'template_id': template_id},
                {'type': 'wait', 'amount': 1, 'unit': 'minutes'},
                {'type': 'condition', 'rules': [{'field': 'tag', 'operator': 'contains', 'value': 'vip'}], 'match_mode': 'all', 'on_false': 'stop'},
                {'type': 'add_tag', 'tag': 'automacao-concluida'},
            ]
        })
        assert automation.status_code == 201, automation.text
        aid = automation.json()['id']
        assert automation.json()['run_count'] == 0

        # A tag adicionada gera ContactEvent; o motor detecta e inscreve o contato.
        updated = client.patch(f'/api/contacts/{contact_id}', json={'tags': ['vip', 'iniciar-fluxo']})
        assert updated.status_code == 200, updated.text
        cycle1 = client.post('/api/automations/process-once')
        assert cycle1.status_code == 200, cycle1.text
        assert cycle1.json()['enrolled'] == 1
        assert cycle1.json()['runs_processed'] == 1

        runs = client.get(f'/api/automations/{aid}/runs').json()
        assert len(runs) == 1
        assert runs[0]['status'] == 'waiting'
        assert runs[0]['current_step'] == 0

        # O e-mail da automação usa a mesma fila persistente do Passo 7.
        delivery_cycle = client.post('/api/delivery/process-once')
        assert delivery_cycle.status_code == 200, delivery_cycle.text
        assert delivery_cycle.json()['processed'] >= 1

        # O próximo ciclo confirma a entrega e agenda a espera persistente.
        cycle2 = client.post('/api/automations/process-once')
        assert cycle2.status_code == 200
        runs2 = client.get(f'/api/automations/{aid}/runs').json()
        assert runs2[0]['current_step'] == 2
        assert runs2[0]['status'] == 'waiting'
        assert runs2[0]['next_run_at'] is not None

        # Simula o relógio avançando; após reinício do worker, a execução continua do banco.
        with SessionLocal() as db:
            run = db.query(AutomationRun).filter(AutomationRun.automation_id == aid).one()
            run.next_run_at = datetime.now(timezone.utc) - timedelta(seconds=1)
            db.commit()

        cycle3 = client.post('/api/automations/process-once')
        assert cycle3.status_code == 200, cycle3.text
        final_run = client.get(f'/api/automations/{aid}/runs').json()[0]
        assert final_run['status'] == 'completed'
        assert final_run['current_step'] == 4

        final_contact = client.get(f'/api/contacts/{contact_id}').json()['contact']
        assert 'automacao-concluida' in final_contact['tags']
        history = client.get(f'/api/contacts/{contact_id}').json()['history']
        assert any(x['event_type'] == 'automation_enrolled' for x in history)
        assert any(x['event_type'] == 'automation_completed' for x in history)

        # Política "once": remover e adicionar novamente o gatilho não cria nova execução.
        assert client.patch(f'/api/contacts/{contact_id}', json={'tags': ['vip']}).status_code == 200
        assert client.patch(f'/api/contacts/{contact_id}', json={'tags': ['vip', 'iniciar-fluxo']}).status_code == 200
        assert client.post('/api/automations/process-once').status_code == 200
        assert len(client.get(f'/api/automations/{aid}/runs').json()) == 1

    for key in ['MAILFLOW_PUBLIC_BASE_URL', 'MAILFLOW_UNSUBSCRIBE_SECRET', 'MAILFLOW_SUPPRESSION_SECRET']:
        os.environ.pop(key, None)


def test_events_step13_timeline_prepare_campaigns_confirmation_and_safety():
    from datetime import datetime, timedelta, timezone
    from app.database import SessionLocal
    from app.models import Campaign

    with TestClient(app) as client, TestClient(app) as outsider:
        assert client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Eventos', 'name': 'Admin Eventos',
            'email': 'eventos@example.com', 'password': 'Senha123'
        }).status_code == 201

        contact = client.post('/api/contacts', json={
            'name': 'Ana', 'email': 'ana-evento@example.com', 'status': 'active', 'source': 'Landing'
        }).json()
        static_list = client.post('/api/lists', json={'name': 'Inscritos Evento', 'description': 'Lista oficial'}).json()
        assert client.post(f"/api/lists/{static_list['id']}/members", json={'contact_ids': [contact['id']]}).status_code == 200

        template = client.post('/api/templates', json={
            'name': 'Lembrete Evento', 'type': 'Evento',
            'subject': '{{evento_nome}} começa em breve',
            'preheader': '{{evento_inicio}}',
            'editor_mode': 'html',
            'html_body': '<p>Nos vemos em {{evento_nome}}.</p><p><a href="{{evento_link}}">Acessar {{evento_plataforma}}</a></p>'
        })
        assert template.status_code == 201, template.text
        template_id = template.json()['id']

        start = datetime.now(timezone.utc) + timedelta(days=3)
        end = start + timedelta(hours=2)
        offer_open = end + timedelta(minutes=30)
        offer_close = offer_open + timedelta(days=2)
        event = client.post('/api/events', json={
            'name': 'Conferência de Teste', 'event_type': 'conference', 'status': 'planned',
            'description': 'Evento de validação do Passo 13.',
            'start_at': start.isoformat(), 'end_at': end.isoformat(), 'timezone': 'America/Belem',
            'platform': 'Zoom', 'access_url': 'https://zoom.example.com/evento',
            'audience_type': 'list', 'audience_id': static_list['id'],
            'offer_open_at': offer_open.isoformat(), 'offer_close_at': offer_close.isoformat(),
        })
        assert event.status_code == 201, event.text
        event_id = event.json()['id']
        assert event.json()['audience_label'] == 'Lista: Inscritos Evento'

        # O plano recomendado é idempotente e organiza pré-evento, live, pós e oferta.
        plan1 = client.post(f'/api/events/{event_id}/recommended-plan')
        assert plan1.status_code == 200, plan1.text
        assert plan1.json()['created'] >= 6
        plan2 = client.post(f'/api/events/{event_id}/recommended-plan')
        assert plan2.status_code == 200
        assert plan2.json()['created'] == 0
        assert plan2.json()['existing'] == plan1.json()['created']

        # Configura templates em duas comunicações-chave e prepara campanhas sem armá-las.
        comms = plan2.json()['communications']
        selected = [x for x in comms if x['system_key'] in {'reminder_24h', 'offer_close_1h'}]
        assert len(selected) == 2
        for comm in selected:
            patched = client.patch(f"/api/events/{event_id}/communications/{comm['id']}", json={'template_id': template_id})
            assert patched.status_code == 200, patched.text

        prepared = client.post(f'/api/events/{event_id}/prepare-campaigns')
        assert prepared.status_code == 200, prepared.text
        assert prepared.json()['prepared'] == 2
        linked = [x for x in prepared.json()['communications'] if x['campaign_id']]
        assert len(linked) == 2
        assert all(not x['campaign_send_armed'] for x in linked)

        campaign = client.get('/api/campaigns').json()
        event_campaigns = [x for x in campaign if x['id'] in {c['campaign_id'] for c in linked}]
        assert len(event_campaigns) == 2
        assert all(x['status'] == 'scheduled' for x in event_campaigns)
        assert any(x['subject'] == 'Conferência de Teste começa em breve' for x in event_campaigns)
        assert any('zoom.example.com/evento' in x['html_body'] for x in event_campaigns)
        assert all(x['utm_enabled'] for x in event_campaigns)

        # Alterar a data antes de armar atualiza automaticamente os rascunhos/agendamentos preparados.
        old_reminder = next(x for x in linked if x['system_key'] == 'reminder_24h')
        old_time = datetime.fromisoformat(old_reminder['scheduled_at'].replace('Z', '+00:00'))
        new_start = start + timedelta(days=1)
        new_end = end + timedelta(days=1)
        new_offer_open = offer_open + timedelta(days=1)
        new_offer_close = offer_close + timedelta(days=1)
        moved = client.patch(f'/api/events/{event_id}', json={
            'start_at': new_start.isoformat(), 'end_at': new_end.isoformat(),
            'offer_open_at': new_offer_open.isoformat(), 'offer_close_at': new_offer_close.isoformat(),
        })
        assert moved.status_code == 200, moved.text
        detail = client.get(f'/api/events/{event_id}').json()
        new_reminder = next(x for x in detail['communications'] if x['system_key'] == 'reminder_24h')
        new_time = datetime.fromisoformat(new_reminder['scheduled_at'].replace('Z', '+00:00'))
        assert round((new_time - old_time).total_seconds()) == 86400
        linked_campaign = next(x for x in client.get('/api/campaigns').json() if x['id'] == new_reminder['campaign_id'])
        campaign_time = datetime.fromisoformat(linked_campaign['scheduled_at'].replace('Z', '+00:00'))
        assert abs((campaign_time - new_time).total_seconds()) < 2

        # A confirmação de inscrição reaproveita o motor de automações e nasce pausada por segurança.
        confirmation = client.post(f'/api/events/{event_id}/confirmation-automation', json={
            'template_id': template_id, 'active': False
        })
        assert confirmation.status_code == 200, confirmation.text
        assert confirmation.json()['active'] is False
        assert confirmation.json()['trigger_type'] == 'list_joined'
        assert confirmation.json()['trigger_config']['list_id'] == static_list['id']
        refreshed = client.get(f'/api/events/{event_id}').json()['event']
        assert refreshed['registration_automation_id'] == confirmation.json()['id']

        # Depois que uma campanha é armada, mover o evento é bloqueado para evitar disparos em horário antigo.
        arm_target = new_reminder['campaign_id']
        with SessionLocal() as db:
            c = db.get(Campaign, arm_target)
            c.send_armed = True
            db.commit()
        blocked = client.patch(f'/api/events/{event_id}', json={'start_at': (new_start + timedelta(hours=1)).isoformat()})
        assert blocked.status_code == 409

        # Isolamento por workspace também vale para eventos.
        assert outsider.post('/api/auth/register', json={
            'workspace_name': 'Outra Empresa Eventos', 'name': 'Outro Admin',
            'email': 'outro-eventos@example.com', 'password': 'Senha123'
        }).status_code == 201
        assert outsider.get('/api/events').json() == []
        assert outsider.get(f'/api/events/{event_id}').status_code == 404


def test_reports_step14_period_comparison_campaigns_links_automations_events_and_alerts():
    from datetime import datetime, timedelta, timezone
    from app.database import SessionLocal
    from app.models import (
        Automation, AutomationRun, Campaign, Contact, EmailDelivery, EmailEngagementEvent,
        EventCommunication, MarketingEvent,
    )

    now = datetime.now(timezone.utc)
    with TestClient(app) as client:
        assert client.post('/api/auth/register', json={
            'workspace_name': 'Empresa Analytics', 'name': 'Admin Analytics',
            'email': 'analytics@example.com', 'password': 'Senha123'
        }).status_code == 201
        me = client.get('/api/auth/me').json()
        wid = me['workspace']['id']

        current_contact = client.post('/api/contacts', json={
            'name': 'Atual', 'email': 'atual-analytics@example.com', 'status': 'active', 'source': 'Meta Ads'
        }).json()
        previous_contact = client.post('/api/contacts', json={
            'name': 'Anterior', 'email': 'anterior-analytics@example.com', 'status': 'active', 'source': 'Orgânico'
        }).json()

        with SessionLocal() as db:
            # Distribui os contatos entre período atual e anterior (30 dias cada).
            c_prev = db.get(Contact, previous_contact['id'])
            c_prev.created_at = now - timedelta(days=40)

            campaign_now = Campaign(
                workspace_id=wid, name='Campanha Atual', subject='Assunto campeão', status='sent',
                queued_at=now - timedelta(days=2), send_started_at=now - timedelta(days=2),
                send_completed_at=now - timedelta(days=2), sent=2, delivered=2, opens=1, clicks=1,
            )
            campaign_prev = Campaign(
                workspace_id=wid, name='Campanha Anterior', subject='Assunto anterior', status='sent',
                queued_at=now - timedelta(days=40), send_started_at=now - timedelta(days=40),
                send_completed_at=now - timedelta(days=40), sent=1, delivered=1, opens=0, clicks=0,
            )
            db.add_all([campaign_now, campaign_prev]); db.flush()

            d1 = EmailDelivery(
                workspace_id=wid, campaign_id=campaign_now.id, contact_id=current_contact['id'],
                recipient_email='atual-analytics@example.com', recipient_name='Atual', is_test=False,
                status='delivered', provider='console', idempotency_key='step14/current/1',
                subject_snapshot='Assunto campeão', queued_at=now-timedelta(days=2),
                sent_at=now-timedelta(days=2), delivered_at=now-timedelta(days=2),
                opened_at=now-timedelta(days=2), clicked_at=now-timedelta(days=2),
            )
            d2 = EmailDelivery(
                workspace_id=wid, campaign_id=campaign_now.id, contact_id=previous_contact['id'],
                recipient_email='anterior-analytics@example.com', recipient_name='Anterior', is_test=False,
                status='delivered', provider='console', idempotency_key='step14/current/2',
                subject_snapshot='Assunto campeão', queued_at=now-timedelta(days=2),
                sent_at=now-timedelta(days=2), delivered_at=now-timedelta(days=2),
            )
            dprev = EmailDelivery(
                workspace_id=wid, campaign_id=campaign_prev.id, contact_id=previous_contact['id'],
                recipient_email='anterior-analytics@example.com', recipient_name='Anterior', is_test=False,
                status='delivered', provider='console', idempotency_key='step14/previous/1',
                subject_snapshot='Assunto anterior', queued_at=now-timedelta(days=40),
                sent_at=now-timedelta(days=40), delivered_at=now-timedelta(days=40),
            )
            # Job antigo para validar observabilidade da fila.
            stuck = EmailDelivery(
                workspace_id=wid, contact_id=current_contact['id'], recipient_email='fila@example.com',
                recipient_name='Fila', is_test=False, status='queued', provider='console',
                idempotency_key='step14/stuck/1', subject_snapshot='Fila', queued_at=now-timedelta(hours=2),
            )
            db.add_all([d1, d2, dprev, stuck]); db.flush()

            click = EmailEngagementEvent(
                workspace_id=wid, campaign_id=campaign_now.id, delivery_id=d1.id,
                contact_id=current_contact['id'], provider='resend', provider_event_id='step14-click-1',
                event_type='clicked', occurred_at=now-timedelta(days=2),
                link_url='https://example.com/oferta?utm_source=mailflow', link_host='example.com',
            )
            db.add(click)

            automation = Automation(
                workspace_id=wid, name='Nutrição Analytics', trigger_type='manual', trigger_config={},
                steps_json=[{'type':'wait','amount':1,'unit':'minutes'}], active=True,
            )
            db.add(automation); db.flush()
            db.add_all([
                AutomationRun(workspace_id=wid, automation_id=automation.id, contact_id=current_contact['id'], status='completed', current_step=1, started_at=now-timedelta(days=1), completed_at=now-timedelta(days=1)),
                AutomationRun(workspace_id=wid, automation_id=automation.id, contact_id=previous_contact['id'], status='failed', current_step=0, started_at=now-timedelta(days=1), last_error='Falha de teste'),
            ])

            event = MarketingEvent(
                workspace_id=wid, name='Evento Analytics', event_type='conference', status='planned',
                start_at=now+timedelta(days=2), end_at=now+timedelta(days=2,hours=2),
                timezone='America/Belem', platform='Zoom', audience_type='all',
            )
            db.add(event); db.flush()
            db.add(EventCommunication(
                workspace_id=wid, event_id=event.id, name='Lembrete', phase='pre_event',
                relative_to='event_start', offset_minutes=-1440, scheduled_at=now+timedelta(days=1),
                campaign_id=campaign_now.id, enabled=True,
            ))
            db.commit()

        response = client.get('/api/reports/overview', params={'days': 30})
        assert response.status_code == 200, response.text
        report = response.json()
        assert report['period']['days'] == 30
        assert report['summary']['sent'] == 2
        assert report['summary']['delivered'] == 2
        assert report['summary']['opens'] == 1
        assert report['summary']['clicks'] == 1
        assert report['previous_summary']['sent'] == 1
        assert report['changes']['sent'] == 100.0
        assert report['summary']['new_contacts'] == 1
        assert report['changes']['new_contacts'] == 0.0
        assert len(report['daily']) == 30

        campaigns = report['campaign_comparison']
        assert len(campaigns) == 1
        assert campaigns[0]['name'] == 'Campanha Atual'
        assert campaigns[0]['delivery_rate'] == 100.0
        assert campaigns[0]['open_rate'] == 50.0
        assert campaigns[0]['click_rate'] == 50.0
        assert report['top_subjects'][0]['subject'] == 'Assunto campeão'

        assert report['top_links'][0]['host'] == 'example.com'
        assert report['top_links'][0]['unique_clicks'] == 1
        assert report['automation_performance'][0]['runs'] == 2
        assert report['automation_performance'][0]['completed'] == 1
        assert report['automation_performance'][0]['failed'] == 1
        assert report['event_performance'][0]['name'] == 'Evento Analytics'
        assert report['event_performance'][0]['sent'] == 2
        assert report['source_breakdown']['campaign']['sent'] == 2
        assert any(a['code'] == 'queue_stuck' for a in report['alerts'])
        assert any(a['code'] == 'automation_failures' for a in report['alerts'])
