from __future__ import annotations

import logging
import os
import time

from .automation_engine import process_automation_cycle
from .database import SessionLocal
from .delivery_service import process_batch
from .health_service import record_heartbeat
from .observability import configure_logging

configure_logging()
logger = logging.getLogger("mailflow.worker")


def main() -> None:
    interval = max(1.0, float(os.getenv("MAILFLOW_WORKER_INTERVAL_SECONDS", "2")))
    batch_size = max(1, min(500, int(os.getenv("MAILFLOW_WORKER_BATCH_SIZE", "50"))))
    logger.info("worker_started batch=%s interval=%s", batch_size, interval)
    while True:
        try:
            with SessionLocal() as db:
                auto = process_automation_cycle(db, trigger_limit=max(100, batch_size * 4), run_limit=max(50, batch_size * 2))
                result = process_batch(db, batch_size)
                record_heartbeat(
                    "worker",
                    status="ok",
                    details={
                        "batch_size": batch_size,
                        "emails_processed": result.get("processed", 0),
                        "email_failures": result.get("failed", 0),
                        "automation_runs": auto.get("runs_processed", 0),
                        "automation_failures": auto.get("runs_failed", 0),
                    },
                    db=db,
                )
                if auto.get("enrolled") or auto.get("runs_processed"):
                    logger.info("automation_cycle enrolled=%s runs=%s failures=%s", auto.get("enrolled"), auto.get("runs_processed"), auto.get("runs_failed"))
                if result.get("processed"):
                    logger.info("delivery_cycle processed=%s failures=%s", result.get("processed"), result.get("failed"))
        except Exception as exc:
            logger.exception("worker_cycle_failed")
            try:
                record_heartbeat("worker", status="error", details={"error": exc.__class__.__name__})
            except Exception:
                pass
        time.sleep(interval)


if __name__ == "__main__":
    main()
