from __future__ import annotations

from datetime import datetime, timezone
import os
import socket

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from .config import settings
from .database import SessionLocal
from .models import ServiceHeartbeat


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def instance_id() -> str:
    return os.getenv("MAILFLOW_INSTANCE_ID", socket.gethostname())[:120]


def record_heartbeat(service_name: str, *, status: str = "ok", details: dict | None = None, db: Session | None = None) -> None:
    owns = db is None
    session = db or SessionLocal()
    try:
        row = session.get(ServiceHeartbeat, service_name)
        if not row:
            row = ServiceHeartbeat(service_name=service_name)
            session.add(row)
        row.instance_id = instance_id()
        row.status = status
        row.details = details or {}
        row.updated_at = utcnow()
        session.commit()
    finally:
        if owns:
            session.close()


def readiness() -> tuple[bool, dict]:
    report: dict = {"database": "unknown", "worker": "not_required"}
    try:
        with SessionLocal() as db:
            db.execute(text("SELECT 1"))
            report["database"] = "ok"
            if settings.require_worker_health:
                hb = db.scalar(select(ServiceHeartbeat).where(ServiceHeartbeat.service_name == "worker"))
                if not hb:
                    report["worker"] = "missing"
                    return False, report
                updated = hb.updated_at
                now = utcnow()
                if updated.tzinfo is None:
                    updated = updated.replace(tzinfo=timezone.utc)
                age = (now - updated).total_seconds()
                report["worker"] = {"status": hb.status, "age_seconds": round(age, 1), "instance_id": hb.instance_id}
                if hb.status != "ok" or age > settings.worker_stale_seconds:
                    return False, report
        return True, report
    except Exception as exc:
        report["database"] = f"error:{exc.__class__.__name__}"
        return False, report
