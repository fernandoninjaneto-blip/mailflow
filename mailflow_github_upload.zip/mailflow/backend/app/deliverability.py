from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import os
import re
from typing import Any

import dns.exception
import dns.resolver
from sqlalchemy import select
from sqlalchemy.orm import Session

from .domain_provider import ResendDomainClient
from .models import SenderIdentity, SenderSettings, SendingDomain


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


DOMAIN_RE = re.compile(r"^(?=.{3,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$", re.I)
LABEL_RE = re.compile(r"^[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?$", re.I)


def normalize_domain_name(value: str) -> str:
    value = value.strip().lower().rstrip(".")
    if value.startswith("http://") or value.startswith("https://"):
        raise ValueError("Informe apenas o domínio, sem http:// ou https://.")
    if "@" in value or "/" in value or not DOMAIN_RE.match(value):
        raise ValueError("Domínio inválido. Exemplo: email.suaempresa.com.br")
    return value


def validate_dns_label(value: str, field_name: str) -> str:
    value = value.strip().lower()
    if not LABEL_RE.match(value):
        raise ValueError(f"{field_name} inválido. Use letras, números e hífens, começando por uma letra.")
    return value


def build_dmarc_value(policy: str = "none", report_email: str = "") -> str:
    policy = policy if policy in {"none", "quarantine", "reject"} else "none"
    parts = ["v=DMARC1", f"p={policy}"]
    if report_email.strip():
        parts.append(f"rua=mailto:{report_email.strip().lower()}")
    parts.extend(["adkim=r", "aspf=r", "pct=100"])
    return "; ".join(parts) + ";"


def _record_status(records: list[dict[str, Any]], purpose: str) -> str:
    items = [r for r in records if str(r.get("record") or "").lower() == purpose.lower()]
    if not items:
        return "not_started"
    statuses = [str(r.get("status") or "not_started").lower() for r in items]
    if all(s == "verified" for s in statuses):
        return "verified"
    if any(s in {"failed", "failure"} for s in statuses):
        return "failed"
    if any(s == "pending" for s in statuses):
        return "pending"
    return statuses[0]


def check_dmarc_dns(domain_name: str) -> dict[str, Any]:
    qname = f"_dmarc.{domain_name}".rstrip(".")
    timeout = float(os.getenv("MAILFLOW_DNS_TIMEOUT_SECONDS", "3"))
    resolver = dns.resolver.Resolver(configure=True)
    resolver.timeout = timeout
    resolver.lifetime = timeout
    try:
        answer = resolver.resolve(qname, "TXT")
        values: list[str] = []
        for rr in answer:
            try:
                value = b"".join(rr.strings).decode("utf-8")
            except Exception:
                value = rr.to_text().strip('"').replace('" "', '')
            if value.lower().startswith("v=dmarc1"):
                values.append(value)
        if len(values) == 1:
            policy_match = re.search(r"(?:^|;)\s*p\s*=\s*(none|quarantine|reject)\b", values[0], re.I)
            return {
                "status": "valid" if policy_match else "invalid",
                "values": values,
                "policy": policy_match.group(1).lower() if policy_match else "",
                "error": "" if policy_match else "Registro DMARC encontrado, mas sem política p= válida.",
            }
        if len(values) > 1:
            return {"status": "invalid", "values": values, "policy": "", "error": "Há mais de um registro DMARC; deve existir apenas um."}
        return {"status": "missing", "values": [], "policy": "", "error": "Nenhum registro DMARC publicado."}
    except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
        return {"status": "missing", "values": [], "policy": "", "error": "Nenhum registro DMARC publicado."}
    except dns.exception.Timeout:
        return {"status": "timeout", "values": [], "policy": "", "error": "Tempo esgotado ao consultar o DNS."}
    except Exception as exc:
        return {"status": "error", "values": [], "policy": "", "error": f"Falha na consulta DNS: {exc}"[:1000]}


def sync_domain_from_provider(domain: SendingDomain, payload: dict[str, Any]) -> None:
    records = payload.get("records") or domain.dns_records or []
    domain.provider_domain_id = str(payload.get("id") or domain.provider_domain_id or "") or None
    domain.provider_status = str(payload.get("status") or domain.provider_status or "not_started")
    domain.region = str(payload.get("region") or domain.region or "us-east-1")
    domain.open_tracking = bool(payload.get("open_tracking", domain.open_tracking))
    domain.click_tracking = bool(payload.get("click_tracking", domain.click_tracking))
    domain.tracking_subdomain = str(payload.get("tracking_subdomain") or domain.tracking_subdomain or "links")
    domain.dns_records = records
    domain.spf_status = _record_status(records, "SPF")
    domain.dkim_status = _record_status(records, "DKIM")
    domain.tracking_status = _record_status(records, "Tracking") if any(str(r.get("record") or "").lower() == "tracking" for r in records) else "not_required"
    recompute_domain_readiness(domain)


def recompute_domain_readiness(domain: SendingDomain) -> bool:
    provider_ok = domain.provider_status in {"verified", "partially_verified"}
    tracking_ok = (not domain.click_tracking and not domain.open_tracking) or domain.tracking_status in {"verified", "not_required"}
    domain.ready_for_sending = bool(
        provider_ok
        and domain.spf_status == "verified"
        and domain.dkim_status == "verified"
        and domain.dmarc_status == "valid"
        and tracking_ok
    )
    return domain.ready_for_sending


def refresh_domain_dns(domain: SendingDomain) -> dict[str, Any]:
    result = check_dmarc_dns(domain.name)
    domain.dmarc_status = result["status"]
    domain.dmarc_found_values = result["values"]
    domain.last_error = result.get("error", "")
    domain.last_checked_at = utcnow()
    recompute_domain_readiness(domain)
    return result


def refresh_domain_from_resend(domain: SendingDomain) -> dict[str, Any]:
    client = ResendDomainClient()
    if not client.configured:
        raise ValueError("RESEND_API_KEY não configurada no backend.")
    if not domain.provider_domain_id:
        raise ValueError("O domínio ainda não foi registrado no Resend.")
    payload = client.get_domain(domain.provider_domain_id)
    sync_domain_from_provider(domain, payload)
    refresh_domain_dns(domain)
    return payload


@dataclass(slots=True)
class ResolvedSender:
    sender_name: str
    sender_email: str
    reply_to: str
    identity_id: str | None = None
    domain_id: str | None = None


def default_sender_identity(db: Session, workspace_id: str) -> SenderIdentity | None:
    identity = db.scalar(select(SenderIdentity).where(
        SenderIdentity.workspace_id == workspace_id,
        SenderIdentity.active.is_(True),
        SenderIdentity.is_default.is_(True),
    ).order_by(SenderIdentity.created_at.asc()))
    if identity:
        return identity
    return db.scalar(select(SenderIdentity).where(
        SenderIdentity.workspace_id == workspace_id,
        SenderIdentity.active.is_(True),
    ).order_by(SenderIdentity.created_at.asc()))


def resolve_sender(db: Session, workspace_id: str, *, require_verified: bool, identity_id: str | None = None) -> ResolvedSender | None:
    identity = None
    if identity_id:
        candidate = db.get(SenderIdentity, identity_id)
        if candidate and candidate.workspace_id == workspace_id and candidate.active:
            identity = candidate
    else:
        identity = default_sender_identity(db, workspace_id)
    if identity:
        domain = db.get(SendingDomain, identity.domain_id)
        if domain and domain.workspace_id == workspace_id:
            if not require_verified or domain.ready_for_sending:
                return ResolvedSender(identity.name, identity.email, identity.reply_to or "", identity.id, domain.id)
    if require_verified:
        return None
    legacy = db.scalar(select(SenderSettings).where(SenderSettings.workspace_id == workspace_id))
    if legacy and (legacy.sender_email or "").strip():
        return ResolvedSender(legacy.sender_name or "", legacy.sender_email or "", legacy.reply_to or "")
    return None


def sender_identity_status(identity: SenderIdentity, domain: SendingDomain | None) -> str:
    if not identity.active:
        return "inactive"
    if not domain:
        return "domain_missing"
    if domain.ready_for_sending:
        return "verified"
    return "domain_not_ready"
