from __future__ import annotations

from datetime import datetime, timezone
import uuid

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, JSON, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_id() -> str:
    return str(uuid.uuid4())


class Workspace(Base):
    __tablename__ = "workspaces"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    users = relationship("User", back_populates="workspace", cascade="all, delete-orphan")
    contacts = relationship("Contact", back_populates="workspace", cascade="all, delete-orphan")
    campaigns = relationship("Campaign", back_populates="workspace", cascade="all, delete-orphan")
    contact_lists = relationship("ContactList", back_populates="workspace", cascade="all, delete-orphan")
    segments = relationship("Segment", back_populates="workspace", cascade="all, delete-orphan")
    email_deliveries = relationship("EmailDelivery", back_populates="workspace", cascade="all, delete-orphan")
    sending_domains = relationship("SendingDomain", back_populates="workspace", cascade="all, delete-orphan")
    sender_identities = relationship("SenderIdentity", back_populates="workspace", cascade="all, delete-orphan")
    engagement_events = relationship("EmailEngagementEvent", back_populates="workspace", cascade="all, delete-orphan")
    suppressions = relationship("SuppressionEntry", back_populates="workspace", cascade="all, delete-orphan")
    consent_events = relationship("ConsentEvent", back_populates="workspace", cascade="all, delete-orphan")
    automations = relationship("Automation", back_populates="workspace", cascade="all, delete-orphan")
    automation_runs = relationship("AutomationRun", back_populates="workspace", cascade="all, delete-orphan")
    events = relationship("MarketingEvent", back_populates="workspace", cascade="all, delete-orphan")
    event_communications = relationship("EventCommunication", back_populates="workspace", cascade="all, delete-orphan")


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(512), nullable=False)
    role: Mapped[str] = mapped_column(String(30), default="user", index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="users")
    sessions = relationship("UserSession", back_populates="user", cascade="all, delete-orphan")
    reset_tokens = relationship("PasswordResetToken", back_populates="user", cascade="all, delete-orphan")


class UserSession(Base):
    __tablename__ = "user_sessions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    user_agent: Mapped[str | None] = mapped_column(String(500), nullable=True)

    user = relationship("User", back_populates="sessions")


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True, nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    user = relationship("User", back_populates="reset_tokens")


class SecurityRateLimit(Base):
    __tablename__ = "security_rate_limits"
    __table_args__ = (UniqueConstraint("action", "key_hash", name="uq_security_rate_limit_action_key"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    action: Mapped[str] = mapped_column(String(80), index=True, nullable=False)
    key_hash: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    window_started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    blocked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class ServiceHeartbeat(Base):
    __tablename__ = "service_heartbeats"

    service_name: Mapped[str] = mapped_column(String(80), primary_key=True)
    instance_id: Mapped[str] = mapped_column(String(120), default="", nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="ok", nullable=False, index=True)
    details: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, index=True)


class Contact(Base):
    __tablename__ = "contacts"
    __table_args__ = (UniqueConstraint("workspace_id", "email", name="uq_contact_workspace_email"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(180), default="")
    last_name: Mapped[str] = mapped_column(String(180), default="")
    email: Mapped[str] = mapped_column(String(320), index=True, nullable=False)
    phone: Mapped[str | None] = mapped_column(String(60), nullable=True)
    tags: Mapped[list[str]] = mapped_column(JSON, default=list)
    custom_fields: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(40), default="active", index=True)
    source: Mapped[str] = mapped_column(String(120), default="Manual", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="contacts")
    events = relationship("ContactEvent", back_populates="contact", cascade="all, delete-orphan")


class ContactEvent(Base):
    __tablename__ = "contact_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    contact_id: Mapped[str] = mapped_column(ForeignKey("contacts.id", ondelete="CASCADE"), index=True, nullable=False)
    event_type: Mapped[str] = mapped_column(String(80), index=True, nullable=False)
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    event_data: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)

    contact = relationship("Contact", back_populates="events")


class CustomFieldDefinition(Base):
    __tablename__ = "custom_field_definitions"
    __table_args__ = (UniqueConstraint("workspace_id", "key", name="uq_custom_field_workspace_key"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    key: Mapped[str] = mapped_column(String(80), nullable=False)
    label: Mapped[str] = mapped_column(String(120), nullable=False)
    field_type: Mapped[str] = mapped_column(String(30), default="text")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ContactList(Base):
    __tablename__ = "contact_lists"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    description: Mapped[str] = mapped_column(String(500), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="contact_lists")
    memberships = relationship("ContactListMembership", back_populates="contact_list", cascade="all, delete-orphan")


class ContactListMembership(Base):
    __tablename__ = "contact_list_memberships"
    __table_args__ = (UniqueConstraint("list_id", "contact_id", name="uq_list_contact"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    list_id: Mapped[str] = mapped_column(ForeignKey("contact_lists.id", ondelete="CASCADE"), index=True, nullable=False)
    contact_id: Mapped[str] = mapped_column(ForeignKey("contacts.id", ondelete="CASCADE"), index=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    contact_list = relationship("ContactList", back_populates="memberships")
    contact = relationship("Contact")


class Segment(Base):
    __tablename__ = "segments"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    description: Mapped[str] = mapped_column(String(500), default="")
    match_mode: Mapped[str] = mapped_column(String(20), default="all")
    rules: Mapped[list[dict]] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="segments")


class Campaign(Base):
    __tablename__ = "campaigns"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    subject: Mapped[str] = mapped_column(String(250))
    preheader: Mapped[str] = mapped_column(String(250), default="")
    segment: Mapped[str] = mapped_column(String(180), default="Todos os contatos ativos")
    audience_type: Mapped[str] = mapped_column(String(30), default="all", index=True)
    audience_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(40), default="draft", index=True)
    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    body: Mapped[str] = mapped_column(Text, default="")
    editor_mode: Mapped[str] = mapped_column(String(20), default="visual")
    design_json: Mapped[list[dict]] = mapped_column(JSON, default=list)
    html_body: Mapped[str] = mapped_column(Text, default="")
    sent: Mapped[int] = mapped_column(Integer, default=0)
    delivered: Mapped[int] = mapped_column(Integer, default=0)
    opens: Mapped[int] = mapped_column(Integer, default=0)
    clicks: Mapped[int] = mapped_column(Integer, default=0)
    unsub: Mapped[int] = mapped_column(Integer, default=0)
    bounces: Mapped[int] = mapped_column(Integer, default=0)
    complaints: Mapped[int] = mapped_column(Integer, default=0)
    open_events: Mapped[int] = mapped_column(Integer, default=0)
    click_events: Mapped[int] = mapped_column(Integer, default=0)
    failures: Mapped[int] = mapped_column(Integer, default=0)
    queued_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    send_started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    send_completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    send_armed: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    sender_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    exclude_list_ids: Mapped[list[str]] = mapped_column(JSON, default=list)
    exclude_segment_ids: Mapped[list[str]] = mapped_column(JSON, default=list)
    exclude_tags: Mapped[list[str]] = mapped_column(JSON, default=list)
    utm_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    utm_source: Mapped[str] = mapped_column(String(120), default="mailflow")
    utm_medium: Mapped[str] = mapped_column(String(120), default="email")
    utm_campaign: Mapped[str] = mapped_column(String(180), default="")
    utm_content: Mapped[str] = mapped_column(String(180), default="")
    utm_term: Mapped[str] = mapped_column(String(180), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="campaigns")
    deliveries = relationship("EmailDelivery", back_populates="campaign", cascade="all, delete-orphan")


class Template(Base):
    __tablename__ = "templates"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    name: Mapped[str] = mapped_column(String(180))
    type: Mapped[str] = mapped_column(String(100), default="Personalizado")
    subject: Mapped[str] = mapped_column(String(250))
    preheader: Mapped[str] = mapped_column(String(250), default="")
    body: Mapped[str] = mapped_column(Text, default="")
    editor_mode: Mapped[str] = mapped_column(String(20), default="visual")
    design_json: Mapped[list[dict]] = mapped_column(JSON, default=list)
    html_body: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Automation(Base):
    __tablename__ = "automations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    # Campos legados v0.11 preservados para migração e leitura histórica.
    trigger: Mapped[str] = mapped_column(String(160), default="")
    steps: Mapped[list[str]] = mapped_column(JSON, default=list)
    # Motor estruturado v0.12.
    trigger_type: Mapped[str] = mapped_column(String(40), default="contact_created", index=True)
    trigger_config: Mapped[dict] = mapped_column(JSON, default=dict)
    steps_json: Mapped[list[dict]] = mapped_column(JSON, default=list)
    reentry_policy: Mapped[str] = mapped_column(String(20), default="once")
    sender_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    activated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="automations")
    runs = relationship("AutomationRun", back_populates="automation", cascade="all, delete-orphan")


class AutomationRun(Base):
    __tablename__ = "automation_runs"
    __table_args__ = (UniqueConstraint("automation_id", "trigger_event_id", name="uq_automation_trigger_event"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    automation_id: Mapped[str] = mapped_column(ForeignKey("automations.id", ondelete="CASCADE"), index=True, nullable=False)
    contact_id: Mapped[str | None] = mapped_column(ForeignKey("contacts.id", ondelete="SET NULL"), index=True, nullable=True)
    trigger_event_id: Mapped[str | None] = mapped_column(ForeignKey("contact_events.id", ondelete="SET NULL"), index=True, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="running", index=True)
    current_step: Mapped[int] = mapped_column(Integer, default=0)
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=True, index=True)
    context_json: Mapped[dict] = mapped_column(JSON, default=dict)
    last_error: Mapped[str] = mapped_column(String(1000), default="")
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="automation_runs")
    automation = relationship("Automation", back_populates="runs")
    contact = relationship("Contact")
    executions = relationship("AutomationStepExecution", back_populates="run", cascade="all, delete-orphan")


class AutomationStepExecution(Base):
    __tablename__ = "automation_step_executions"
    __table_args__ = (UniqueConstraint("run_id", "step_index", name="uq_automation_run_step"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    run_id: Mapped[str] = mapped_column(ForeignKey("automation_runs.id", ondelete="CASCADE"), index=True, nullable=False)
    step_index: Mapped[int] = mapped_column(Integer, nullable=False)
    step_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(30), default="completed", index=True)
    output_json: Mapped[dict] = mapped_column(JSON, default=dict)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    run = relationship("AutomationRun", back_populates="executions")


class AutomationTriggerReceipt(Base):
    __tablename__ = "automation_trigger_receipts"
    __table_args__ = (UniqueConstraint("automation_id", "event_id", name="uq_automation_event_receipt"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    automation_id: Mapped[str] = mapped_column(ForeignKey("automations.id", ondelete="CASCADE"), index=True, nullable=False)
    event_id: Mapped[str] = mapped_column(ForeignKey("contact_events.id", ondelete="CASCADE"), index=True, nullable=False)
    matched: Mapped[bool] = mapped_column(Boolean, default=False)
    run_id: Mapped[str | None] = mapped_column(ForeignKey("automation_runs.id", ondelete="SET NULL"), nullable=True)
    processed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


class MarketingEvent(Base):
    __tablename__ = "marketing_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    event_type: Mapped[str] = mapped_column(String(40), default="online_event", index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(30), default="draft", index=True)
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    end_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    timezone: Mapped[str] = mapped_column(String(80), default="America/Belem")
    platform: Mapped[str] = mapped_column(String(80), default="Zoom")
    access_url: Mapped[str] = mapped_column(String(1000), default="")
    audience_type: Mapped[str] = mapped_column(String(30), default="all")
    audience_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    sender_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    offer_open_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    offer_close_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    registration_automation_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="events")
    communications = relationship("EventCommunication", back_populates="event", cascade="all, delete-orphan")


class EventCommunication(Base):
    __tablename__ = "event_communications"
    __table_args__ = (UniqueConstraint("event_id", "system_key", name="uq_event_communication_system_key"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    event_id: Mapped[str] = mapped_column(ForeignKey("marketing_events.id", ondelete="CASCADE"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    phase: Mapped[str] = mapped_column(String(40), default="pre_event", index=True)
    relative_to: Mapped[str] = mapped_column(String(40), default="event_start")
    offset_minutes: Mapped[int] = mapped_column(Integer, default=0)
    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    template_id: Mapped[str | None] = mapped_column(ForeignKey("templates.id", ondelete="SET NULL"), nullable=True, index=True)
    campaign_id: Mapped[str | None] = mapped_column(ForeignKey("campaigns.id", ondelete="SET NULL"), nullable=True, index=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    system_key: Mapped[str | None] = mapped_column(String(80), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="event_communications")
    event = relationship("MarketingEvent", back_populates="communications")
    template = relationship("Template")
    campaign = relationship("Campaign")


class SendingDomain(Base):
    __tablename__ = "sending_domains"
    __table_args__ = (UniqueConstraint("workspace_id", "name", name="uq_sending_domain_workspace_name"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    provider: Mapped[str] = mapped_column(String(40), default="resend", index=True)
    provider_domain_id: Mapped[str | None] = mapped_column(String(160), nullable=True, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(253), nullable=False, index=True)
    region: Mapped[str] = mapped_column(String(40), default="us-east-1")
    custom_return_path: Mapped[str] = mapped_column(String(63), default="send")
    tracking_subdomain: Mapped[str] = mapped_column(String(63), default="links")
    open_tracking: Mapped[bool] = mapped_column(Boolean, default=True)
    click_tracking: Mapped[bool] = mapped_column(Boolean, default=True)
    tls_mode: Mapped[str] = mapped_column(String(30), default="opportunistic")
    provider_status: Mapped[str] = mapped_column(String(50), default="not_started", index=True)
    dns_records: Mapped[list[dict]] = mapped_column(JSON, default=list)
    spf_status: Mapped[str] = mapped_column(String(40), default="not_started")
    dkim_status: Mapped[str] = mapped_column(String(40), default="not_started")
    tracking_status: Mapped[str] = mapped_column(String(40), default="not_started")
    dmarc_status: Mapped[str] = mapped_column(String(40), default="not_checked")
    dmarc_policy: Mapped[str] = mapped_column(String(20), default="none")
    dmarc_report_email: Mapped[str] = mapped_column(String(320), default="")
    dmarc_value: Mapped[str] = mapped_column(String(1000), default="")
    dmarc_found_values: Mapped[list[str]] = mapped_column(JSON, default=list)
    ready_for_sending: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str] = mapped_column(String(1000), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="sending_domains")
    sender_identities = relationship("SenderIdentity", back_populates="domain", cascade="all, delete-orphan")


class SenderIdentity(Base):
    __tablename__ = "sender_identities"
    __table_args__ = (UniqueConstraint("workspace_id", "email", name="uq_sender_identity_workspace_email"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    domain_id: Mapped[str] = mapped_column(ForeignKey("sending_domains.id", ondelete="CASCADE"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(180), default="Sua Marca")
    email: Mapped[str] = mapped_column(String(320), index=True, nullable=False)
    reply_to: Mapped[str] = mapped_column(String(320), default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="sender_identities")
    domain = relationship("SendingDomain", back_populates="sender_identities")


class SenderSettings(Base):
    __tablename__ = "sender_settings"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), unique=True, index=True)
    sender_name: Mapped[str] = mapped_column(String(180), default="Sua Marca")
    sender_email: Mapped[str] = mapped_column(String(320), default="")
    reply_to: Mapped[str] = mapped_column(String(320), default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class EmailDelivery(Base):
    __tablename__ = "email_deliveries"
    __table_args__ = (
        UniqueConstraint("campaign_id", "contact_id", "is_test", "recipient_email", name="uq_delivery_campaign_recipient"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    campaign_id: Mapped[str | None] = mapped_column(ForeignKey("campaigns.id", ondelete="CASCADE"), index=True, nullable=True)
    automation_run_id: Mapped[str | None] = mapped_column(ForeignKey("automation_runs.id", ondelete="SET NULL"), index=True, nullable=True)
    automation_step_index: Mapped[int | None] = mapped_column(Integer, nullable=True)
    contact_id: Mapped[str | None] = mapped_column(ForeignKey("contacts.id", ondelete="SET NULL"), index=True, nullable=True)
    recipient_email: Mapped[str] = mapped_column(String(320), index=True, nullable=False)
    recipient_name: Mapped[str] = mapped_column(String(240), default="")
    is_test: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    status: Mapped[str] = mapped_column(String(40), default="queued", index=True)
    provider: Mapped[str] = mapped_column(String(40), default="console", index=True)
    provider_message_id: Mapped[str | None] = mapped_column(String(160), nullable=True, index=True)
    idempotency_key: Mapped[str] = mapped_column(String(256), unique=True, index=True, nullable=False)
    subject_snapshot: Mapped[str] = mapped_column(String(250), default="")
    html_snapshot: Mapped[str] = mapped_column(Text, default="")
    text_snapshot: Mapped[str] = mapped_column(Text, default="")
    sender_name_snapshot: Mapped[str] = mapped_column(String(180), default="")
    sender_email_snapshot: Mapped[str] = mapped_column(String(320), default="")
    reply_to_snapshot: Mapped[str] = mapped_column(String(320), default="")
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=4)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    last_error: Mapped[str] = mapped_column(String(1000), default="")
    last_event_type: Mapped[str] = mapped_column(String(100), default="")
    queued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    opened_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    clicked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    bounced_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    complained_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    unsubscribed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    failed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    workspace = relationship("Workspace", back_populates="email_deliveries")
    campaign = relationship("Campaign", back_populates="deliveries")
    contact = relationship("Contact")
    engagement_events = relationship("EmailEngagementEvent", back_populates="delivery", cascade="all, delete-orphan")



class SuppressionEntry(Base):
    __tablename__ = "suppression_entries"
    __table_args__ = (UniqueConstraint("workspace_id", "email_hash", name="uq_suppression_workspace_hash"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    contact_id: Mapped[str | None] = mapped_column(ForeignKey("contacts.id", ondelete="SET NULL"), index=True, nullable=True)
    campaign_id: Mapped[str | None] = mapped_column(ForeignKey("campaigns.id", ondelete="SET NULL"), index=True, nullable=True)
    email_hash: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    email_hint: Mapped[str] = mapped_column(String(320), default="")
    reason: Mapped[str] = mapped_column(String(40), default="manual", index=True)
    source: Mapped[str] = mapped_column(String(80), default="manual")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    workspace = relationship("Workspace", back_populates="suppressions")
    contact = relationship("Contact")
    campaign = relationship("Campaign")


class ConsentEvent(Base):
    __tablename__ = "consent_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    contact_id: Mapped[str | None] = mapped_column(ForeignKey("contacts.id", ondelete="SET NULL"), index=True, nullable=True)
    email_hash: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    email_hint: Mapped[str] = mapped_column(String(320), default="")
    action: Mapped[str] = mapped_column(String(30), index=True, nullable=False)
    legal_basis: Mapped[str] = mapped_column(String(80), default="consent")
    source: Mapped[str] = mapped_column(String(160), default="manual")
    purpose: Mapped[str] = mapped_column(String(120), default="email_marketing")
    notice_version: Mapped[str] = mapped_column(String(80), default="")
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)

    workspace = relationship("Workspace", back_populates="consent_events")
    contact = relationship("Contact")

class EmailEngagementEvent(Base):
    __tablename__ = "email_engagement_events"
    __table_args__ = (UniqueConstraint("provider", "provider_event_id", name="uq_engagement_provider_event"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    campaign_id: Mapped[str | None] = mapped_column(ForeignKey("campaigns.id", ondelete="CASCADE"), index=True, nullable=True)
    delivery_id: Mapped[str] = mapped_column(ForeignKey("email_deliveries.id", ondelete="CASCADE"), index=True, nullable=False)
    contact_id: Mapped[str | None] = mapped_column(ForeignKey("contacts.id", ondelete="SET NULL"), index=True, nullable=True)
    provider: Mapped[str] = mapped_column(String(40), index=True, nullable=False)
    provider_event_id: Mapped[str] = mapped_column(String(180), index=True, nullable=False)
    event_type: Mapped[str] = mapped_column(String(40), index=True, nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    link_url: Mapped[str] = mapped_column(Text, default="")
    link_host: Mapped[str] = mapped_column(String(255), default="", index=True)
    ip_address: Mapped[str] = mapped_column(String(80), default="")
    user_agent: Mapped[str] = mapped_column(String(1000), default="")
    event_data: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)

    workspace = relationship("Workspace", back_populates="engagement_events")
    delivery = relationship("EmailDelivery", back_populates="engagement_events")
    campaign = relationship("Campaign")
    contact = relationship("Contact")


class WebhookEvent(Base):
    __tablename__ = "webhook_events"
    __table_args__ = (UniqueConstraint("provider", "provider_event_id", name="uq_webhook_provider_event"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    provider: Mapped[str] = mapped_column(String(40), index=True, nullable=False)
    provider_event_id: Mapped[str] = mapped_column(String(180), index=True, nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), index=True, nullable=False)
    provider_message_id: Mapped[str | None] = mapped_column(String(180), index=True, nullable=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    processed: Mapped[bool] = mapped_column(Boolean, default=False)
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
