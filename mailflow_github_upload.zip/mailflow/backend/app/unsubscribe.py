from __future__ import annotations

import base64
import hashlib
import hmac
import html
import json
import os
from datetime import datetime, timezone
from urllib.parse import urljoin

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import ConsentEvent, Contact, ContactEvent, EmailDelivery, SuppressionEntry


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def normalize_email(email: str) -> str:
    return (email or '').strip().lower()


def _secret(name: str, fallback: str) -> bytes:
    return (os.getenv(name, '').strip() or fallback).encode('utf-8')


def email_hash(email: str) -> str:
    normalized = normalize_email(email)
    return hmac.new(_secret('MAILFLOW_SUPPRESSION_SECRET', 'mailflow-dev-suppression-change-me'), normalized.encode(), hashlib.sha256).hexdigest()


def mask_email(email: str) -> str:
    email = normalize_email(email)
    if '@' not in email:
        return '***'
    local, domain = email.split('@', 1)
    visible = local[:1] if local else ''
    return f"{visible}{'*' * max(3, min(8, max(1, len(local)-1)))}@{domain}"


def find_suppression(db: Session, workspace_id: str, email: str) -> SuppressionEntry | None:
    return db.scalar(select(SuppressionEntry).where(
        SuppressionEntry.workspace_id == workspace_id,
        SuppressionEntry.email_hash == email_hash(email),
        SuppressionEntry.active.is_(True),
    ))


def status_for_reason(reason: str) -> str:
    return {
        'unsubscribe': 'unsubscribed',
        'complaint': 'blocked',
        'hard_bounce': 'bounce',
        'manual': 'blocked',
        'privacy_delete': 'blocked',
    }.get(reason, 'blocked')


def add_suppression(
    db: Session,
    workspace_id: str,
    email: str,
    *,
    reason: str,
    source: str,
    contact_id: str | None = None,
    campaign_id: str | None = None,
    metadata: dict | None = None,
) -> SuppressionEntry:
    normalized = normalize_email(email)
    digest = email_hash(normalized)
    item = db.scalar(select(SuppressionEntry).where(
        SuppressionEntry.workspace_id == workspace_id,
        SuppressionEntry.email_hash == digest,
    ))
    if not item:
        item = SuppressionEntry(
            workspace_id=workspace_id,
            email_hash=digest,
            email_hint=mask_email(normalized),
            reason=reason,
            source=source,
            contact_id=contact_id,
            campaign_id=campaign_id,
            metadata_json=metadata or {},
            active=True,
        )
        db.add(item)
    else:
        item.active = True
        item.reason = reason
        item.source = source
        item.contact_id = contact_id or item.contact_id
        item.campaign_id = campaign_id or item.campaign_id
        item.metadata_json = {**(item.metadata_json or {}), **(metadata or {})}
        item.released_at = None
        item.updated_at = utcnow()

    contact = db.get(Contact, contact_id) if contact_id else db.scalar(select(Contact).where(
        Contact.workspace_id == workspace_id,
        Contact.email == normalized,
    ))
    if contact and contact.workspace_id == workspace_id:
        contact.status = status_for_reason(reason)
        db.add(ContactEvent(
            workspace_id=workspace_id,
            contact_id=contact.id,
            event_type='suppressed',
            description=f'Contato incluído na supressão global: {reason}.',
            event_data={'reason': reason, 'source': source, 'campaign_id': campaign_id},
        ))
    return item


def release_suppression(db: Session, item: SuppressionEntry, *, source: str) -> None:
    item.active = False
    item.released_at = utcnow()
    item.updated_at = utcnow()
    item.metadata_json = {**(item.metadata_json or {}), 'released_source': source}
    if item.contact_id:
        contact = db.get(Contact, item.contact_id)
        if contact and contact.workspace_id == item.workspace_id:
            contact.status = 'active'
            db.add(ContactEvent(
                workspace_id=item.workspace_id,
                contact_id=contact.id,
                event_type='suppression_released',
                description='Supressão removida após novo registro de consentimento.',
                event_data={'source': source},
            ))


def record_consent(
    db: Session,
    workspace_id: str,
    email: str,
    *,
    contact_id: str | None,
    action: str,
    legal_basis: str,
    source: str,
    purpose: str = 'email_marketing',
    notice_version: str = '',
    evidence: dict | None = None,
) -> ConsentEvent:
    event = ConsentEvent(
        workspace_id=workspace_id,
        contact_id=contact_id,
        email_hash=email_hash(email),
        email_hint=mask_email(email),
        action=action,
        legal_basis=legal_basis,
        source=source,
        purpose=purpose,
        notice_version=notice_version,
        evidence=evidence or {},
    )
    db.add(event)
    return event


def make_unsubscribe_token(delivery_id: str) -> str:
    payload = json.dumps({'d': delivery_id}, separators=(',', ':')).encode('utf-8')
    encoded = base64.urlsafe_b64encode(payload).rstrip(b'=')
    sig = hmac.new(_secret('MAILFLOW_UNSUBSCRIBE_SECRET', 'mailflow-dev-unsubscribe-change-me'), encoded, hashlib.sha256).digest()
    return f"{encoded.decode()}.{base64.urlsafe_b64encode(sig).rstrip(b'=').decode()}"


def parse_unsubscribe_token(token: str) -> str | None:
    try:
        raw_payload, raw_sig = token.split('.', 1)
        encoded = raw_payload.encode()
        expected = hmac.new(_secret('MAILFLOW_UNSUBSCRIBE_SECRET', 'mailflow-dev-unsubscribe-change-me'), encoded, hashlib.sha256).digest()
        pad = '=' * (-len(raw_sig) % 4)
        sig = base64.urlsafe_b64decode(raw_sig + pad)
        if not hmac.compare_digest(expected, sig):
            return None
        payload_pad = '=' * (-len(raw_payload) % 4)
        data = json.loads(base64.urlsafe_b64decode(raw_payload + payload_pad).decode())
        return str(data.get('d') or '') or None
    except Exception:
        return None


def public_base_url() -> str:
    return os.getenv('MAILFLOW_PUBLIC_BASE_URL', 'http://localhost:8080').rstrip('/')


def unsubscribe_url(delivery_id: str) -> str:
    return f"{public_base_url()}/api/unsubscribe/{make_unsubscribe_token(delivery_id)}"


def inject_unsubscribe_footer(html_body: str, text_body: str, url: str, workspace_name: str) -> tuple[str, str]:
    safe_url = html.escape(url, quote=True)
    safe_ws = html.escape(workspace_name or 'esta lista')
    footer = (
        '<div data-mailflow-unsubscribe="true" style="margin-top:32px;padding-top:20px;border-top:1px solid #e5e7eb;'
        'font-family:Arial,sans-serif;font-size:12px;line-height:1.5;color:#6b7280;text-align:center">'
        f'Você recebeu este e-mail porque está na lista de {safe_ws}. '
        f'<a href="{safe_url}" style="color:#4b5563;text-decoration:underline">Cancelar inscrição</a>.'
        '</div>'
    )
    html_result = (html_body or '') + footer
    text_footer = f"\n\n---\nCancelar inscrição: {url}"
    return html_result, (text_body or '') + text_footer


def unsubscribe_headers(url: str) -> dict[str, str]:
    return {
        'List-Unsubscribe': f'<{url}>',
        'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click',
    }


def unsubscribe_readiness() -> dict:
    base = public_base_url()
    https = base.startswith("https://")
    secret = os.getenv("MAILFLOW_UNSUBSCRIBE_SECRET", "").strip()
    suppression_secret = os.getenv("MAILFLOW_SUPPRESSION_SECRET", "").strip()
    errors = []
    if not https:
        errors.append("MAILFLOW_PUBLIC_BASE_URL precisa usar HTTPS em produção para one-click unsubscribe.")
    if len(secret) < 24:
        errors.append("MAILFLOW_UNSUBSCRIBE_SECRET precisa ser configurado com um segredo forte.")
    if len(suppression_secret) < 24:
        errors.append("MAILFLOW_SUPPRESSION_SECRET precisa ser configurado com um segredo forte e estável.")
    return {"ready": not errors, "public_base_url": base, "errors": errors}
