from __future__ import annotations

from datetime import timedelta
import hashlib
import hmac
import os

from fastapi import HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .config import settings, env_bool
from .models import SecurityRateLimit
from .security import utcnow

_SECURITY_SECRET = os.getenv("MAILFLOW_SECURITY_SECRET", "dev-mailflow-security-secret-change-me")


def _hash_identity(action: str, identity: str) -> str:
    msg = f"{action}:{identity.strip().lower()}".encode("utf-8")
    return hmac.new(_SECURITY_SECRET.encode("utf-8"), msg, hashlib.sha256).hexdigest()


def request_ip(request: Request) -> str:
    if settings.trust_proxy_headers:
        forwarded = (request.headers.get("x-forwarded-for") or "").split(",", 1)[0].strip()
        if forwarded:
            return forwarded[:80]
        real = (request.headers.get("x-real-ip") or "").strip()
        if real:
            return real[:80]
    return (request.client.host if request.client else "unknown")[:80]


def consume(db: Session, *, action: str, identity: str, limit: int, window_seconds: int, block_seconds: int) -> None:
    if not env_bool("MAILFLOW_RATE_LIMIT_ENABLED", False):
        return
    now = utcnow()
    key_hash = _hash_identity(action, identity)
    row = db.scalar(select(SecurityRateLimit).where(
        SecurityRateLimit.action == action,
        SecurityRateLimit.key_hash == key_hash,
    ).with_for_update())
    if not row:
        row = SecurityRateLimit(action=action, key_hash=key_hash, attempts=0, window_started_at=now)
        db.add(row)
        try:
            db.flush()
        except IntegrityError:
            # Another API replica may have created the same bucket concurrently.
            db.rollback()
            row = db.scalar(select(SecurityRateLimit).where(
                SecurityRateLimit.action == action,
                SecurityRateLimit.key_hash == key_hash,
            ).with_for_update())
            if not row:
                raise

    blocked_until = row.blocked_until
    if blocked_until is not None and blocked_until.tzinfo is None:
        blocked_until = blocked_until.replace(tzinfo=now.tzinfo)
    started = row.window_started_at
    if started is not None and started.tzinfo is None:
        started = started.replace(tzinfo=now.tzinfo)

    if blocked_until and blocked_until > now:
        retry = max(1, int((blocked_until - now).total_seconds()))
        db.commit()
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Muitas tentativas. Tente novamente mais tarde.", headers={"Retry-After": str(retry)})

    if not started or (now - started).total_seconds() >= window_seconds:
        row.window_started_at = now
        row.attempts = 0
        row.blocked_until = None

    if row.attempts >= limit:
        row.blocked_until = now + timedelta(seconds=block_seconds)
        db.commit()
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Muitas tentativas. Tente novamente mais tarde.", headers={"Retry-After": str(block_seconds)})

    row.attempts += 1
    row.updated_at = now
    db.commit()


def reset(db: Session, *, action: str, identity: str) -> None:
    if not env_bool("MAILFLOW_RATE_LIMIT_ENABLED", False):
        return
    key_hash = _hash_identity(action, identity)
    row = db.scalar(select(SecurityRateLimit).where(
        SecurityRateLimit.action == action,
        SecurityRateLimit.key_hash == key_hash,
    ))
    if row:
        db.delete(row)
        db.commit()
