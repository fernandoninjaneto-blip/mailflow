from __future__ import annotations

from datetime import date, datetime
from typing import Any, Iterable

from .models import Contact


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _norm(value: Any) -> str:
    return _text(value).casefold()


def _contact_value(contact: Contact, field: str, custom_key: str | None = None) -> Any:
    if field == "status":
        return contact.status
    if field == "source":
        return contact.source
    if field == "email":
        return contact.email
    if field == "name":
        return " ".join(x for x in [contact.name, contact.last_name] if x).strip()
    if field == "phone":
        return contact.phone or ""
    if field == "created_at":
        return contact.created_at
    if field == "tag":
        return contact.tags or []
    if field == "custom":
        return (contact.custom_fields or {}).get(custom_key or "")
    return None


def _date_value(value: Any) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(_text(value)[:10])
    except ValueError:
        return None


def matches_rule(contact: Contact, rule: dict[str, Any]) -> bool:
    field = _text(rule.get("field"))
    operator = _text(rule.get("operator"))
    wanted = rule.get("value")
    current = _contact_value(contact, field, _text(rule.get("custom_key")) or None)

    if field == "tag":
        tags = [_norm(tag) for tag in (current or [])]
        target = _norm(wanted)
        if operator in {"contains", "equals"}:
            return target in tags
        if operator in {"not_contains", "not_equals"}:
            return target not in tags
        if operator == "is_set":
            return bool(tags)
        if operator == "not_set":
            return not tags
        return False

    if field == "created_at":
        left, right = _date_value(current), _date_value(wanted)
        if operator == "is_set":
            return left is not None
        if operator == "not_set":
            return left is None
        if left is None or right is None:
            return False
        if operator == "before":
            return left < right
        if operator == "after":
            return left > right
        if operator == "equals":
            return left == right
        if operator == "not_equals":
            return left != right
        return False

    if operator == "is_set":
        return _text(current) != ""
    if operator == "not_set":
        return _text(current) == ""

    left, right = _norm(current), _norm(wanted)
    if operator == "equals":
        return left == right
    if operator == "not_equals":
        return left != right
    if operator == "contains":
        return right in left
    if operator == "not_contains":
        return right not in left
    if operator == "starts_with":
        return left.startswith(right)
    if operator == "ends_with":
        return left.endswith(right)
    return False


def filter_contacts(contacts: Iterable[Contact], rules: list[dict[str, Any]], match_mode: str = "all") -> list[Contact]:
    rules = rules or []
    if not rules:
        return list(contacts)
    predicate = all if match_mode == "all" else any
    return [contact for contact in contacts if predicate(matches_rule(contact, rule) for rule in rules)]
