from __future__ import annotations

import logging
import time
import uuid
from urllib.parse import urlparse

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from .config import settings
from .security import CSRF_COOKIE, SESSION_COOKIE, verify_csrf_token

logger = logging.getLogger("mailflow.http")

SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}
PUBLIC_UNSAFE_PREFIXES = ("/api/webhooks/", "/api/unsubscribe/")
CSRF_EXEMPT = {
    "/api/auth/login",
    "/api/auth/register",
    "/api/auth/forgot-password",
    "/api/auth/reset-password",
}


def _normalize_origin(value: str) -> str:
    parsed = urlparse(value)
    if not parsed.scheme or not parsed.netloc:
        return ""
    return f"{parsed.scheme}://{parsed.netloc}".rstrip("/")


class ProductionSecurityMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        method = request.method.upper()
        unsafe = method not in SAFE_METHODS
        public_unsafe = any(path.startswith(prefix) for prefix in PUBLIC_UNSAFE_PREFIXES)

        if settings.origin_check_enabled and unsafe and not public_unsafe:
            origin = request.headers.get("origin")
            referer = request.headers.get("referer")
            candidate = _normalize_origin(origin or referer or "")
            trusted = {_normalize_origin(x) for x in settings.trusted_origins}
            if not candidate or candidate not in trusted:
                return JSONResponse(status_code=403, content={"detail": "Origem da requisição não autorizada."})

        if settings.csrf_enabled and unsafe and not public_unsafe and path not in CSRF_EXEMPT:
            session_token = request.cookies.get(SESSION_COOKIE)
            if session_token:
                cookie_token = request.cookies.get(CSRF_COOKIE) or ""
                header_token = request.headers.get("x-csrf-token") or ""
                if not cookie_token or not header_token or cookie_token != header_token or not verify_csrf_token(session_token, header_token):
                    return JSONResponse(status_code=403, content={"detail": "Token CSRF ausente ou inválido."})

        start = time.perf_counter()
        request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
        try:
            response = await call_next(request)
        except Exception:
            logger.exception("request_failed", extra={"request_id": request_id, "method": method, "path": path})
            raise
        duration_ms = round((time.perf_counter() - start) * 1000, 2)
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: https:; connect-src 'self'; frame-src 'self' data: blob:; "
            "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
        )
        if path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        if settings.production_like:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        logger.info("request", extra={"request_id": request_id, "method": method, "path": path, "status_code": response.status_code, "duration_ms": duration_ms})
        return response
