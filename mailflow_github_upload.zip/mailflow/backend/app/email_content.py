from __future__ import annotations

import html
import re
from typing import Any

_VAR_RE = re.compile(r"\{\{\s*([\w.-]+)(?:\|([^{}]*))?\s*\}\}")
_TAG_RE = re.compile(r"<[^>]+>")


def _safe_url(value: str, *, image: bool = False) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    lowered = value.lower()
    allowed = ("https://", "http://") if image else ("https://", "http://", "mailto:", "tel:")
    return value if lowered.startswith(allowed) else ""


def substitute_variables(text: str, context: dict[str, Any] | None = None, *, escape_values: bool = False) -> str:
    context = context or {}
    flattened = dict(context)
    custom = context.get("custom_fields") or {}
    if isinstance(custom, dict):
        for key, value in custom.items():
            flattened.setdefault(str(key), value)

    aliases = {
        "nome": "name",
        "sobrenome": "last_name",
        "empresa": "workspace_name",
    }

    def repl(match: re.Match[str]) -> str:
        key = match.group(1)
        fallback = (match.group(2) or "").strip()
        lookup = aliases.get(key, key)
        value = flattened.get(lookup)
        if value is None or str(value).strip() == "":
            value = fallback
        result = str(value)
        return html.escape(result, quote=True) if escape_values else result

    return _VAR_RE.sub(repl, text or "")


def blocks_to_plain_text(blocks: list[dict] | None) -> str:
    parts: list[str] = []
    for block in blocks or []:
        kind = block.get("type")
        data = block.get("data") or {}
        if kind in {"heading", "text"}:
            parts.append(str(data.get("text") or ""))
        elif kind == "button":
            label = str(data.get("text") or "")
            url = str(data.get("url") or "")
            parts.append(f"{label}: {url}" if url else label)
        elif kind == "image" and data.get("alt"):
            parts.append(str(data.get("alt")))
    return "\n\n".join(p for p in parts if p.strip())


def html_to_plain_text(value: str) -> str:
    value = re.sub(r"<\s*(br|/p|/div|/h[1-6]|/li)\s*/?>", "\n", value or "", flags=re.I)
    value = _TAG_RE.sub("", value)
    value = html.unescape(value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def _align(value: str) -> str:
    return value if value in {"left", "center", "right"} else "left"


def _color(value: str, default: str) -> str:
    value = (value or "").strip()
    return value if re.fullmatch(r"#[0-9a-fA-F]{6}", value) else default


def _num(value: Any, default: int, low: int, high: int) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        n = default
    return max(low, min(high, n))


def render_visual_blocks(blocks: list[dict] | None) -> str:
    rows: list[str] = []
    for block in blocks or []:
        kind = block.get("type")
        data = block.get("data") or {}
        if kind == "heading":
            level = str(data.get("level") or "h2").lower()
            if level not in {"h1", "h2", "h3"}:
                level = "h2"
            size = _num(data.get("font_size"), {"h1": 34, "h2": 28, "h3": 22}[level], 14, 52)
            align = _align(str(data.get("align") or "left"))
            color = _color(str(data.get("color") or ""), "#16181d")
            text = html.escape(str(data.get("text") or ""), quote=False).replace("\n", "<br>")
            rows.append(f'<tr><td style="padding:12px 32px;text-align:{align}"><{level} style="margin:0;color:{color};font-family:Arial,sans-serif;font-size:{size}px;line-height:1.2">{text}</{level}></td></tr>')
        elif kind == "text":
            size = _num(data.get("font_size"), 16, 11, 28)
            align = _align(str(data.get("align") or "left"))
            color = _color(str(data.get("color") or ""), "#3f4350")
            text = html.escape(str(data.get("text") or ""), quote=False).replace("\n", "<br>")
            rows.append(f'<tr><td style="padding:10px 32px;text-align:{align};color:{color};font-family:Arial,sans-serif;font-size:{size}px;line-height:1.6">{text}</td></tr>')
        elif kind == "image":
            src = _safe_url(str(data.get("url") or ""), image=True)
            if not src:
                continue
            width = _num(data.get("width"), 100, 10, 100)
            alt = html.escape(str(data.get("alt") or ""), quote=True)
            img = f'<img src="{html.escape(src, quote=True)}" alt="{alt}" width="{width}%" style="display:inline-block;max-width:100%;height:auto;border:0;border-radius:8px">'
            link = _safe_url(str(data.get("link") or ""))
            if link:
                img = f'<a href="{html.escape(link, quote=True)}" target="_blank" style="text-decoration:none">{img}</a>'
            rows.append(f'<tr><td style="padding:12px 32px;text-align:center">{img}</td></tr>')
        elif kind == "button":
            label = html.escape(str(data.get("text") or "Clique em saiba mais"), quote=False)
            url = _safe_url(str(data.get("url") or "")) or "#"
            align = _align(str(data.get("align") or "left"))
            bg = _color(str(data.get("bg_color") or ""), "#2427d8")
            fg = _color(str(data.get("text_color") or ""), "#ffffff")
            radius = _num(data.get("radius"), 8, 0, 30)
            rows.append(f'<tr><td style="padding:14px 32px;text-align:{align}"><a href="{html.escape(url, quote=True)}" target="_blank" style="display:inline-block;background:{bg};color:{fg};font-family:Arial,sans-serif;font-size:15px;font-weight:bold;text-decoration:none;padding:12px 20px;border-radius:{radius}px">{label}</a></td></tr>')
        elif kind == "divider":
            color = _color(str(data.get("color") or ""), "#e5e7eb")
            rows.append(f'<tr><td style="padding:14px 32px"><div style="border-top:1px solid {color};font-size:1px;line-height:1px">&nbsp;</div></td></tr>')
        elif kind == "spacer":
            height = _num(data.get("height"), 24, 4, 120)
            rows.append(f'<tr><td height="{height}" style="height:{height}px;font-size:1px;line-height:1px">&nbsp;</td></tr>')

    inner = "".join(rows) or '<tr><td style="padding:36px 32px;color:#777;font-family:Arial,sans-serif;text-align:center">Adicione blocos ao seu e-mail.</td></tr>'
    return f'''<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f5f7">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;background:#f4f5f7"><tr><td align="center" style="padding:28px 12px">
<table role="presentation" width="600" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:600px;background:#ffffff;border-radius:10px;overflow:hidden">{inner}</table>
</td></tr></table></body></html>'''


def ensure_html_document(value: str) -> str:
    value = (value or "").strip()
    if not value:
        return "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head><body></body></html>"
    if re.search(r"<html[\s>]", value, flags=re.I):
        return value
    return f'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>{value}</body></html>'


def normalize_email_fields(data: dict[str, Any], existing: Any | None = None) -> dict[str, Any]:
    """Mantém editor_mode/design/html/body coerentes antes de persistir."""
    mode = data.get("editor_mode", getattr(existing, "editor_mode", "visual") if existing else "visual") or "visual"
    design = data.get("design_json", getattr(existing, "design_json", []) if existing else []) or []
    html_body = data.get("html_body", getattr(existing, "html_body", "") if existing else "") or ""
    old_body = data.get("body", getattr(existing, "body", "") if existing else "") or ""

    if mode == "visual":
        if not design and old_body.strip():
            design = [{"type": "text", "data": {"text": old_body, "align": "left", "font_size": 16, "color": "#3f4350"}}]
        html_body = render_visual_blocks(design)
        body = blocks_to_plain_text(design)
    else:
        html_body = ensure_html_document(html_body or old_body)
        body = html_to_plain_text(html_body)
        design = design if isinstance(design, list) else []

    data["editor_mode"] = mode
    data["design_json"] = design
    data["html_body"] = html_body
    data["body"] = body
    return data


def render_with_context(subject: str, preheader: str, html_body: str, context: dict[str, Any]) -> dict[str, str]:
    return {
        "subject": substitute_variables(subject, context),
        "preheader": substitute_variables(preheader, context),
        "html": substitute_variables(html_body, context, escape_values=True),
    }
