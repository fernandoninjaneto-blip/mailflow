import os

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import DeclarativeBase, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mailflow.db")

if DATABASE_URL.startswith("sqlite"):
    connect_args = {"check_same_thread": False}
    engine = create_engine(DATABASE_URL, pool_pre_ping=True, connect_args=connect_args)
else:
    connect_args = {"connect_timeout": int(os.getenv("DB_CONNECT_TIMEOUT_SECONDS", "10"))}
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,
        pool_size=max(1, int(os.getenv("DB_POOL_SIZE", "5"))),
        max_overflow=max(0, int(os.getenv("DB_MAX_OVERFLOW", "10"))),
        pool_recycle=max(60, int(os.getenv("DB_POOL_RECYCLE_SECONDS", "1800"))),
        connect_args=connect_args,
    )
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


class Base(DeclarativeBase):
    pass


def migrate_schema() -> None:
    """Pequena migração compatível com as versões anteriores.

    Preserva a base existente ao abrir a v0.13. As novas tabelas de eventos são criadas pelo metadata.
    Migrações formais com Alembic entram antes de produção pública.
    """
    inspector = inspect(engine)
    if "contacts" not in inspector.get_table_names():
        return
    columns = {c["name"] for c in inspector.get_columns("contacts")}
    statements: list[str] = []
    if "last_name" not in columns:
        statements.append("ALTER TABLE contacts ADD COLUMN last_name VARCHAR(180) DEFAULT '' NOT NULL")
    if "custom_fields" not in columns:
        statements.append("ALTER TABLE contacts ADD COLUMN custom_fields JSON DEFAULT '{}' NOT NULL")
    if "campaigns" in inspector.get_table_names():
        campaign_columns = {c["name"] for c in inspector.get_columns("campaigns")}
        if "audience_type" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN audience_type VARCHAR(30) DEFAULT 'all' NOT NULL")
        if "audience_id" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN audience_id VARCHAR(36)")
        if "editor_mode" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN editor_mode VARCHAR(20) DEFAULT 'visual' NOT NULL")
        if "design_json" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN design_json JSON DEFAULT '[]' NOT NULL")
        if "html_body" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN html_body TEXT DEFAULT '' NOT NULL")
        if "bounces" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN bounces INTEGER DEFAULT 0 NOT NULL")
        if "complaints" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN complaints INTEGER DEFAULT 0 NOT NULL")
        if "failures" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN failures INTEGER DEFAULT 0 NOT NULL")
        if "queued_at" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN queued_at DATETIME")
        if "send_started_at" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN send_started_at DATETIME")
        if "send_completed_at" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN send_completed_at DATETIME")
        if "send_armed" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN send_armed BOOLEAN DEFAULT 0 NOT NULL")
        if "sender_id" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN sender_id VARCHAR(36)")
        if "exclude_list_ids" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN exclude_list_ids JSON DEFAULT '[]' NOT NULL")
        if "exclude_segment_ids" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN exclude_segment_ids JSON DEFAULT '[]' NOT NULL")
        if "exclude_tags" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN exclude_tags JSON DEFAULT '[]' NOT NULL")
        if "open_events" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN open_events INTEGER DEFAULT 0 NOT NULL")
        if "click_events" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN click_events INTEGER DEFAULT 0 NOT NULL")
        if "utm_enabled" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN utm_enabled BOOLEAN DEFAULT 0 NOT NULL")
        if "utm_source" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN utm_source VARCHAR(120) DEFAULT 'mailflow' NOT NULL")
        if "utm_medium" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN utm_medium VARCHAR(120) DEFAULT 'email' NOT NULL")
        if "utm_campaign" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN utm_campaign VARCHAR(180) DEFAULT '' NOT NULL")
        if "utm_content" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN utm_content VARCHAR(180) DEFAULT '' NOT NULL")
        if "utm_term" not in campaign_columns:
            statements.append("ALTER TABLE campaigns ADD COLUMN utm_term VARCHAR(180) DEFAULT '' NOT NULL")

    legacy_automation_upgrade = False
    if "automations" in inspector.get_table_names():
        automation_columns = {c["name"] for c in inspector.get_columns("automations")}
        if "trigger_type" not in automation_columns:
            legacy_automation_upgrade = True
            statements.append("ALTER TABLE automations ADD COLUMN trigger_type VARCHAR(40) DEFAULT 'contact_created' NOT NULL")
        if "trigger_config" not in automation_columns:
            statements.append("ALTER TABLE automations ADD COLUMN trigger_config JSON DEFAULT '{}' NOT NULL")
        if "steps_json" not in automation_columns:
            statements.append("ALTER TABLE automations ADD COLUMN steps_json JSON DEFAULT '[]' NOT NULL")
        if "reentry_policy" not in automation_columns:
            statements.append("ALTER TABLE automations ADD COLUMN reentry_policy VARCHAR(20) DEFAULT 'once' NOT NULL")
        if "sender_id" not in automation_columns:
            statements.append("ALTER TABLE automations ADD COLUMN sender_id VARCHAR(36)")
        if "activated_at" not in automation_columns:
            statements.append("ALTER TABLE automations ADD COLUMN activated_at DATETIME")
        if "updated_at" not in automation_columns:
            statements.append("ALTER TABLE automations ADD COLUMN updated_at DATETIME")

    if "email_deliveries" in inspector.get_table_names():
        delivery_columns = {c["name"] for c in inspector.get_columns("email_deliveries")}
        if "unsubscribed_at" not in delivery_columns:
            statements.append("ALTER TABLE email_deliveries ADD COLUMN unsubscribed_at DATETIME")
        if "automation_run_id" not in delivery_columns:
            statements.append("ALTER TABLE email_deliveries ADD COLUMN automation_run_id VARCHAR(36)")
        if "automation_step_index" not in delivery_columns:
            statements.append("ALTER TABLE email_deliveries ADD COLUMN automation_step_index INTEGER")
    if "templates" in inspector.get_table_names():
        template_columns = {c["name"] for c in inspector.get_columns("templates")}
        if "preheader" not in template_columns:
            statements.append("ALTER TABLE templates ADD COLUMN preheader VARCHAR(250) DEFAULT '' NOT NULL")
        if "editor_mode" not in template_columns:
            statements.append("ALTER TABLE templates ADD COLUMN editor_mode VARCHAR(20) DEFAULT 'visual' NOT NULL")
        if "design_json" not in template_columns:
            statements.append("ALTER TABLE templates ADD COLUMN design_json JSON DEFAULT '[]' NOT NULL")
        if "html_body" not in template_columns:
            statements.append("ALTER TABLE templates ADD COLUMN html_body TEXT DEFAULT '' NOT NULL")
    if statements:
        with engine.begin() as conn:
            for statement in statements:
                conn.execute(text(statement))
            if legacy_automation_upgrade:
                # Automações textuais da v0.11 não são executadas automaticamente após a migração.
                conn.execute(text("UPDATE automations SET active = 0"))
                conn.execute(text("UPDATE automations SET updated_at = created_at WHERE updated_at IS NULL"))


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
