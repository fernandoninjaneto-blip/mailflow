from __future__ import annotations

from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from .config import settings, validate_runtime_configuration
from .health_service import readiness, record_heartbeat
from .middleware import ProductionSecurityMiddleware
from .observability import configure_logging
from .routers import account, auth, automations, campaigns, contacts, dashboard, delivery, domains, email_editor, events, privacy, reports, resources, segments

configure_logging()
logger = logging.getLogger("mailflow.api")


@asynccontextmanager
async def lifespan(app: FastAPI):
    errors = validate_runtime_configuration()
    if errors:
        for error in errors:
            logger.critical("configuration_error: %s", error)
        raise RuntimeError("Configuração de produção inválida: " + " | ".join(errors))
    # Schema migrations are intentionally not executed here. The deploy pipeline
    # runs `alembic upgrade head` before API/worker start.
    try:
        record_heartbeat("api", details={"version": "0.15.0"})
    except Exception as exc:
        logger.warning("api_heartbeat_initial_failed: %s", exc)
    logger.info("mailflow_api_started")
    yield
    logger.info("mailflow_api_stopped")


app = FastAPI(
    title="MailFlow API",
    version="0.15.0",
    description="Backend do MailFlow v0.16 com gate de staging, Alembic, CSRF, rate limiting, observabilidade e health checks.",
    lifespan=lifespan,
    docs_url="/api/docs" if not settings.production_like else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if not settings.production_like else None,
)

app.add_middleware(ProductionSecurityMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.trusted_origins),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "X-CSRF-Token", "X-Request-ID"],
)

app.include_router(auth.router)
app.include_router(account.router)
app.include_router(dashboard.router)
app.include_router(reports.router)
app.include_router(contacts.router)
app.include_router(segments.router)
app.include_router(automations.router)
app.include_router(events.router)
app.include_router(campaigns.router)
app.include_router(delivery.router)
app.include_router(domains.router)
app.include_router(email_editor.router)
app.include_router(privacy.router)
app.include_router(resources.router)


@app.get("/api/health")
def health_compat():
    return {"status": "ok", "service": "mailflow-api", "version": "0.15.0"}


@app.get("/api/health/live")
def health_live():
    return {"status": "ok", "service": "mailflow-api", "version": "0.15.0"}


@app.get("/api/health/ready")
def health_ready():
    ok, checks = readiness()
    if not ok:
        raise HTTPException(status_code=503, detail={"status": "not_ready", "checks": checks})
    try:
        record_heartbeat("api", details={"version": "0.15.0"})
    except Exception:
        pass
    return {"status": "ready", "service": "mailflow-api", "version": "0.15.0", "checks": checks}


# Render (and other single-service platforms) can serve the immutable frontend
# from the same origin as the API. This keeps cookies, CSRF and CORS simple.
_frontend_dir = os.getenv("MAILFLOW_FRONTEND_DIR", "").strip()
if _frontend_dir and os.path.isdir(_frontend_dir):
    app.mount("/", StaticFiles(directory=_frontend_dir, html=True), name="frontend")
