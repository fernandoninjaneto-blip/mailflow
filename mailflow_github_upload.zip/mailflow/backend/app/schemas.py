from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator

ContactStatus = Literal["active", "unsubscribed", "bounce", "blocked", "invalid"]
CampaignStatus = Literal["draft", "scheduled", "sending", "sent", "paused", "cancelled"]
UserRole = Literal["admin", "user"]
CustomFieldType = Literal["text", "number", "date", "boolean"]
BulkAction = Literal["add_tags", "remove_tags", "set_status", "delete"]
AudienceType = Literal["all", "list", "segment"]
SegmentMatchMode = Literal["all", "any"]
SegmentField = Literal["status", "tag", "source", "email", "name", "phone", "created_at", "custom"]
SegmentOperator = Literal["equals", "not_equals", "contains", "not_contains", "starts_with", "ends_with", "is_set", "not_set", "before", "after"]


def validate_password_strength(value: str) -> str:
    if len(value) < 8:
        raise ValueError("A senha deve ter pelo menos 8 caracteres.")
    if not any(c.isalpha() for c in value) or not any(c.isdigit() for c in value):
        raise ValueError("A senha deve conter pelo menos uma letra e um número.")
    return value


class WorkspaceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    created_at: datetime


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    email: EmailStr
    role: UserRole
    active: bool
    created_at: datetime


class AuthMeOut(BaseModel):
    user: UserOut
    workspace: WorkspaceOut


class RegisterIn(BaseModel):
    workspace_name: str = Field(min_length=2, max_length=160)
    name: str = Field(min_length=2, max_length=180)
    email: EmailStr
    password: str

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        return validate_password_strength(v)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class ForgotPasswordIn(BaseModel):
    email: EmailStr


class ForgotPasswordOut(BaseModel):
    message: str
    reset_token: str | None = None


class ResetPasswordIn(BaseModel):
    token: str = Field(min_length=20)
    new_password: str

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        return validate_password_strength(v)


class UserCreate(BaseModel):
    name: str = Field(min_length=2, max_length=180)
    email: EmailStr
    password: str
    role: UserRole = "user"

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        return validate_password_strength(v)


class UserUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=180)
    role: UserRole | None = None
    active: bool | None = None


class WorkspaceUpdate(BaseModel):
    name: str = Field(min_length=2, max_length=160)


class ContactBase(BaseModel):
    name: str = ""
    last_name: str = ""
    email: EmailStr
    phone: str | None = None
    tags: list[str] = Field(default_factory=list)
    custom_fields: dict[str, Any] = Field(default_factory=dict)
    status: ContactStatus = "active"
    source: str = "Manual"

    @field_validator("tags")
    @classmethod
    def normalize_tags(cls, value: list[str]) -> list[str]:
        out: list[str] = []
        seen = set()
        for tag in value:
            clean = str(tag).strip()
            if clean and clean.lower() not in seen:
                seen.add(clean.lower())
                out.append(clean[:80])
        return out


class ContactCreate(ContactBase):
    pass


class ContactUpdate(BaseModel):
    name: str | None = None
    last_name: str | None = None
    email: EmailStr | None = None
    phone: str | None = None
    tags: list[str] | None = None
    custom_fields: dict[str, Any] | None = None
    status: ContactStatus | None = None
    source: str | None = None


class ContactOut(ContactBase):
    model_config = ConfigDict(from_attributes=True)
    id: str
    created_at: datetime
    updated_at: datetime


class ContactListOut(BaseModel):
    items: list[ContactOut]
    total: int
    page: int
    page_size: int
    pages: int


class ContactStatsOut(BaseModel):
    total: int
    active: int
    unsubscribed: int
    bounce: int
    blocked: int
    invalid: int
    tagged: int


class ContactEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    event_type: str
    description: str
    event_data: dict[str, Any]
    created_at: datetime


class ContactDetailOut(BaseModel):
    contact: ContactOut
    history: list[ContactEventOut]


class TagSummaryOut(BaseModel):
    name: str
    count: int


class BulkContactActionIn(BaseModel):
    ids: list[str] = Field(min_length=1, max_length=5000)
    action: BulkAction
    tags: list[str] = Field(default_factory=list)
    status: ContactStatus | None = None


class BulkContactActionOut(BaseModel):
    affected: int
    action: BulkAction


class CustomFieldCreate(BaseModel):
    label: str = Field(min_length=1, max_length=120)
    key: str | None = Field(default=None, max_length=80)
    field_type: CustomFieldType = "text"


class CustomFieldOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    key: str
    label: str
    field_type: CustomFieldType
    created_at: datetime


class ImportSummaryOut(BaseModel):
    rows_found: int
    valid: int
    invalid: int
    duplicates_in_file: int
    duplicates_existing: int
    created: int
    updated: int
    skipped: int
    errors: list[str] = Field(default_factory=list)


class StaticListCreate(BaseModel):
    name: str = Field(min_length=1, max_length=180)
    description: str = Field(default="", max_length=500)


class StaticListUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=180)
    description: str | None = Field(default=None, max_length=500)


class StaticListOut(BaseModel):
    id: str
    name: str
    description: str
    member_count: int
    active_member_count: int
    created_at: datetime
    updated_at: datetime


class ListMembersIn(BaseModel):
    contact_ids: list[str] = Field(min_length=1, max_length=5000)


class ListMembersResult(BaseModel):
    affected: int
    member_count: int


class SegmentRule(BaseModel):
    field: SegmentField
    operator: SegmentOperator
    value: str | None = None
    custom_key: str | None = Field(default=None, max_length=80)

    @field_validator("custom_key")
    @classmethod
    def validate_custom_key(cls, value: str | None) -> str | None:
        return value.strip() if value else None


class SegmentCreate(BaseModel):
    name: str = Field(min_length=1, max_length=180)
    description: str = Field(default="", max_length=500)
    match_mode: SegmentMatchMode = "all"
    rules: list[SegmentRule] = Field(min_length=1, max_length=20)


class SegmentUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=180)
    description: str | None = Field(default=None, max_length=500)
    match_mode: SegmentMatchMode | None = None
    rules: list[SegmentRule] | None = Field(default=None, min_length=1, max_length=20)


class SegmentOut(BaseModel):
    id: str
    name: str
    description: str
    match_mode: SegmentMatchMode
    rules: list[SegmentRule]
    matching_count: int
    active_count: int
    created_at: datetime
    updated_at: datetime


class SegmentPreviewIn(BaseModel):
    match_mode: SegmentMatchMode = "all"
    rules: list[SegmentRule] = Field(min_length=1, max_length=20)


class SegmentPreviewOut(BaseModel):
    matching_count: int
    active_count: int
    sample: list[ContactOut]


class CampaignBase(BaseModel):
    name: str
    subject: str
    preheader: str = ""
    segment: str = "Todos os contatos ativos"
    audience_type: AudienceType = "all"
    audience_id: str | None = None
    status: CampaignStatus = "draft"
    scheduled_at: datetime | None = None
    body: str = ""
    editor_mode: Literal["visual", "html"] = "visual"
    design_json: list[dict] = Field(default_factory=list)
    html_body: str = ""
    sender_id: str | None = None
    exclude_list_ids: list[str] = Field(default_factory=list)
    exclude_segment_ids: list[str] = Field(default_factory=list)
    exclude_tags: list[str] = Field(default_factory=list)
    utm_enabled: bool = False
    utm_source: str = "mailflow"
    utm_medium: str = "email"
    utm_campaign: str = ""
    utm_content: str = ""
    utm_term: str = ""


class CampaignCreate(CampaignBase):
    pass


class CampaignUpdate(BaseModel):
    name: str | None = None
    subject: str | None = None
    preheader: str | None = None
    segment: str | None = None
    audience_type: AudienceType | None = None
    audience_id: str | None = None
    status: CampaignStatus | None = None
    scheduled_at: datetime | None = None
    body: str | None = None
    editor_mode: Literal["visual", "html"] | None = None
    design_json: list[dict] | None = None
    html_body: str | None = None
    sender_id: str | None = None
    exclude_list_ids: list[str] | None = None
    exclude_segment_ids: list[str] | None = None
    exclude_tags: list[str] | None = None
    utm_enabled: bool | None = None
    utm_source: str | None = None
    utm_medium: str | None = None
    utm_campaign: str | None = None
    utm_content: str | None = None
    utm_term: str | None = None


class CampaignOut(CampaignBase):
    model_config = ConfigDict(from_attributes=True)
    id: str
    sent: int
    delivered: int
    opens: int
    clicks: int
    unsub: int
    bounces: int = 0
    complaints: int = 0
    open_events: int = 0
    click_events: int = 0
    failures: int = 0
    queued_at: datetime | None = None
    send_started_at: datetime | None = None
    send_completed_at: datetime | None = None
    send_armed: bool = False
    sender_id: str | None = None
    exclude_list_ids: list[str] = Field(default_factory=list)
    exclude_segment_ids: list[str] = Field(default_factory=list)
    exclude_tags: list[str] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime


class DashboardOut(BaseModel):
    contacts_total: int
    contacts_active: int
    contacts_unsubscribed: int
    campaigns_total: int
    sent: int
    delivered: int
    opens: int
    clicks: int
    unsub: int


class TemplateIn(BaseModel):
    name: str
    type: str = "Personalizado"
    subject: str
    preheader: str = ""
    body: str = ""
    editor_mode: Literal["visual", "html"] = "visual"
    design_json: list[dict] = Field(default_factory=list)
    html_body: str = ""


class TemplateOut(TemplateIn):
    model_config = ConfigDict(from_attributes=True)
    id: str


AutomationTriggerType = Literal["contact_created", "tag_added", "list_joined", "email_clicked", "status_changed", "manual"]
AutomationReentryPolicy = Literal["once", "reenter"]
AutomationRunStatus = Literal["running", "waiting", "completed", "cancelled", "failed"]
AutomationStepType = Literal["send_email", "wait", "condition", "add_tag", "remove_tag"]


class AutomationStep(BaseModel):
    type: AutomationStepType
    template_id: str | None = None
    amount: int | None = Field(default=None, ge=1, le=3650)
    unit: Literal["minutes", "hours", "days"] | None = None
    rules: list[SegmentRule] = Field(default_factory=list, max_length=20)
    match_mode: SegmentMatchMode = "all"
    on_false: Literal["stop", "skip_next"] = "stop"
    tag: str | None = Field(default=None, max_length=80)

    @model_validator(mode="after")
    def validate_by_type(self):
        if self.type == "send_email" and not (self.template_id or "").strip():
            raise ValueError("Etapas de e-mail precisam de um template.")
        if self.type == "wait":
            if not self.amount or not self.unit:
                raise ValueError("Etapas de espera precisam de quantidade e unidade.")
        if self.type == "condition" and not self.rules:
            raise ValueError("Etapas de condição precisam de pelo menos uma regra.")
        if self.type in {"add_tag", "remove_tag"} and not (self.tag or "").strip():
            raise ValueError("Etapas de tag precisam informar a tag.")
        return self


class AutomationCreate(BaseModel):
    name: str = Field(min_length=2, max_length=180)
    trigger_type: AutomationTriggerType
    trigger_config: dict[str, Any] = Field(default_factory=dict)
    steps: list[AutomationStep] = Field(min_length=1, max_length=30)
    reentry_policy: AutomationReentryPolicy = "once"
    sender_id: str | None = None
    active: bool = True


class AutomationUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=180)
    trigger_type: AutomationTriggerType | None = None
    trigger_config: dict[str, Any] | None = None
    steps: list[AutomationStep] | None = Field(default=None, min_length=1, max_length=30)
    reentry_policy: AutomationReentryPolicy | None = None
    sender_id: str | None = None


class AutomationOut(BaseModel):
    id: str
    name: str
    trigger_type: AutomationTriggerType
    trigger_config: dict[str, Any]
    steps: list[AutomationStep]
    reentry_policy: AutomationReentryPolicy
    sender_id: str | None = None
    active: bool
    run_count: int = 0
    running_count: int = 0
    completed_count: int = 0
    failed_count: int = 0
    created_at: datetime
    updated_at: datetime


class AutomationRunOut(BaseModel):
    id: str
    automation_id: str
    contact_id: str | None
    contact_email: str = ""
    status: AutomationRunStatus
    current_step: int
    total_steps: int
    next_run_at: datetime | None
    last_error: str
    started_at: datetime
    completed_at: datetime | None


class AutomationEnrollIn(BaseModel):
    contact_id: str


class AutomationProcessOut(BaseModel):
    triggers_scanned: int = 0
    enrolled: int = 0
    runs_processed: int = 0
    runs_failed: int = 0


class SenderSettingsIn(BaseModel):
    sender_name: str = "Sua Marca"
    sender_email: str = ""
    reply_to: str = ""


class SenderSettingsOut(SenderSettingsIn):
    model_config = ConfigDict(from_attributes=True)
    id: str

class EmailPreviewIn(BaseModel):
    subject: str = ""
    preheader: str = ""
    editor_mode: Literal["visual", "html"] = "visual"
    design_json: list[dict] = Field(default_factory=list)
    html_body: str = ""
    body: str = ""
    sample: dict[str, Any] = Field(default_factory=dict)


class EmailPreviewOut(BaseModel):
    subject: str
    preheader: str
    html: str
    plain_text: str




class CampaignReviewSampleOut(BaseModel):
    id: str
    name: str = ""
    last_name: str = ""
    email: EmailStr


class CampaignReviewSenderOut(BaseModel):
    id: str | None = None
    name: str
    email: str
    reply_to: str = ""
    domain_id: str | None = None


class CampaignReviewOut(BaseModel):
    campaign_id: str
    campaign_name: str
    status: str
    scheduled_at: datetime | None = None
    provider: str
    live: bool
    base_audience: int
    eligible: int
    excluded_total: int
    exclusions: dict[str, int]
    sender: CampaignReviewSenderOut | None = None
    blockers: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    can_send: bool
    review_token: str
    sample: list[CampaignReviewSampleOut] = Field(default_factory=list)


class CampaignSendIn(BaseModel):
    review_token: str = Field(min_length=16)
    expected_recipients: int = Field(ge=0)
    confirmation: Literal["ENVIAR", "AGENDAR"]

class CampaignSendOut(BaseModel):
    campaign_id: str
    status: str
    queued: int = 0
    scheduled_at: datetime | None = None
    provider: str
    live: bool


class TestSendIn(BaseModel):
    email: EmailStr


class DeliveryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    campaign_id: str | None
    contact_id: str | None
    recipient_email: str
    recipient_name: str
    is_test: bool
    status: str
    provider: str
    provider_message_id: str | None
    attempt_count: int
    max_attempts: int
    next_attempt_at: datetime | None
    last_error: str
    last_event_type: str
    queued_at: datetime
    sent_at: datetime | None
    delivered_at: datetime | None
    opened_at: datetime | None
    clicked_at: datetime | None
    bounced_at: datetime | None
    complained_at: datetime | None
    unsubscribed_at: datetime | None = None
    failed_at: datetime | None


class DeliveryListOut(BaseModel):
    total: int
    queued: int
    retry: int
    processing: int = 0
    pending: int = 0
    processed: int = 0
    progress_pct: float = 0
    sent: int
    delivered: int
    bounced: int
    complained: int
    failed: int
    cancelled: int = 0
    suppressed: int = 0
    items: list[DeliveryOut]


class ProviderStatusOut(BaseModel):
    provider: str
    configured: bool
    live: bool
    mode: str
    webhook_configured: bool
    queue: str


class ProcessOnceOut(BaseModel):
    processed: int
    failed: int


# Passo 13: eventos e lançamentos
EventType = Literal["online_event", "conference", "webinar", "immersion", "launch", "class", "other"]
EventStatus = Literal["draft", "planned", "live", "completed", "archived"]
EventPhase = Literal["registration", "pre_event", "live", "offer", "post_event"]
EventAnchor = Literal["event_start", "event_end", "offer_open", "offer_close", "absolute"]


class MarketingEventCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    event_type: EventType = "online_event"
    description: str = Field(default="", max_length=5000)
    status: EventStatus = "draft"
    start_at: datetime
    end_at: datetime
    timezone: str = Field(default="America/Belem", min_length=2, max_length=80)
    platform: str = Field(default="Zoom", max_length=80)
    access_url: str = Field(default="", max_length=1000)
    audience_type: AudienceType = "all"
    audience_id: str | None = None
    sender_id: str | None = None
    offer_open_at: datetime | None = None
    offer_close_at: datetime | None = None
    notes: str = Field(default="", max_length=10000)

    @model_validator(mode="after")
    def validate_dates(self):
        if self.end_at <= self.start_at:
            raise ValueError("O término do evento precisa ser posterior ao início.")
        if self.offer_open_at and self.offer_close_at and self.offer_close_at <= self.offer_open_at:
            raise ValueError("O encerramento da oferta precisa ser posterior à abertura.")
        return self


class MarketingEventUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=200)
    event_type: EventType | None = None
    description: str | None = Field(default=None, max_length=5000)
    status: EventStatus | None = None
    start_at: datetime | None = None
    end_at: datetime | None = None
    timezone: str | None = Field(default=None, min_length=2, max_length=80)
    platform: str | None = Field(default=None, max_length=80)
    access_url: str | None = Field(default=None, max_length=1000)
    audience_type: AudienceType | None = None
    audience_id: str | None = None
    sender_id: str | None = None
    offer_open_at: datetime | None = None
    offer_close_at: datetime | None = None
    notes: str | None = Field(default=None, max_length=10000)


class EventCommunicationCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    phase: EventPhase = "pre_event"
    relative_to: EventAnchor = "event_start"
    offset_minutes: int = Field(default=0, ge=-525600, le=525600)
    scheduled_at: datetime | None = None
    template_id: str | None = None
    enabled: bool = True

    @model_validator(mode="after")
    def absolute_needs_date(self):
        if self.relative_to == "absolute" and self.scheduled_at is None:
            raise ValueError("Comunicações com horário absoluto precisam de data e hora.")
        return self


class EventCommunicationUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=200)
    phase: EventPhase | None = None
    relative_to: EventAnchor | None = None
    offset_minutes: int | None = Field(default=None, ge=-525600, le=525600)
    scheduled_at: datetime | None = None
    template_id: str | None = None
    enabled: bool | None = None


class EventCommunicationOut(BaseModel):
    id: str
    event_id: str
    name: str
    phase: str
    relative_to: str
    offset_minutes: int
    scheduled_at: datetime | None
    template_id: str | None
    template_name: str = ""
    campaign_id: str | None
    campaign_status: str = ""
    campaign_send_armed: bool = False
    enabled: bool
    system_key: str | None = None
    needs_review: bool = False
    created_at: datetime
    updated_at: datetime


class EventReadinessOut(BaseModel):
    ready_to_prepare: bool = False
    communications_total: int = 0
    communications_enabled: int = 0
    communications_with_template: int = 0
    campaigns_prepared: int = 0
    campaigns_armed: int = 0
    blockers: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class EventMetricsOut(BaseModel):
    campaigns: int = 0
    sent: int = 0
    delivered: int = 0
    opens: int = 0
    clicks: int = 0
    unsubscribes: int = 0
    bounces: int = 0
    complaints: int = 0


class MarketingEventOut(BaseModel):
    id: str
    name: str
    event_type: str
    description: str
    status: str
    effective_status: str
    start_at: datetime
    end_at: datetime
    timezone: str
    platform: str
    access_url: str
    audience_type: str
    audience_id: str | None
    audience_label: str
    sender_id: str | None
    sender_label: str
    offer_open_at: datetime | None
    offer_close_at: datetime | None
    registration_automation_id: str | None
    notes: str
    readiness: EventReadinessOut
    metrics: EventMetricsOut
    created_at: datetime
    updated_at: datetime


class MarketingEventDetailOut(BaseModel):
    event: MarketingEventOut
    communications: list[EventCommunicationOut]


class EventRecommendedPlanOut(BaseModel):
    created: int = 0
    existing: int = 0
    communications: list[EventCommunicationOut] = Field(default_factory=list)


class EventPrepareCampaignsOut(BaseModel):
    prepared: int = 0
    updated: int = 0
    skipped: int = 0
    blocked: int = 0
    messages: list[str] = Field(default_factory=list)
    communications: list[EventCommunicationOut] = Field(default_factory=list)


class EventConfirmationAutomationIn(BaseModel):
    template_id: str
    active: bool = False



# Passo 8: domínio, autenticação e entregabilidade
DomainRegion = Literal["us-east-1", "eu-west-1", "sa-east-1", "ap-northeast-1"]
TlsMode = Literal["opportunistic", "enforced"]
DmarcPolicy = Literal["none", "quarantine", "reject"]


class SendingDomainCreate(BaseModel):
    name: str = Field(min_length=3, max_length=253)
    region: DomainRegion = "us-east-1"
    custom_return_path: str = Field(default="send", min_length=1, max_length=63)
    tracking_subdomain: str = Field(default="links", min_length=1, max_length=63)
    open_tracking: bool = True
    click_tracking: bool = True
    tls_mode: TlsMode = "opportunistic"
    dmarc_policy: DmarcPolicy = "none"
    dmarc_report_email: EmailStr | None = None


class SendingDomainUpdate(BaseModel):
    open_tracking: bool | None = None
    click_tracking: bool | None = None
    tls_mode: TlsMode | None = None
    dmarc_policy: DmarcPolicy | None = None
    dmarc_report_email: EmailStr | None = None


class DnsRecordOut(BaseModel):
    record: str = ""
    name: str = ""
    type: str = ""
    value: str = ""
    ttl: str = ""
    status: str = ""
    priority: int | None = None


class SendingDomainOut(BaseModel):
    id: str
    provider: str
    provider_domain_id: str | None
    name: str
    region: str
    custom_return_path: str
    tracking_subdomain: str
    open_tracking: bool
    click_tracking: bool
    tls_mode: str
    provider_status: str
    dns_records: list[dict]
    spf_status: str
    dkim_status: str
    tracking_status: str
    dmarc_status: str
    dmarc_policy: str
    dmarc_report_email: str
    dmarc_value: str
    dmarc_found_values: list[str]
    ready_for_sending: bool
    last_checked_at: datetime | None
    last_error: str
    created_at: datetime
    updated_at: datetime


class SenderIdentityCreate(BaseModel):
    domain_id: str
    name: str = Field(min_length=1, max_length=180)
    email: EmailStr
    reply_to: EmailStr | None = None
    is_default: bool = False


class SenderIdentityUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=180)
    reply_to: EmailStr | None = None
    active: bool | None = None
    is_default: bool | None = None


class SenderIdentityOut(BaseModel):
    id: str
    domain_id: str
    domain_name: str
    name: str
    email: str
    reply_to: str
    active: bool
    is_default: bool
    domain_ready: bool
    status: str
    created_at: datetime
    updated_at: datetime


class DeliverabilityStatusOut(BaseModel):
    provider: str
    provider_configured: bool
    domains: int
    ready_domains: int
    sender_identities: int
    ready_sender_identities: int
    default_sender_id: str | None
    live_send_ready: bool
    bulk_marketing_ready: bool
    blockers: list[str]
    warnings: list[str]


class CampaignReportSummaryOut(BaseModel):
    sent: int = 0
    delivered: int = 0
    delivery_rate: float = 0
    unique_opens: int = 0
    open_events: int = 0
    open_rate: float = 0
    unique_clicks: int = 0
    click_events: int = 0
    click_rate: float = 0
    click_to_open_rate: float = 0
    bounces: int = 0
    bounce_rate: float = 0
    complaints: int = 0
    complaint_rate: float = 0
    unsubscribes: int = 0


class CampaignLinkStatOut(BaseModel):
    url: str
    host: str = ""
    unique_clicks: int = 0
    total_clicks: int = 0
    ctr: float = 0


class CampaignRecipientEngagementOut(BaseModel):
    delivery_id: str
    contact_id: str | None = None
    email: str
    name: str = ""
    delivered_at: datetime | None = None
    opened_at: datetime | None = None
    clicked_at: datetime | None = None
    open_events: int = 0
    click_events: int = 0
    last_clicked_url: str = ""


class CampaignReportOut(BaseModel):
    campaign_id: str
    campaign_name: str
    subject: str
    status: str
    summary: CampaignReportSummaryOut
    links: list[CampaignLinkStatOut] = Field(default_factory=list)
    recipients: list[CampaignRecipientEngagementOut] = Field(default_factory=list)
    utm: dict[str, str | bool] = Field(default_factory=dict)


class EngagementEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    delivery_id: str
    contact_id: str | None = None
    event_type: str
    occurred_at: datetime
    link_url: str = ""
    link_host: str = ""
    ip_address: str = ""
    user_agent: str = ""


class SuppressionCreateIn(BaseModel):
    email: EmailStr
    reason: Literal["manual", "unsubscribe", "complaint", "hard_bounce", "privacy_delete"] = "manual"


class SuppressionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    contact_id: str | None = None
    campaign_id: str | None = None
    email_hint: str
    reason: str
    source: str
    active: bool
    metadata_json: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    released_at: datetime | None = None


class SuppressionReleaseIn(BaseModel):
    legal_basis: str = Field(default="consent", min_length=2, max_length=80)
    source: str = Field(min_length=2, max_length=160)
    notice_version: str = Field(default="", max_length=80)
    note: str = Field(default="", max_length=500)


class ConsentRecordIn(BaseModel):
    contact_id: str
    action: Literal["granted", "revoked"]
    legal_basis: str = Field(default="consent", min_length=2, max_length=80)
    source: str = Field(min_length=2, max_length=160)
    notice_version: str = Field(default="", max_length=80)
    evidence: dict[str, Any] = Field(default_factory=dict)
    reactivate: bool = False


class PrivacyDeleteIn(BaseModel):
    confirmation: str
