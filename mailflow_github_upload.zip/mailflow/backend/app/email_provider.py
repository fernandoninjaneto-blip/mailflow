from __future__ import annotations

from dataclasses import dataclass
import logging
import os
import uuid
from typing import Any

import httpx

logger = logging.getLogger("mailflow.email_provider")


class ProviderError(RuntimeError):
    def __init__(self, message: str, *, retryable: bool = False, status_code: int | None = None):
        super().__init__(message)
        self.retryable = retryable
        self.status_code = status_code


@dataclass(slots=True)
class ProviderResult:
    message_id: str
    raw: dict[str, Any]


class EmailProvider:
    name = "base"

    @property
    def configured(self) -> bool:
        return False

    @property
    def live(self) -> bool:
        return False

    def send(
        self,
        *,
        from_name: str,
        from_email: str,
        to_email: str,
        subject: str,
        html: str,
        text: str,
        reply_to: str = "",
        idempotency_key: str,
        headers: dict[str, str] | None = None,
    ) -> ProviderResult:
        raise NotImplementedError


class ConsoleProvider(EmailProvider):
    """Provider de desenvolvimento.

    Ele exercita a fila e todo o pipeline sem sair para a internet.
    Não deve ser tratado como entrega real.
    """

    name = "console"

    @property
    def configured(self) -> bool:
        return True

    @property
    def live(self) -> bool:
        return False

    def send(self, **kwargs) -> ProviderResult:
        message_id = f"console_{uuid.uuid4()}"
        # Não registra destinatário/assunto para evitar PII em logs de staging.
        logger.info("console_email_accepted", extra={"event": "console_email_accepted"})
        return ProviderResult(message_id=message_id, raw={"id": message_id, "mode": "console"})


class ResendProvider(EmailProvider):
    name = "resend"

    def __init__(self) -> None:
        self.api_key = os.getenv("RESEND_API_KEY", "").strip()
        self.base_url = os.getenv("RESEND_API_BASE", "https://api.resend.com").rstrip("/")
        self.timeout = float(os.getenv("MAILFLOW_PROVIDER_TIMEOUT_SECONDS", "20"))

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    @property
    def live(self) -> bool:
        return self.configured

    def send(
        self,
        *,
        from_name: str,
        from_email: str,
        to_email: str,
        subject: str,
        html: str,
        text: str,
        reply_to: str = "",
        idempotency_key: str,
        headers: dict[str, str] | None = None,
    ) -> ProviderResult:
        if not self.api_key:
            raise ProviderError("RESEND_API_KEY não configurada.", retryable=False)
        if not from_email:
            raise ProviderError("E-mail do remetente não configurado.", retryable=False)

        payload: dict[str, Any] = {
            "from": f"{from_name} <{from_email}>" if from_name else from_email,
            "to": [to_email],
            "subject": subject,
            "html": html,
            "text": text,
        }
        if headers:
            payload["headers"] = headers
        if reply_to:
            payload["reply_to"] = reply_to

        try:
            response = httpx.post(
                f"{self.base_url}/emails",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                    "Idempotency-Key": idempotency_key,
                },
                json=payload,
                timeout=self.timeout,
            )
        except httpx.TimeoutException as exc:
            raise ProviderError("Timeout ao comunicar com o Resend.", retryable=True) from exc
        except httpx.RequestError as exc:
            raise ProviderError(f"Falha de rede ao comunicar com o Resend: {exc}", retryable=True) from exc

        if response.status_code >= 400:
            try:
                data = response.json()
                message = data.get("message") or data.get("error") or response.text
            except Exception:
                message = response.text
            retryable = response.status_code == 429 or response.status_code >= 500
            raise ProviderError(
                f"Resend respondeu {response.status_code}: {str(message)[:700]}",
                retryable=retryable,
                status_code=response.status_code,
            )

        data = response.json()
        message_id = str(data.get("id") or "").strip()
        if not message_id:
            raise ProviderError("Resend não retornou o ID da mensagem.", retryable=True)
        return ProviderResult(message_id=message_id, raw=data)


def get_provider() -> EmailProvider:
    requested = os.getenv("MAIL_PROVIDER", "console").strip().lower()
    if requested == "resend":
        return ResendProvider()
    return ConsoleProvider()


def provider_status() -> dict[str, Any]:
    provider = get_provider()
    webhook_secret = os.getenv("RESEND_WEBHOOK_SECRET", "").strip()
    return {
        "provider": provider.name,
        "configured": provider.configured,
        "live": provider.live,
        "mode": "live" if provider.live else "development",
        "webhook_configured": bool(webhook_secret) if provider.name == "resend" else False,
        "queue": "database",
    }
