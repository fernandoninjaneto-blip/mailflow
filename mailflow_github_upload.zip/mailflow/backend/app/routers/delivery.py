from __future__ import annotations

from datetime import datetime, timezone
import json

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..delivery_service import enqueue_campaign, process_batch, refresh_campaign_metrics, record_contact_event, send_test_delivery
from ..campaign_review import validate_review_confirmation
from ..email_provider import provider_status
from ..models import Campaign, Contact, EmailDelivery, EmailEngagementEvent, SendingDomain, User, WebhookEvent
from ..schemas import CampaignReportOut, CampaignSendIn, CampaignSendOut, DeliveryListOut, DeliveryOut, EngagementEventOut, ProcessOnceOut, ProviderStatusOut, TestSendIn
from ..security import get_current_user, require_admin
from ..deliverability import refresh_domain_dns, sync_domain_from_provider
from ..webhook_security import WebhookVerificationError, verify_svix_signature
from ..tracking import build_campaign_report, record_engagement_event
from ..unsubscribe import add_suppression

router = APIRouter(prefix="/api", tags=["delivery"])


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


def _campaign(db: Session, workspace_id: str, campaign_id: str) -> Campaign:
    item = db.get(Campaign, campaign_id)
    if not item or item.workspace_id != workspace_id:
        raise HTTPException(status_code=404, detail="Campanha não encontrada.")
    return item


@router.get("/delivery/provider", response_model=ProviderStatusOut)
def get_delivery_provider(user: User = Depends(get_current_user)):
    return provider_status()


@router.post("/campaigns/{campaign_id}/send", response_model=CampaignSendOut)
def send_campaign(payload: CampaignSendIn, campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = _campaign(db, user.workspace_id, campaign_id)
    pstatus = provider_status()

    if campaign.status == "cancelled":
        raise HTTPException(status_code=409, detail="Campanha cancelada. Duplique ou crie uma nova campanha para reenviar.")
    if campaign.status == "sent":
        raise HTTPException(status_code=409, detail="A campanha já foi enviada.")
    if campaign.status == "sending":
        existing = db.scalar(select(func.count(EmailDelivery.id)).where(
            EmailDelivery.campaign_id == campaign.id, EmailDelivery.is_test.is_(False)
        )) or 0
        return CampaignSendOut(campaign_id=campaign.id, status=campaign.status, queued=int(existing), scheduled_at=campaign.scheduled_at, provider=pstatus["provider"], live=pstatus["live"])

    try:
        validate_review_confirmation(db, campaign, payload.review_token, payload.expected_recipients)
    except ValueError as exc:
        code = 409 if "mudou após a revisão" in str(exc) else 422
        raise HTTPException(status_code=code, detail=str(exc)) from exc

    scheduled_at = _aware(campaign.scheduled_at)
    is_future_schedule = campaign.status == "scheduled" and scheduled_at and scheduled_at > utcnow()
    expected_confirmation = "AGENDAR" if is_future_schedule else "ENVIAR"
    if payload.confirmation != expected_confirmation:
        raise HTTPException(status_code=422, detail=f'Digite {expected_confirmation} para confirmar esta operação.')

    if is_future_schedule:
        try:
            queued = enqueue_campaign(db, campaign, scheduled_for=scheduled_at)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return CampaignSendOut(
            campaign_id=campaign.id, status="scheduled", queued=queued,
            scheduled_at=campaign.scheduled_at, provider=pstatus["provider"], live=pstatus["live"],
        )

    try:
        queued = enqueue_campaign(db, campaign)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    db.refresh(campaign)
    return CampaignSendOut(
        campaign_id=campaign.id, status=campaign.status, queued=queued,
        scheduled_at=campaign.scheduled_at, provider=pstatus["provider"], live=pstatus["live"],
    )


@router.post("/campaigns/{campaign_id}/pause")
def pause_campaign(campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = _campaign(db, user.workspace_id, campaign_id)
    if campaign.status not in {"sending", "scheduled"}:
        raise HTTPException(status_code=409, detail="Somente campanhas em envio ou agendadas podem ser pausadas.")
    campaign.status = "paused"
    campaign.send_armed = False
    db.commit()
    pending = db.scalar(select(func.count(EmailDelivery.id)).where(
        EmailDelivery.campaign_id == campaign.id,
        EmailDelivery.is_test.is_(False),
        EmailDelivery.status.in_(["queued", "retry"]),
    )) or 0
    return {"campaign_id": campaign.id, "status": campaign.status, "pending_jobs": int(pending)}


@router.post("/campaigns/{campaign_id}/resume")
def resume_campaign(campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = _campaign(db, user.workspace_id, campaign_id)
    if campaign.status != "paused":
        raise HTTPException(status_code=409, detail="A campanha não está pausada.")
    pending = db.scalar(select(func.count(EmailDelivery.id)).where(
        EmailDelivery.campaign_id == campaign.id,
        EmailDelivery.is_test.is_(False),
        EmailDelivery.status.in_(["queued", "retry"]),
    )) or 0
    scheduled_at = _aware(campaign.scheduled_at)
    if pending:
        campaign.status = "scheduled" if scheduled_at and scheduled_at > utcnow() else "sending"
        campaign.send_armed = True
        if campaign.status == "sending":
            campaign.send_started_at = campaign.send_started_at or utcnow()
        db.commit()
        return {"campaign_id": campaign.id, "status": campaign.status, "pending_jobs": int(pending)}
    if scheduled_at and scheduled_at > utcnow():
        campaign.status = "scheduled"
        campaign.send_armed = True
        db.commit()
        return {"campaign_id": campaign.id, "status": campaign.status, "pending_jobs": 0}
    raise HTTPException(status_code=409, detail="Não há fila pendente para retomar. Faça uma nova revisão da campanha antes de enviar.")


@router.post("/campaigns/{campaign_id}/send-test", response_model=DeliveryOut)
def send_campaign_test(payload: TestSendIn, campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = _campaign(db, user.workspace_id, campaign_id)
    try:
        return send_test_delivery(db, campaign, str(payload.email).lower())
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/campaigns/{campaign_id}/cancel")
def cancel_campaign(campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = _campaign(db, user.workspace_id, campaign_id)
    if campaign.status == "sent":
        raise HTTPException(status_code=409, detail="A campanha já foi processada e não pode ser cancelada.")
    jobs = list(db.scalars(select(EmailDelivery).where(
        EmailDelivery.campaign_id == campaign.id,
        EmailDelivery.is_test.is_(False),
        EmailDelivery.status.in_(["queued", "retry"]),
    )))
    for job in jobs:
        job.status = "cancelled"
        job.next_attempt_at = None
        job.last_event_type = "mailflow.cancelled"
    campaign.status = "cancelled"
    campaign.send_armed = False
    campaign.send_completed_at = utcnow()
    db.commit()
    return {"campaign_id": campaign.id, "status": campaign.status, "cancelled_jobs": len(jobs)}


@router.get("/campaigns/{campaign_id}/deliveries", response_model=DeliveryListOut)
def list_campaign_deliveries(
    campaign_id: str,
    limit: int = 100,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    campaign = _campaign(db, user.workspace_id, campaign_id)
    base = [EmailDelivery.campaign_id == campaign.id, EmailDelivery.is_test.is_(False)]
    items = list(db.scalars(select(EmailDelivery).where(*base).order_by(EmailDelivery.queued_at.desc()).limit(max(1, min(limit, 500)))))
    counts = dict(db.execute(select(EmailDelivery.status, func.count(EmailDelivery.id)).where(*base).group_by(EmailDelivery.status)).all())
    total = sum(counts.values())
    pending = counts.get("queued", 0) + counts.get("retry", 0) + counts.get("processing", 0)
    processed = max(0, total - pending - counts.get("cancelled", 0))
    progress_pct = round((processed / total) * 100, 1) if total else 0
    return DeliveryListOut(
        total=total,
        queued=counts.get("queued", 0),
        retry=counts.get("retry", 0),
        processing=counts.get("processing", 0),
        pending=pending,
        processed=processed,
        progress_pct=progress_pct,
        sent=counts.get("sent", 0),
        delivered=counts.get("delivered", 0),
        bounced=counts.get("bounced", 0),
        complained=counts.get("complained", 0),
        failed=counts.get("failed", 0),
        cancelled=counts.get("cancelled", 0),
        suppressed=counts.get("suppressed", 0),
        items=items,
    )


@router.get("/campaigns/{campaign_id}/report", response_model=CampaignReportOut)
def campaign_report(
    campaign_id: str,
    recipient_limit: int = 100,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    campaign = _campaign(db, user.workspace_id, campaign_id)
    return build_campaign_report(db, campaign, recipient_limit=recipient_limit)


@router.get("/campaigns/{campaign_id}/engagement-events", response_model=list[EngagementEventOut])
def campaign_engagement_events(
    campaign_id: str,
    limit: int = 200,
    event_type: str | None = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    campaign = _campaign(db, user.workspace_id, campaign_id)
    stmt = select(EmailEngagementEvent).where(EmailEngagementEvent.campaign_id == campaign.id)
    if event_type in {"open", "click"}:
        stmt = stmt.where(EmailEngagementEvent.event_type == event_type)
    return list(db.scalars(stmt.order_by(EmailEngagementEvent.occurred_at.desc()).limit(max(1, min(limit, 1000)))))


@router.post("/delivery/process-once", response_model=ProcessOnceOut)
def process_once(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return process_batch(db, 100)


def _event_delivery(db: Session, message_id: str | None) -> EmailDelivery | None:
    if not message_id:
        return None
    return db.scalar(select(EmailDelivery).where(
        EmailDelivery.provider == "resend",
        EmailDelivery.provider_message_id == message_id,
    ))


def _apply_resend_event(db: Session, delivery: EmailDelivery, event_type: str, payload: dict, provider_event_id: str) -> None:
    now = utcnow()
    delivery.last_event_type = event_type
    if event_type == "email.sent":
        delivery.sent_at = delivery.sent_at or now
        if delivery.status in {"queued", "processing", "retry"}:
            delivery.status = "sent"
    elif event_type == "email.delivered":
        delivery.sent_at = delivery.sent_at or now
        delivery.delivered_at = delivery.delivered_at or now
        if delivery.status not in {"bounced", "complained", "failed"}:
            delivery.status = "delivered"
    elif event_type == "email.opened":
        first_open = delivery.opened_at is None
        engagement = record_engagement_event(db, delivery, provider_event_id, event_type, payload)
        delivery.opened_at = delivery.opened_at or (engagement.occurred_at if engagement else now)
        if first_open:
            record_contact_event(db, delivery, "email_opened", "Contato abriu a campanha.", {"campaign_id": delivery.campaign_id, "provider": "resend"})
    elif event_type == "email.clicked":
        first_click = delivery.clicked_at is None
        engagement = record_engagement_event(db, delivery, provider_event_id, event_type, payload)
        delivery.clicked_at = delivery.clicked_at or (engagement.occurred_at if engagement else now)
        if first_click:
            record_contact_event(db, delivery, "email_clicked", "Contato clicou em um link da campanha.", {"campaign_id": delivery.campaign_id, "url": engagement.link_url if engagement else "", "provider": "resend"})
    elif event_type == "email.bounced":
        delivery.bounced_at = delivery.bounced_at or now
        delivery.status = "bounced"
        contact = db.get(Contact, delivery.contact_id) if delivery.contact_id else None
        if contact and contact.workspace_id == delivery.workspace_id and contact.status != "bounce":
            contact.status = "bounce"
            record_contact_event(db, delivery, "email_bounced", "E-mail marcado como bounce pelo provedor.", {"provider": "resend"})
        add_suppression(db, delivery.workspace_id, delivery.recipient_email, reason="hard_bounce", source="resend_webhook", contact_id=delivery.contact_id, campaign_id=delivery.campaign_id)
    elif event_type == "email.complained":
        delivery.complained_at = delivery.complained_at or now
        delivery.status = "complained"
        contact = db.get(Contact, delivery.contact_id) if delivery.contact_id else None
        if contact and contact.workspace_id == delivery.workspace_id and contact.status != "blocked":
            contact.status = "blocked"
            record_contact_event(db, delivery, "email_complained", "Contato bloqueado após reclamação de spam.", {"provider": "resend"})
        add_suppression(db, delivery.workspace_id, delivery.recipient_email, reason="complaint", source="resend_webhook", contact_id=delivery.contact_id, campaign_id=delivery.campaign_id)
    elif event_type in {"email.failed", "email.suppressed"}:
        delivery.failed_at = delivery.failed_at or now
        delivery.status = "failed"
        delivery.last_error = f"Evento do provedor: {event_type}"
    # email.delivery_delayed preserva o estado atual e fica registrado em last_event_type.
    refresh_campaign_metrics(db, delivery.campaign_id)


@router.post("/webhooks/resend")
async def resend_webhook(request: Request, db: Session = Depends(get_db)):
    raw = await request.body()
    headers = {
        "svix-id": request.headers.get("svix-id", ""),
        "svix-timestamp": request.headers.get("svix-timestamp", ""),
        "svix-signature": request.headers.get("svix-signature", ""),
    }
    try:
        verify_svix_signature(raw, headers)
    except WebhookVerificationError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Payload JSON inválido.") from exc

    event_id = headers["svix-id"]
    existing = db.scalar(select(WebhookEvent).where(
        WebhookEvent.provider == "resend",
        WebhookEvent.provider_event_id == event_id,
    ))
    if existing:
        return {"received": True, "duplicate": True, "processed": existing.processed}

    event_type = str(payload.get("type") or "unknown")
    data = payload.get("data") or {}
    message_id = str(data.get("email_id") or data.get("id") or "").strip() or None
    event = WebhookEvent(
        provider="resend",
        provider_event_id=event_id,
        event_type=event_type,
        provider_message_id=message_id,
        payload=payload,
    )
    db.add(event)
    if event_type in {"domain.created", "domain.updated"}:
        provider_domain_id = str(data.get("id") or "").strip()
        domain = db.scalar(select(SendingDomain).where(SendingDomain.provider_domain_id == provider_domain_id)) if provider_domain_id else None
        if domain:
            sync_domain_from_provider(domain, data)
            refresh_domain_dns(domain)
            event.processed = True
            event.processed_at = utcnow()
    else:
        delivery = _event_delivery(db, message_id)
        if delivery:
            _apply_resend_event(db, delivery, event_type, payload, event_id)
            event.processed = True
            event.processed_at = utcnow()
    db.commit()
    return {"received": True, "duplicate": False, "processed": event.processed}
