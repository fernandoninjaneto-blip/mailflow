from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..email_content import normalize_email_fields
from ..campaign_review import build_campaign_review, resolve_campaign_audience
from ..models import Campaign, Contact, ContactList, ContactListMembership, EmailDelivery, Segment, SenderIdentity, User
from ..schemas import CampaignCreate, CampaignOut, CampaignReviewOut, CampaignUpdate
from ..security import get_current_user
from ..segmentation import filter_contacts

router = APIRouter(prefix="/api/campaigns", tags=["campaigns"])


def _audience_label(db: Session, workspace_id: str, audience_type: str, audience_id: str | None) -> str:
    if audience_type == "all":
        return "Todos os contatos ativos"
    if audience_type == "list":
        item = db.get(ContactList, audience_id) if audience_id else None
        if not item or item.workspace_id != workspace_id:
            raise HTTPException(status_code=422, detail="A lista selecionada não pertence a este workspace.")
        return f"Lista: {item.name}"
    if audience_type == "segment":
        item = db.get(Segment, audience_id) if audience_id else None
        if not item or item.workspace_id != workspace_id:
            raise HTTPException(status_code=422, detail="O segmento selecionado não pertence a este workspace.")
        return f"Segmento: {item.name}"
    raise HTTPException(status_code=422, detail="Tipo de audiência inválido.")


def _campaign_contacts(db: Session, campaign: Campaign) -> list[Contact]:
    return resolve_campaign_audience(db, campaign)["eligible"]


@router.get("", response_model=list[CampaignOut])
def list_campaigns(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    stmt = select(Campaign).where(Campaign.workspace_id == user.workspace_id).order_by(Campaign.created_at.desc())
    return list(db.scalars(stmt))


@router.post("", response_model=CampaignOut, status_code=status.HTTP_201_CREATED)
def create_campaign(payload: CampaignCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = normalize_email_fields(payload.model_dump())
    audience_type = data.get("audience_type", "all")
    audience_id = data.get("audience_id")
    data["segment"] = _audience_label(db, user.workspace_id, audience_type, audience_id)
    if audience_type == "all":
        data["audience_id"] = None
    sender_id = data.get("sender_id")
    if sender_id:
        sender = db.get(SenderIdentity, sender_id)
        if not sender or sender.workspace_id != user.workspace_id:
            raise HTTPException(status_code=422, detail="O remetente selecionado não pertence a este workspace.")
    campaign = Campaign(workspace_id=user.workspace_id, **data)
    db.add(campaign)
    db.flush()
    try:
        resolve_campaign_audience(db, campaign)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    db.commit()
    db.refresh(campaign)
    return campaign


@router.patch("/{campaign_id}", response_model=CampaignOut)
def update_campaign(campaign_id: str, payload: CampaignUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = db.get(Campaign, campaign_id)
    if not campaign or campaign.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Campanha não encontrada.")
    data = payload.model_dump(exclude_unset=True)
    immutable_fields = {"subject", "preheader", "audience_type", "audience_id", "scheduled_at", "body", "editor_mode", "design_json", "html_body", "sender_id", "exclude_list_ids", "exclude_segment_ids", "exclude_tags", "utm_enabled", "utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"}
    if campaign.status in {"sending", "sent"} and immutable_fields.intersection(data):
        raise HTTPException(status_code=409, detail="Uma campanha já enviada ou em processamento não pode ter público/conteúdo alterados.")
    if campaign.send_armed and immutable_fields.intersection(data):
        # Qualquer edição material desarma o agendamento e remove snapshots ainda não enviados.
        for delivery in list(db.scalars(select(EmailDelivery).where(
            EmailDelivery.campaign_id == campaign.id,
            EmailDelivery.is_test.is_(False),
            EmailDelivery.status.in_(["queued", "retry"]),
        ))):
            db.delete(delivery)
        campaign.send_armed = False
        campaign.queued_at = None
    if any(k in data for k in {"editor_mode", "design_json", "html_body", "body"}):
        data = normalize_email_fields(data, existing=campaign)
    next_sender_id = data.get("sender_id", campaign.sender_id)
    if next_sender_id:
        sender = db.get(SenderIdentity, next_sender_id)
        if not sender or sender.workspace_id != user.workspace_id:
            raise HTTPException(status_code=422, detail="O remetente selecionado não pertence a este workspace.")
    next_type = data.get("audience_type", campaign.audience_type or "all")
    next_id = data.get("audience_id", campaign.audience_id)
    if "audience_type" in data or "audience_id" in data:
        data["segment"] = _audience_label(db, user.workspace_id, next_type, next_id)
        if next_type == "all":
            data["audience_id"] = None
    for key, value in data.items():
        setattr(campaign, key, value)
    try:
        resolve_campaign_audience(db, campaign)
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    db.commit()
    db.refresh(campaign)
    return campaign


@router.delete("/{campaign_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_campaign(campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = db.get(Campaign, campaign_id)
    if not campaign or campaign.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Campanha não encontrada.")
    if campaign.status == "sending":
        raise HTTPException(status_code=409, detail="Cancele o processamento antes de excluir a campanha.")
    db.delete(campaign)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/{campaign_id}/audience")
def campaign_audience(campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = db.get(Campaign, campaign_id)
    if not campaign or campaign.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Campanha não encontrada.")
    resolved = resolve_campaign_audience(db, campaign)
    contacts = resolved["eligible"]
    return {
        "base_count": len(resolved["base"]),
        "count": len(contacts),
        "excluded": resolved["excluded_total"],
        "exclusions": resolved["exclusions"],
        "sample": [{"id": c.id, "name": c.name, "last_name": c.last_name, "email": c.email} for c in contacts[:20]],
    }


@router.get("/{campaign_id}/review", response_model=CampaignReviewOut)
def campaign_review(campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = db.get(Campaign, campaign_id)
    if not campaign or campaign.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Campanha não encontrada.")
    try:
        review = build_campaign_review(db, campaign)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    review.pop("eligible_contacts", None)
    return review


@router.post("/{campaign_id}/simulate-send", response_model=CampaignOut)
def simulate_send(campaign_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = db.get(Campaign, campaign_id)
    if not campaign or campaign.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Campanha não encontrada.")

    contacts = _campaign_contacts(db, campaign)
    audience = len(contacts)
    campaign.status = "sent"
    campaign.sent = audience
    campaign.delivered = round(audience * 0.975)
    campaign.opens = round(campaign.delivered * 0.52)
    campaign.clicks = round(campaign.delivered * 0.11)
    campaign.unsub = round(audience * 0.003)
    db.commit()
    db.refresh(campaign)
    return campaign
