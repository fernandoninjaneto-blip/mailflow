from __future__ import annotations

import copy
import re
from datetime import datetime, timedelta, timezone
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..email_content import normalize_email_fields, substitute_variables
from ..models import (
    Automation,
    Campaign,
    ContactList,
    EventCommunication,
    MarketingEvent,
    Segment,
    SenderIdentity,
    Template,
    User,
)
from ..schemas import (
    EventCommunicationCreate,
    EventCommunicationOut,
    EventCommunicationUpdate,
    EventConfirmationAutomationIn,
    EventMetricsOut,
    EventPrepareCampaignsOut,
    EventReadinessOut,
    EventRecommendedPlanOut,
    MarketingEventCreate,
    MarketingEventDetailOut,
    MarketingEventOut,
    MarketingEventUpdate,
)
from ..security import get_current_user

router = APIRouter(prefix="/api/events", tags=["events"])


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


def _same_time(a: datetime | None, b: datetime | None, tolerance_seconds: int = 2) -> bool:
    a, b = _aware(a), _aware(b)
    if a is None or b is None:
        return a is b
    return abs((a - b).total_seconds()) <= tolerance_seconds


def _get_event(db: Session, workspace_id: str, event_id: str) -> MarketingEvent:
    item = db.get(MarketingEvent, event_id)
    if not item or item.workspace_id != workspace_id:
        raise HTTPException(status_code=404, detail="Evento não encontrado.")
    return item


def _audience_label(db: Session, workspace_id: str, audience_type: str, audience_id: str | None) -> str:
    if audience_type == "all":
        return "Todos os contatos ativos"
    if audience_type == "list":
        item = db.get(ContactList, audience_id) if audience_id else None
        if not item or item.workspace_id != workspace_id:
            raise HTTPException(status_code=422, detail="A lista selecionada não pertence a este workspace.")
        return f"Lista: {item.name}"
    if audience_type == "segment":
        item = db.get(Segment, audience_id) if audience_id else None
        if not item or item.workspace_id != workspace_id:
            raise HTTPException(status_code=422, detail="O segmento selecionado não pertence a este workspace.")
        return f"Segmento: {item.name}"
    raise HTTPException(status_code=422, detail="Tipo de audiência inválido.")


def _sender(db: Session, workspace_id: str, sender_id: str | None) -> SenderIdentity | None:
    if sender_id:
        sender = db.get(SenderIdentity, sender_id)
        if not sender or sender.workspace_id != workspace_id or not sender.active:
            raise HTTPException(status_code=422, detail="O remetente selecionado é inválido ou está inativo.")
        return sender
    return db.scalar(select(SenderIdentity).where(
        SenderIdentity.workspace_id == workspace_id,
        SenderIdentity.active.is_(True),
        SenderIdentity.is_default.is_(True),
    ))


def _validate_dates(start_at: datetime, end_at: datetime, offer_open_at: datetime | None, offer_close_at: datetime | None) -> None:
    start_at, end_at = _aware(start_at), _aware(end_at)
    offer_open_at, offer_close_at = _aware(offer_open_at), _aware(offer_close_at)
    if not start_at or not end_at or end_at <= start_at:
        raise HTTPException(status_code=422, detail="O término do evento precisa ser posterior ao início.")
    if offer_open_at and offer_close_at and offer_close_at <= offer_open_at:
        raise HTTPException(status_code=422, detail="O encerramento da oferta precisa ser posterior à abertura.")


def _event_anchor(event: MarketingEvent, relative_to: str, absolute: datetime | None = None) -> datetime | None:
    if relative_to == "absolute":
        return _aware(absolute)
    return {
        "event_start": _aware(event.start_at),
        "event_end": _aware(event.end_at),
        "offer_open": _aware(event.offer_open_at),
        "offer_close": _aware(event.offer_close_at),
    }.get(relative_to)


def _schedule(event: MarketingEvent, relative_to: str, offset_minutes: int, absolute: datetime | None = None) -> datetime | None:
    anchor = _event_anchor(event, relative_to, absolute)
    return anchor + timedelta(minutes=int(offset_minutes or 0)) if anchor else None


def _event_context(event: MarketingEvent) -> dict[str, str]:
    try:
        tz = ZoneInfo(event.timezone or "America/Belem")
    except Exception:
        tz = timezone.utc

    def fmt(value: datetime | None) -> str:
        value = _aware(value)
        if not value:
            return ""
        return value.astimezone(tz).strftime("%d/%m/%Y às %H:%M")

    return {
        "event_name": event.name,
        "evento_nome": event.name,
        "event_start": fmt(event.start_at),
        "evento_inicio": fmt(event.start_at),
        "event_end": fmt(event.end_at),
        "evento_fim": fmt(event.end_at),
        "event_link": event.access_url or "",
        "evento_link": event.access_url or "",
        "event_platform": event.platform or "",
        "evento_plataforma": event.platform or "",
        "offer_open": fmt(event.offer_open_at),
        "oferta_abre": fmt(event.offer_open_at),
        "offer_close": fmt(event.offer_close_at),
        "oferta_fecha": fmt(event.offer_close_at),
    }


def _deep_substitute(value: Any, context: dict[str, Any]) -> Any:
    if isinstance(value, str):
        return substitute_variables(value, context)
    if isinstance(value, list):
        return [_deep_substitute(x, context) for x in value]
    if isinstance(value, dict):
        return {k: _deep_substitute(v, context) for k, v in value.items()}
    return value


def _slug(value: str) -> str:
    clean = re.sub(r"[^a-z0-9]+", "_", value.casefold()).strip("_")
    return clean[:160] or "evento"


def _template_payload(template: Template, event: MarketingEvent) -> dict[str, Any]:
    context = _event_context(event)
    if template.editor_mode == "visual":
        data = {
            "subject": substitute_variables(template.subject, context),
            "preheader": substitute_variables(template.preheader or "", context),
            "editor_mode": "visual",
            "design_json": _deep_substitute(copy.deepcopy(template.design_json or []), context),
            "html_body": "",
            "body": "",
        }
    else:
        data = {
            "subject": substitute_variables(template.subject, context),
            "preheader": substitute_variables(template.preheader or "", context),
            "editor_mode": "html",
            "design_json": [],
            "html_body": substitute_variables(template.html_body or "", context, escape_values=True),
            "body": "",
        }
    return normalize_email_fields(data)


def _linked_campaigns(db: Session, event: MarketingEvent) -> list[Campaign]:
    ids = [x.campaign_id for x in event.communications if x.campaign_id]
    if not ids:
        return []
    return list(db.scalars(select(Campaign).where(Campaign.id.in_(ids), Campaign.workspace_id == event.workspace_id)))


def _has_locked_campaigns(db: Session, event: MarketingEvent) -> bool:
    return any(c.send_armed or c.status in {"sending"} for c in _linked_campaigns(db, event))


def _effective_status(event: MarketingEvent) -> str:
    if event.status == "archived":
        return "archived"
    now = utcnow()
    start, end = _aware(event.start_at), _aware(event.end_at)
    if start and end and start <= now <= end:
        return "live"
    if end and now > end:
        return "completed"
    return event.status


def _metrics(db: Session, event: MarketingEvent) -> EventMetricsOut:
    campaigns = _linked_campaigns(db, event)
    return EventMetricsOut(
        campaigns=len(campaigns),
        sent=sum(c.sent or 0 for c in campaigns),
        delivered=sum(c.delivered or 0 for c in campaigns),
        opens=sum(c.opens or 0 for c in campaigns),
        clicks=sum(c.clicks or 0 for c in campaigns),
        unsubscribes=sum(c.unsub or 0 for c in campaigns),
        bounces=sum(c.bounces or 0 for c in campaigns),
        complaints=sum(c.complaints or 0 for c in campaigns),
    )


def _campaign_mismatch(event: MarketingEvent, comm: EventCommunication, campaign: Campaign, template: Template | None) -> bool:
    if not _same_time(campaign.scheduled_at, comm.scheduled_at):
        return True
    if campaign.audience_type != event.audience_type or campaign.audience_id != event.audience_id:
        return True
    if event.sender_id and campaign.sender_id != event.sender_id:
        return True
    if template:
        expected = _template_payload(template, event)
        if campaign.subject != expected["subject"] or campaign.preheader != expected["preheader"]:
            return True
    return False


def _communication_out(db: Session, event: MarketingEvent, comm: EventCommunication) -> EventCommunicationOut:
    template = db.get(Template, comm.template_id) if comm.template_id else None
    if template and template.workspace_id != event.workspace_id:
        template = None
    campaign = db.get(Campaign, comm.campaign_id) if comm.campaign_id else None
    if campaign and campaign.workspace_id != event.workspace_id:
        campaign = None
    needs_review = bool(campaign and _campaign_mismatch(event, comm, campaign, template))
    return EventCommunicationOut(
        id=comm.id,
        event_id=comm.event_id,
        name=comm.name,
        phase=comm.phase,
        relative_to=comm.relative_to,
        offset_minutes=comm.offset_minutes,
        scheduled_at=comm.scheduled_at,
        template_id=comm.template_id,
        template_name=template.name if template else "",
        campaign_id=campaign.id if campaign else None,
        campaign_status=campaign.status if campaign else "",
        campaign_send_armed=bool(campaign.send_armed) if campaign else False,
        enabled=comm.enabled,
        system_key=comm.system_key,
        needs_review=needs_review,
        created_at=comm.created_at,
        updated_at=comm.updated_at,
    )


def _readiness(db: Session, event: MarketingEvent) -> EventReadinessOut:
    blockers: list[str] = []
    warnings: list[str] = []
    comms = list(event.communications)
    enabled = [c for c in comms if c.enabled]
    with_template = [c for c in enabled if c.template_id]
    prepared = 0
    armed = 0

    try:
        _audience_label(db, event.workspace_id, event.audience_type, event.audience_id)
    except HTTPException as exc:
        blockers.append(str(exc.detail))

    try:
        sender = _sender(db, event.workspace_id, event.sender_id)
    except HTTPException as exc:
        sender = None
        warnings.append(str(exc.detail))
    if not sender:
        warnings.append("Nenhum remetente padrão/selecionado está disponível; defina um antes de revisar os disparos.")
    elif not sender.domain or not sender.domain.ready_for_sending:
        warnings.append("O domínio do remetente ainda não está pronto para envio real. As campanhas podem ser preparadas, mas não devem ser armadas em produção.")

    if event.platform and event.platform.casefold() not in {"presencial", "in-person", "offline"} and not (event.access_url or "").strip():
        warnings.append("O evento online ainda não possui link de acesso.")
    if not enabled:
        blockers.append("Adicione pelo menos uma comunicação habilitada ao evento.")
    if enabled and len(with_template) < len(enabled):
        blockers.append("Todas as comunicações habilitadas precisam de um template antes de preparar campanhas.")

    now = utcnow()
    for comm in enabled:
        if not comm.scheduled_at:
            blockers.append(f"A comunicação '{comm.name}' não possui horário calculado.")
            continue
        if _aware(comm.scheduled_at) <= now and not comm.campaign_id:
            warnings.append(f"A comunicação '{comm.name}' está no passado e não será preparada automaticamente.")
        if comm.campaign_id:
            campaign = db.get(Campaign, comm.campaign_id)
            if campaign and campaign.workspace_id == event.workspace_id:
                prepared += 1
                if campaign.send_armed:
                    armed += 1
                if _campaign_mismatch(event, comm, campaign, db.get(Template, comm.template_id) if comm.template_id else None):
                    warnings.append(f"A campanha de '{comm.name}' está diferente do plano e precisa de nova revisão.")

    if event.audience_type == "list" and not event.registration_automation_id:
        warnings.append("Você pode criar uma automação de confirmação para novos inscritos nesta lista.")

    return EventReadinessOut(
        ready_to_prepare=not blockers,
        communications_total=len(comms),
        communications_enabled=len(enabled),
        communications_with_template=len(with_template),
        campaigns_prepared=prepared,
        campaigns_armed=armed,
        blockers=blockers,
        warnings=warnings,
    )


def _event_out(db: Session, event: MarketingEvent) -> MarketingEventOut:
    audience_label = _audience_label(db, event.workspace_id, event.audience_type, event.audience_id)
    try:
        sender = _sender(db, event.workspace_id, event.sender_id)
    except HTTPException:
        sender = None
    return MarketingEventOut(
        id=event.id,
        name=event.name,
        event_type=event.event_type,
        description=event.description or "",
        status=event.status,
        effective_status=_effective_status(event),
        start_at=event.start_at,
        end_at=event.end_at,
        timezone=event.timezone,
        platform=event.platform or "",
        access_url=event.access_url or "",
        audience_type=event.audience_type,
        audience_id=event.audience_id,
        audience_label=audience_label,
        sender_id=event.sender_id,
        sender_label=f"{sender.name} <{sender.email}>" if sender else "Nenhum remetente disponível",
        offer_open_at=event.offer_open_at,
        offer_close_at=event.offer_close_at,
        registration_automation_id=event.registration_automation_id,
        notes=event.notes or "",
        readiness=_readiness(db, event),
        metrics=_metrics(db, event),
        created_at=event.created_at,
        updated_at=event.updated_at,
    )


def _sync_campaign(db: Session, event: MarketingEvent, comm: EventCommunication) -> str:
    if not comm.template_id:
        return "skipped"
    template = db.get(Template, comm.template_id)
    if not template or template.workspace_id != event.workspace_id:
        return "skipped"
    if not comm.scheduled_at or _aware(comm.scheduled_at) <= utcnow():
        return "skipped"

    payload = _template_payload(template, event)
    audience_label = _audience_label(db, event.workspace_id, event.audience_type, event.audience_id)
    campaign = db.get(Campaign, comm.campaign_id) if comm.campaign_id else None
    if campaign and campaign.workspace_id != event.workspace_id:
        campaign = None
    if campaign and (campaign.send_armed or campaign.status in {"sending", "sent"}):
        return "blocked"

    data = dict(
        name=f"{event.name} • {comm.name}",
        subject=payload["subject"],
        preheader=payload["preheader"],
        segment=audience_label,
        audience_type=event.audience_type,
        audience_id=None if event.audience_type == "all" else event.audience_id,
        status="scheduled",
        scheduled_at=comm.scheduled_at,
        body=payload["body"],
        editor_mode=payload["editor_mode"],
        design_json=payload["design_json"],
        html_body=payload["html_body"],
        sender_id=event.sender_id,
        utm_enabled=True,
        utm_source="mailflow",
        utm_medium="email",
        utm_campaign=_slug(event.name),
        utm_content=comm.system_key or _slug(comm.name),
    )
    if campaign:
        for key, value in data.items():
            setattr(campaign, key, value)
        campaign.send_armed = False
        campaign.queued_at = None
        result = "updated"
    else:
        campaign = Campaign(workspace_id=event.workspace_id, **data)
        db.add(campaign)
        db.flush()
        comm.campaign_id = campaign.id
        result = "prepared"
    return result


def _resync_unlocked_campaigns(db: Session, event: MarketingEvent) -> None:
    for comm in event.communications:
        if comm.relative_to != "absolute":
            comm.scheduled_at = _schedule(event, comm.relative_to, comm.offset_minutes)
        if comm.campaign_id:
            campaign = db.get(Campaign, comm.campaign_id)
            if campaign and not campaign.send_armed and campaign.status not in {"sending", "sent"}:
                _sync_campaign(db, event, comm)


@router.get("", response_model=list[MarketingEventOut])
def list_events(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    items = list(db.scalars(select(MarketingEvent).where(
        MarketingEvent.workspace_id == user.workspace_id
    ).order_by(MarketingEvent.start_at.desc())))
    return [_event_out(db, item) for item in items]


@router.post("", response_model=MarketingEventOut, status_code=status.HTTP_201_CREATED)
def create_event(payload: MarketingEventCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = payload.model_dump()
    _validate_dates(data["start_at"], data["end_at"], data.get("offer_open_at"), data.get("offer_close_at"))
    _audience_label(db, user.workspace_id, data["audience_type"], data.get("audience_id"))
    if data["audience_type"] == "all":
        data["audience_id"] = None
    if data.get("sender_id"):
        _sender(db, user.workspace_id, data["sender_id"])
    event = MarketingEvent(workspace_id=user.workspace_id, **data)
    db.add(event); db.commit(); db.refresh(event)
    return _event_out(db, event)


@router.get("/{event_id}", response_model=MarketingEventDetailOut)
def get_event(event_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    comms = sorted(event.communications, key=lambda x: (_aware(x.scheduled_at) or datetime.max.replace(tzinfo=timezone.utc), x.created_at))
    return MarketingEventDetailOut(event=_event_out(db, event), communications=[_communication_out(db, event, x) for x in comms])


@router.patch("/{event_id}", response_model=MarketingEventOut)
def update_event(event_id: str, payload: MarketingEventUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    data = payload.model_dump(exclude_unset=True)
    schedule_fields = {"start_at", "end_at", "offer_open_at", "offer_close_at", "audience_type", "audience_id", "sender_id"}
    if schedule_fields.intersection(data) and _has_locked_campaigns(db, event):
        raise HTTPException(status_code=409, detail="Há campanhas deste evento já armadas ou enviando. Pause/cancele antes de alterar datas, público ou remetente.")
    next_start = data.get("start_at", event.start_at)
    next_end = data.get("end_at", event.end_at)
    next_offer_open = data.get("offer_open_at", event.offer_open_at)
    next_offer_close = data.get("offer_close_at", event.offer_close_at)
    _validate_dates(next_start, next_end, next_offer_open, next_offer_close)
    next_type = data.get("audience_type", event.audience_type)
    next_audience_id = data.get("audience_id", event.audience_id)
    _audience_label(db, user.workspace_id, next_type, next_audience_id)
    if next_type == "all":
        data["audience_id"] = None
    if data.get("sender_id"):
        _sender(db, user.workspace_id, data["sender_id"])
    for key, value in data.items():
        setattr(event, key, value)
    _resync_unlocked_campaigns(db, event)
    db.commit(); db.refresh(event)
    return _event_out(db, event)


@router.delete("/{event_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_event(event_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    if _has_locked_campaigns(db, event):
        raise HTTPException(status_code=409, detail="Há campanhas armadas ou enviando vinculadas a este evento.")
    # Campanhas preparadas não são apagadas silenciosamente; apenas o vínculo de orquestração é removido.
    db.delete(event); db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/{event_id}/communications", response_model=EventCommunicationOut, status_code=status.HTTP_201_CREATED)
def create_communication(event_id: str, payload: EventCommunicationCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    if payload.template_id:
        template = db.get(Template, payload.template_id)
        if not template or template.workspace_id != user.workspace_id:
            raise HTTPException(status_code=422, detail="Template inválido para esta comunicação.")
    scheduled = _schedule(event, payload.relative_to, payload.offset_minutes, payload.scheduled_at)
    if scheduled is None:
        raise HTTPException(status_code=422, detail="O marco escolhido ainda não possui data configurada no evento.")
    item = EventCommunication(
        workspace_id=user.workspace_id,
        event_id=event.id,
        name=payload.name.strip(),
        phase=payload.phase,
        relative_to=payload.relative_to,
        offset_minutes=payload.offset_minutes,
        scheduled_at=scheduled,
        template_id=payload.template_id,
        enabled=payload.enabled,
    )
    db.add(item); db.commit(); db.refresh(item)
    return _communication_out(db, event, item)


@router.patch("/{event_id}/communications/{communication_id}", response_model=EventCommunicationOut)
def update_communication(event_id: str, communication_id: str, payload: EventCommunicationUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    item = db.get(EventCommunication, communication_id)
    if not item or item.workspace_id != user.workspace_id or item.event_id != event.id:
        raise HTTPException(status_code=404, detail="Comunicação não encontrada.")
    campaign = db.get(Campaign, item.campaign_id) if item.campaign_id else None
    if campaign and (campaign.send_armed or campaign.status in {"sending", "sent"}):
        raise HTTPException(status_code=409, detail="A campanha vinculada já está armada/em processamento. Cancele ou pause antes de editar esta comunicação.")
    data = payload.model_dump(exclude_unset=True)
    next_template = data.get("template_id", item.template_id)
    if next_template:
        template = db.get(Template, next_template)
        if not template or template.workspace_id != user.workspace_id:
            raise HTTPException(status_code=422, detail="Template inválido para esta comunicação.")
    next_relative = data.get("relative_to", item.relative_to)
    next_offset = data.get("offset_minutes", item.offset_minutes)
    absolute = data.get("scheduled_at", item.scheduled_at) if next_relative == "absolute" else None
    scheduled = _schedule(event, next_relative, next_offset, absolute)
    if scheduled is None:
        raise HTTPException(status_code=422, detail="O marco escolhido ainda não possui data configurada no evento.")
    for key, value in data.items():
        if key != "scheduled_at":
            setattr(item, key, value)
    item.scheduled_at = scheduled
    if item.campaign_id:
        _sync_campaign(db, event, item)
    db.commit(); db.refresh(item)
    return _communication_out(db, event, item)


@router.delete("/{event_id}/communications/{communication_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_communication(event_id: str, communication_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    item = db.get(EventCommunication, communication_id)
    if not item or item.workspace_id != user.workspace_id or item.event_id != event.id:
        raise HTTPException(status_code=404, detail="Comunicação não encontrada.")
    campaign = db.get(Campaign, item.campaign_id) if item.campaign_id else None
    if campaign and (campaign.send_armed or campaign.status in {"sending", "sent"}):
        raise HTTPException(status_code=409, detail="A campanha vinculada já está armada/em processamento.")
    db.delete(item); db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/{event_id}/recommended-plan", response_model=EventRecommendedPlanOut)
def create_recommended_plan(event_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    definitions: list[dict[str, Any]] = [
        {"system_key": "reminder_24h", "name": "Lembrete • 24h antes", "phase": "pre_event", "relative_to": "event_start", "offset_minutes": -1440},
        {"system_key": "reminder_1h", "name": "Lembrete • 1h antes", "phase": "pre_event", "relative_to": "event_start", "offset_minutes": -60},
        {"system_key": "event_started", "name": "O evento começou", "phase": "live", "relative_to": "event_start", "offset_minutes": 0},
        {"system_key": "post_event", "name": "Pós-evento • próximos passos", "phase": "post_event", "relative_to": "event_end", "offset_minutes": 30},
    ]
    if event.offer_open_at:
        definitions.append({"system_key": "offer_open", "name": "Oferta aberta", "phase": "offer", "relative_to": "offer_open", "offset_minutes": 0})
    if event.offer_close_at:
        close = _aware(event.offer_close_at)
        open_at = _aware(event.offer_open_at) if event.offer_open_at else None
        twenty_four_before = close - timedelta(days=1) if close else None
        if twenty_four_before and (not open_at or twenty_four_before > open_at):
            definitions.append({"system_key": "offer_close_24h", "name": "Oferta • encerra em 24h", "phase": "offer", "relative_to": "offer_close", "offset_minutes": -1440})
        definitions.append({"system_key": "offer_close_1h", "name": "Oferta • última hora", "phase": "offer", "relative_to": "offer_close", "offset_minutes": -60})

    created = 0
    existing = 0
    for definition in definitions:
        found = db.scalar(select(EventCommunication).where(
            EventCommunication.event_id == event.id,
            EventCommunication.system_key == definition["system_key"],
        ))
        if found:
            existing += 1
            continue
        scheduled = _schedule(event, definition["relative_to"], definition["offset_minutes"])
        if scheduled is None:
            continue
        db.add(EventCommunication(
            workspace_id=user.workspace_id,
            event_id=event.id,
            name=definition["name"],
            phase=definition["phase"],
            relative_to=definition["relative_to"],
            offset_minutes=definition["offset_minutes"],
            scheduled_at=scheduled,
            enabled=True,
            system_key=definition["system_key"],
        ))
        created += 1
    db.commit(); db.refresh(event)
    comms = sorted(event.communications, key=lambda x: (_aware(x.scheduled_at) or datetime.max.replace(tzinfo=timezone.utc), x.created_at))
    return EventRecommendedPlanOut(created=created, existing=existing, communications=[_communication_out(db, event, x) for x in comms])


@router.post("/{event_id}/prepare-campaigns", response_model=EventPrepareCampaignsOut)
def prepare_campaigns(event_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    prepared = updated = skipped = blocked = 0
    messages: list[str] = []
    for comm in sorted(event.communications, key=lambda x: (_aware(x.scheduled_at) or datetime.max.replace(tzinfo=timezone.utc))):
        if not comm.enabled:
            skipped += 1
            continue
        result = _sync_campaign(db, event, comm)
        if result == "prepared":
            prepared += 1
        elif result == "updated":
            updated += 1
        elif result == "blocked":
            blocked += 1
            messages.append(f"'{comm.name}' já possui campanha armada/enviada e não foi alterada.")
        else:
            skipped += 1
            if not comm.template_id:
                messages.append(f"'{comm.name}' não possui template.")
            elif not comm.scheduled_at or _aware(comm.scheduled_at) <= utcnow():
                messages.append(f"'{comm.name}' está no passado e não foi preparada.")
    db.commit(); db.refresh(event)
    comms = sorted(event.communications, key=lambda x: (_aware(x.scheduled_at) or datetime.max.replace(tzinfo=timezone.utc), x.created_at))
    return EventPrepareCampaignsOut(
        prepared=prepared, updated=updated, skipped=skipped, blocked=blocked, messages=messages,
        communications=[_communication_out(db, event, x) for x in comms],
    )


@router.post("/{event_id}/confirmation-automation")
def create_confirmation_automation(event_id: str, payload: EventConfirmationAutomationIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    event = _get_event(db, user.workspace_id, event_id)
    if event.audience_type != "list" or not event.audience_id:
        raise HTTPException(status_code=422, detail="A confirmação automática requer que o público do evento seja uma lista estática.")
    contact_list = db.get(ContactList, event.audience_id)
    if not contact_list or contact_list.workspace_id != user.workspace_id:
        raise HTTPException(status_code=422, detail="Lista do evento inválida.")
    template = db.get(Template, payload.template_id)
    if not template or template.workspace_id != user.workspace_id:
        raise HTTPException(status_code=422, detail="Template de confirmação inválido.")
    if event.registration_automation_id:
        existing = db.get(Automation, event.registration_automation_id)
        if existing and existing.workspace_id == user.workspace_id:
            raise HTTPException(status_code=409, detail="Este evento já possui uma automação de confirmação vinculada.")
    automation = Automation(
        workspace_id=user.workspace_id,
        name=f"{event.name} • Confirmação de inscrição",
        trigger="Entrou na lista do evento",
        steps=[f"Enviar e-mail: {template.name}"],
        trigger_type="list_joined",
        trigger_config={"list_id": contact_list.id},
        steps_json=[{"type": "send_email", "template_id": template.id, "amount": None, "unit": None, "rules": [], "match_mode": "all", "on_false": "stop", "tag": None}],
        reentry_policy="once",
        sender_id=event.sender_id,
        active=payload.active,
        activated_at=utcnow() if payload.active else None,
    )
    db.add(automation); db.flush()
    event.registration_automation_id = automation.id
    db.commit(); db.refresh(automation)
    return {
        "id": automation.id,
        "name": automation.name,
        "active": automation.active,
        "trigger_type": automation.trigger_type,
        "trigger_config": automation.trigger_config,
        "template_id": template.id,
    }
