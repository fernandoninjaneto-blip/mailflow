from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Campaign, Contact, User
from ..schemas import DashboardOut
from ..security import get_current_user

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("", response_model=DashboardOut)
def dashboard(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    wid = user.workspace_id
    contacts_total = db.scalar(select(func.count(Contact.id)).where(Contact.workspace_id == wid)) or 0
    contacts_active = db.scalar(select(func.count(Contact.id)).where(Contact.workspace_id == wid, Contact.status == "active")) or 0
    contacts_unsubscribed = db.scalar(select(func.count(Contact.id)).where(Contact.workspace_id == wid, Contact.status == "unsubscribed")) or 0
    campaigns_total = db.scalar(select(func.count(Campaign.id)).where(Campaign.workspace_id == wid)) or 0
    sums = db.execute(select(
        func.coalesce(func.sum(Campaign.sent), 0),
        func.coalesce(func.sum(Campaign.delivered), 0),
        func.coalesce(func.sum(Campaign.opens), 0),
        func.coalesce(func.sum(Campaign.clicks), 0),
        func.coalesce(func.sum(Campaign.unsub), 0),
    ).where(Campaign.workspace_id == wid, Campaign.status == "sent")).one()
    return DashboardOut(
        contacts_total=contacts_total,
        contacts_active=contacts_active,
        contacts_unsubscribed=contacts_unsubscribed,
        campaigns_total=campaigns_total,
        sent=sums[0], delivered=sums[1], opens=sums[2], clicks=sums[3], unsub=sums[4]
    )
