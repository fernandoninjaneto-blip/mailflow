from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deliverability import (
    build_dmarc_value,
    normalize_domain_name,
    recompute_domain_readiness,
    refresh_domain_dns,
    sender_identity_status,
    sync_domain_from_provider,
    validate_dns_label,
)
from ..domain_provider import DomainProviderError, ResendDomainClient
from ..email_provider import provider_status
from ..models import SenderIdentity, SenderSettings, SendingDomain, User
from ..schemas import (
    DeliverabilityStatusOut,
    SenderIdentityCreate,
    SenderIdentityOut,
    SenderIdentityUpdate,
    SendingDomainCreate,
    SendingDomainOut,
    SendingDomainUpdate,
)
from ..unsubscribe import unsubscribe_readiness
from ..security import get_current_user, require_admin

router = APIRouter(prefix="/api", tags=["domains"])


def _domain(db: Session, workspace_id: str, domain_id: str) -> SendingDomain:
    item = db.get(SendingDomain, domain_id)
    if not item or item.workspace_id != workspace_id:
        raise HTTPException(status_code=404, detail="Domínio não encontrado.")
    return item


def _identity(db: Session, workspace_id: str, identity_id: str) -> SenderIdentity:
    item = db.get(SenderIdentity, identity_id)
    if not item or item.workspace_id != workspace_id:
        raise HTTPException(status_code=404, detail="Remetente não encontrado.")
    return item


def _domain_out(item: SendingDomain) -> SendingDomainOut:
    return SendingDomainOut.model_validate(item, from_attributes=True)


def _identity_out(db: Session, item: SenderIdentity) -> SenderIdentityOut:
    domain = db.get(SendingDomain, item.domain_id)
    return SenderIdentityOut(
        id=item.id,
        domain_id=item.domain_id,
        domain_name=domain.name if domain else "",
        name=item.name,
        email=item.email,
        reply_to=item.reply_to or "",
        active=item.active,
        is_default=item.is_default,
        domain_ready=bool(domain and domain.ready_for_sending),
        status=sender_identity_status(item, domain),
        created_at=item.created_at,
        updated_at=item.updated_at,
    )


def _sync_legacy_sender(db: Session, identity: SenderIdentity) -> None:
    settings = db.scalar(select(SenderSettings).where(SenderSettings.workspace_id == identity.workspace_id))
    if not settings:
        settings = SenderSettings(workspace_id=identity.workspace_id)
        db.add(settings)
    settings.sender_name = identity.name
    settings.sender_email = identity.email
    settings.reply_to = identity.reply_to or ""


def _make_default(db: Session, identity: SenderIdentity) -> None:
    for other in db.scalars(select(SenderIdentity).where(SenderIdentity.workspace_id == identity.workspace_id)):
        other.is_default = other.id == identity.id
    identity.active = True
    _sync_legacy_sender(db, identity)


@router.get("/domains", response_model=list[SendingDomainOut])
def list_domains(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    items = list(db.scalars(select(SendingDomain).where(
        SendingDomain.workspace_id == user.workspace_id
    ).order_by(SendingDomain.created_at.desc())))
    return [_domain_out(x) for x in items]


@router.post("/domains", response_model=SendingDomainOut, status_code=status.HTTP_201_CREATED)
def create_domain(payload: SendingDomainCreate, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    try:
        name = normalize_domain_name(payload.name)
        return_path = validate_dns_label(payload.custom_return_path, "Return-Path")
        tracking = validate_dns_label(payload.tracking_subdomain, "Subdomínio de tracking")
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    if db.scalar(select(SendingDomain).where(SendingDomain.workspace_id == admin.workspace_id, SendingDomain.name == name)):
        raise HTTPException(status_code=409, detail="Este domínio já foi cadastrado neste workspace.")

    report_email = (payload.dmarc_report_email or "").strip().lower()
    item = SendingDomain(
        workspace_id=admin.workspace_id,
        provider="resend",
        name=name,
        region=payload.region,
        custom_return_path=return_path,
        tracking_subdomain=tracking,
        open_tracking=payload.open_tracking,
        click_tracking=payload.click_tracking,
        tls_mode=payload.tls_mode,
        dmarc_policy=payload.dmarc_policy,
        dmarc_report_email=report_email,
        dmarc_value=build_dmarc_value(payload.dmarc_policy, report_email),
        provider_status="provider_unconfigured",
    )
    db.add(item)
    db.flush()

    client = ResendDomainClient()
    if client.configured:
        try:
            provider_data = client.create_domain(
                name=item.name,
                region=item.region,
                custom_return_path=item.custom_return_path,
                open_tracking=item.open_tracking,
                click_tracking=item.click_tracking,
                tracking_subdomain=item.tracking_subdomain,
            )
            sync_domain_from_provider(item, provider_data)
            # TLS é atualizado por endpoint próprio do provedor depois da criação.
            if item.provider_domain_id:
                client.update_domain(
                    item.provider_domain_id,
                    open_tracking=item.open_tracking,
                    click_tracking=item.click_tracking,
                    tracking_subdomain=item.tracking_subdomain,
                    tls_mode=item.tls_mode,
                )
        except DomainProviderError as exc:
            item.provider_status = "provider_error"
            item.last_error = str(exc)
    refresh_domain_dns(item)
    db.commit(); db.refresh(item)
    return _domain_out(item)


@router.post("/domains/{domain_id}/register", response_model=SendingDomainOut)
def register_domain(domain_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = _domain(db, admin.workspace_id, domain_id)
    if item.provider_domain_id:
        return _domain_out(item)
    client = ResendDomainClient()
    if not client.configured:
        raise HTTPException(status_code=422, detail="RESEND_API_KEY não configurada no backend.")
    try:
        data = client.create_domain(
            name=item.name,
            region=item.region,
            custom_return_path=item.custom_return_path,
            open_tracking=item.open_tracking,
            click_tracking=item.click_tracking,
            tracking_subdomain=item.tracking_subdomain,
        )
        sync_domain_from_provider(item, data)
        if item.provider_domain_id:
            client.update_domain(
                item.provider_domain_id,
                open_tracking=item.open_tracking,
                click_tracking=item.click_tracking,
                tracking_subdomain=item.tracking_subdomain,
                tls_mode=item.tls_mode,
            )
        refresh_domain_dns(item)
    except DomainProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    db.commit(); db.refresh(item)
    return _domain_out(item)


@router.post("/domains/{domain_id}/refresh", response_model=SendingDomainOut)
def refresh_domain(domain_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _domain(db, user.workspace_id, domain_id)
    if item.provider_domain_id:
        client = ResendDomainClient()
        if client.configured:
            try:
                sync_domain_from_provider(item, client.get_domain(item.provider_domain_id))
                item.last_error = ""
            except DomainProviderError as exc:
                item.last_error = str(exc)
        elif item.provider_status != "verified":
            item.provider_status = "provider_unconfigured"
    refresh_domain_dns(item)
    db.commit(); db.refresh(item)
    return _domain_out(item)


@router.post("/domains/{domain_id}/verify", response_model=SendingDomainOut)
def verify_domain(domain_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = _domain(db, admin.workspace_id, domain_id)
    client = ResendDomainClient()
    if not client.configured:
        raise HTTPException(status_code=422, detail="RESEND_API_KEY não configurada no backend.")
    try:
        if not item.provider_domain_id:
            data = client.create_domain(
                name=item.name,
                region=item.region,
                custom_return_path=item.custom_return_path,
                open_tracking=item.open_tracking,
                click_tracking=item.click_tracking,
                tracking_subdomain=item.tracking_subdomain,
            )
            sync_domain_from_provider(item, data)
        client.verify_domain(item.provider_domain_id)
        # A verificação é assíncrona, mas buscar logo depois já devolve o estado atual.
        sync_domain_from_provider(item, client.get_domain(item.provider_domain_id))
        refresh_domain_dns(item)
    except DomainProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    db.commit(); db.refresh(item)
    return _domain_out(item)


@router.patch("/domains/{domain_id}", response_model=SendingDomainOut)
def update_domain(payload: SendingDomainUpdate, domain_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = _domain(db, admin.workspace_id, domain_id)
    data = payload.model_dump(exclude_unset=True)
    for key, value in data.items():
        if key == "dmarc_report_email":
            value = (value or "").strip().lower()
        setattr(item, key, value)
    item.dmarc_value = build_dmarc_value(item.dmarc_policy, item.dmarc_report_email)

    if item.provider_domain_id and any(k in data for k in {"open_tracking", "click_tracking", "tls_mode"}):
        client = ResendDomainClient()
        if not client.configured:
            raise HTTPException(status_code=422, detail="RESEND_API_KEY não configurada para atualizar o domínio no provedor.")
        try:
            client.update_domain(
                item.provider_domain_id,
                open_tracking=item.open_tracking,
                click_tracking=item.click_tracking,
                tracking_subdomain=item.tracking_subdomain,
                tls_mode=item.tls_mode,
            )
            sync_domain_from_provider(item, client.get_domain(item.provider_domain_id))
        except DomainProviderError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc
    refresh_domain_dns(item)
    db.commit(); db.refresh(item)
    return _domain_out(item)


@router.get("/senders", response_model=list[SenderIdentityOut])
def list_senders(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    items = list(db.scalars(select(SenderIdentity).where(
        SenderIdentity.workspace_id == user.workspace_id
    ).order_by(SenderIdentity.is_default.desc(), SenderIdentity.created_at.asc())))
    return [_identity_out(db, x) for x in items]


@router.post("/senders", response_model=SenderIdentityOut, status_code=status.HTTP_201_CREATED)
def create_sender(payload: SenderIdentityCreate, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    domain = _domain(db, admin.workspace_id, payload.domain_id)
    email = str(payload.email).lower()
    email_domain = email.rsplit("@", 1)[1]
    if email_domain != domain.name:
        raise HTTPException(status_code=422, detail=f"O e-mail do remetente precisa usar exatamente o domínio {domain.name}.")
    if db.scalar(select(SenderIdentity).where(SenderIdentity.workspace_id == admin.workspace_id, SenderIdentity.email == email)):
        raise HTTPException(status_code=409, detail="Este remetente já está cadastrado.")
    existing_count = len(list(db.scalars(select(SenderIdentity.id).where(SenderIdentity.workspace_id == admin.workspace_id))))
    item = SenderIdentity(
        workspace_id=admin.workspace_id,
        domain_id=domain.id,
        name=payload.name.strip(),
        email=email,
        reply_to=str(payload.reply_to).lower() if payload.reply_to else "",
        is_default=payload.is_default or existing_count == 0,
        active=True,
    )
    db.add(item); db.flush()
    if item.is_default:
        _make_default(db, item)
    db.commit(); db.refresh(item)
    return _identity_out(db, item)


@router.patch("/senders/{identity_id}", response_model=SenderIdentityOut)
def update_sender(payload: SenderIdentityUpdate, identity_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = _identity(db, admin.workspace_id, identity_id)
    data = payload.model_dump(exclude_unset=True)
    if data.get("name") is not None:
        item.name = data["name"].strip()
    if "reply_to" in data:
        item.reply_to = str(data["reply_to"]).lower() if data["reply_to"] else ""
    if "active" in data:
        item.active = bool(data["active"])
    if data.get("is_default"):
        _make_default(db, item)
    elif data.get("is_default") is False and item.is_default:
        raise HTTPException(status_code=422, detail="Defina outro remetente como padrão antes de remover o padrão atual.")
    db.commit(); db.refresh(item)
    return _identity_out(db, item)


@router.post("/senders/{identity_id}/default", response_model=SenderIdentityOut)
def set_default_sender(identity_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = _identity(db, admin.workspace_id, identity_id)
    _make_default(db, item)
    db.commit(); db.refresh(item)
    return _identity_out(db, item)


@router.get("/deliverability/status", response_model=DeliverabilityStatusOut)
def deliverability_status(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    pstatus = provider_status()
    domains = list(db.scalars(select(SendingDomain).where(SendingDomain.workspace_id == user.workspace_id)))
    identities = list(db.scalars(select(SenderIdentity).where(SenderIdentity.workspace_id == user.workspace_id)))
    ready_domains = [x for x in domains if x.ready_for_sending]
    ready_identities = []
    for identity in identities:
        domain = db.get(SendingDomain, identity.domain_id)
        if identity.active and domain and domain.ready_for_sending:
            ready_identities.append(identity)
    default = next((x for x in ready_identities if x.is_default), None)
    blockers: list[str] = []
    warnings: list[str] = []
    if pstatus["provider"] == "resend" and not pstatus["configured"]:
        blockers.append("RESEND_API_KEY não configurada.")
    if not ready_domains:
        blockers.append("Nenhum domínio possui SPF, DKIM e DMARC validados.")
    if not default:
        blockers.append("Nenhum remetente padrão ativo está ligado a um domínio pronto.")
    if not pstatus.get("webhook_configured") and pstatus["provider"] == "resend":
        warnings.append("Configure o webhook assinado do Resend para receber bounces, reclamações e eventos.")
    warnings.append("Para Gmail/Yahoo em massa, mantenha a taxa de spam abaixo de 0,3% e monitore a reputação do domínio.")
    unsubscribe = unsubscribe_readiness()
    if not unsubscribe["ready"]:
        warnings.extend(unsubscribe["errors"])
    live_ready = bool(pstatus["live"] and not blockers)
    bulk_ready = bool(live_ready and unsubscribe["ready"] and pstatus.get("webhook_configured"))
    return DeliverabilityStatusOut(
        provider=pstatus["provider"],
        provider_configured=pstatus["configured"],
        domains=len(domains),
        ready_domains=len(ready_domains),
        sender_identities=len(identities),
        ready_sender_identities=len(ready_identities),
        default_sender_id=default.id if default else None,
        live_send_ready=live_ready,
        bulk_marketing_ready=bulk_ready,
        blockers=blockers,
        warnings=warnings,
    )
