from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..email_content import normalize_email_fields
from ..models import SenderSettings, Template, User
from ..schemas import SenderSettingsIn, SenderSettingsOut, TemplateIn, TemplateOut
from ..security import get_current_user

router = APIRouter(prefix="/api", tags=["resources"])


@router.get("/templates", response_model=list[TemplateOut])
def list_templates(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return list(db.scalars(select(Template).where(Template.workspace_id == user.workspace_id).order_by(Template.created_at.desc())))


@router.post("/templates", response_model=TemplateOut, status_code=status.HTTP_201_CREATED)
def create_template(payload: TemplateIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = normalize_email_fields(payload.model_dump())
    item = Template(workspace_id=user.workspace_id, **data)
    db.add(item); db.commit(); db.refresh(item); return item


@router.delete("/templates/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_template(item_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = db.get(Template, item_id)
    if not item or item.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Template não encontrado.")
    db.delete(item); db.commit(); return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/settings/sender", response_model=SenderSettingsOut)
def get_settings(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = db.scalar(select(SenderSettings).where(SenderSettings.workspace_id == user.workspace_id))
    if not item:
        item = SenderSettings(workspace_id=user.workspace_id)
        db.add(item); db.commit(); db.refresh(item)
    return item


@router.put("/settings/sender", response_model=SenderSettingsOut)
def update_settings(payload: SenderSettingsIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = db.scalar(select(SenderSettings).where(SenderSettings.workspace_id == user.workspace_id))
    if not item:
        item = SenderSettings(workspace_id=user.workspace_id)
        db.add(item)
    for key, value in payload.model_dump().items():
        setattr(item, key, value)
    db.commit(); db.refresh(item); return item
