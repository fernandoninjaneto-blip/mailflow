from __future__ import annotations

from datetime import timedelta
import html
import logging
import os

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import PasswordResetToken, SenderSettings, User, UserSession, Workspace
from ..schemas import AuthMeOut, ForgotPasswordIn, ForgotPasswordOut, LoginIn, RegisterIn, ResetPasswordIn
from ..security import clear_session_cookie, create_session, get_current_session, get_current_user, hash_password, new_token, token_hash, utcnow, verify_password
from ..email_provider import ProviderError, get_provider
from ..rate_limit import consume as consume_rate_limit, request_ip, reset as reset_rate_limit

router = APIRouter(prefix="/api/auth", tags=["auth"])
logger = logging.getLogger("mailflow.auth")

EXPOSE_RESET_TOKEN = os.getenv("MAILFLOW_EXPOSE_RESET_TOKEN", "false").lower() == "true"
RESET_MINUTES = int(os.getenv("PASSWORD_RESET_MINUTES", "30"))
# Equaliza o custo de login quando o e-mail não existe, reduzindo enumeração por timing.
_DUMMY_PASSWORD_HASH = hash_password("mailflow-dummy-password-2026")


@router.post("/register", response_model=AuthMeOut, status_code=status.HTTP_201_CREATED)
def register(payload: RegisterIn, request: Request, response: Response, db: Session = Depends(get_db)):
    email = str(payload.email).strip().lower()
    consume_rate_limit(db, action="register_ip", identity=request_ip(request), limit=8, window_seconds=3600, block_seconds=3600)
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Já existe uma conta com este e-mail.")

    workspace = Workspace(name=payload.workspace_name.strip())
    db.add(workspace)
    db.flush()

    user = User(
        workspace_id=workspace.id,
        name=payload.name.strip(),
        email=email,
        password_hash=hash_password(payload.password),
        role="admin",
        active=True,
    )
    db.add(user)
    db.add(SenderSettings(workspace_id=workspace.id, sender_name=workspace.name))
    db.commit()
    db.refresh(user)
    db.refresh(workspace)
    create_session(db, user, request, response)
    return AuthMeOut(user=user, workspace=workspace)


@router.post("/login", response_model=AuthMeOut)
def login(payload: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    email = str(payload.email).strip().lower()
    consume_rate_limit(db, action="login_email", identity=email, limit=10, window_seconds=900, block_seconds=900)
    consume_rate_limit(db, action="login_ip", identity=request_ip(request), limit=60, window_seconds=900, block_seconds=900)
    user = db.scalar(select(User).where(User.email == email))
    password_ok = verify_password(payload.password, user.password_hash if user else _DUMMY_PASSWORD_HASH)
    if not user or not user.active or not password_ok:
        raise HTTPException(status_code=401, detail="E-mail ou senha inválidos.")
    workspace = db.get(Workspace, user.workspace_id)
    reset_rate_limit(db, action="login_email", identity=email)
    create_session(db, user, request, response)
    return AuthMeOut(user=user, workspace=workspace)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    response: Response,
    session: UserSession = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    db.delete(session)
    db.commit()
    clear_session_cookie(response)
    response.status_code = status.HTTP_204_NO_CONTENT
    return response


@router.get("/me", response_model=AuthMeOut)
def me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    workspace = db.get(Workspace, user.workspace_id)
    return AuthMeOut(user=user, workspace=workspace)


@router.post("/forgot-password", response_model=ForgotPasswordOut)
def forgot_password(payload: ForgotPasswordIn, request: Request, db: Session = Depends(get_db)):
    email = str(payload.email).strip().lower()
    consume_rate_limit(db, action="forgot_ip", identity=request_ip(request), limit=10, window_seconds=3600, block_seconds=3600)
    consume_rate_limit(db, action="forgot_email", identity=email, limit=5, window_seconds=3600, block_seconds=3600)
    user = db.scalar(select(User).where(User.email == email, User.active.is_(True)))
    generic = "Se o e-mail estiver cadastrado, você receberá instruções para redefinir a senha."
    if not user:
        return ForgotPasswordOut(message=generic)

    # Apenas o token de recuperação mais recente permanece válido.
    for previous in db.scalars(select(PasswordResetToken).where(
        PasswordResetToken.user_id == user.id,
        PasswordResetToken.used_at.is_(None),
    )):
        previous.used_at = utcnow()

    raw = new_token()
    reset = PasswordResetToken(
        user_id=user.id,
        token_hash=token_hash(raw),
        expires_at=utcnow() + timedelta(minutes=RESET_MINUTES),
    )
    db.add(reset)
    db.commit()

    # No Passo 7, quando um provider real está configurado, o link já pode ser entregue por e-mail.
    provider = get_provider()
    sender = db.scalar(select(SenderSettings).where(SenderSettings.workspace_id == user.workspace_id))
    workspace = db.get(Workspace, user.workspace_id)
    app_url = os.getenv("APP_URL", "http://localhost:8080").rstrip("/")
    if provider.live and sender and sender.sender_email:
        reset_url = f"{app_url}/?reset_token={raw}"
        try:
            provider.send(
                from_name=sender.sender_name or (workspace.name if workspace else "MailFlow"),
                from_email=sender.sender_email,
                to_email=user.email,
                subject="Redefinição de senha do MailFlow",
                html=f'<p>Olá, {html.escape(user.name)}.</p><p>Use o link abaixo para redefinir sua senha:</p><p><a href="{html.escape(reset_url, quote=True)}">Redefinir senha</a></p><p>O link expira em {RESET_MINUTES} minutos.</p>',
                text=f"Redefina sua senha: {reset_url}\nO link expira em {RESET_MINUTES} minutos.",
                reply_to=sender.reply_to or "",
                idempotency_key=f"password-reset/{reset.id}",
            )
        except ProviderError as exc:
            # Não revelamos ao solicitante se a conta existe ou se houve falha de entrega.
            logger.warning("password_reset_delivery_failed provider=%s retryable=%s", getattr(provider, "name", "unknown"), getattr(exc, "retryable", False))

    return ForgotPasswordOut(message=generic, reset_token=raw if EXPOSE_RESET_TOKEN else None)


@router.post("/reset-password")
def reset_password(payload: ResetPasswordIn, request: Request, db: Session = Depends(get_db)):
    consume_rate_limit(db, action="reset_ip", identity=request_ip(request), limit=15, window_seconds=3600, block_seconds=3600)
    reset = db.scalar(select(PasswordResetToken).where(
        PasswordResetToken.token_hash == token_hash(payload.token),
        PasswordResetToken.used_at.is_(None),
        PasswordResetToken.expires_at > utcnow(),
    ))
    if not reset:
        raise HTTPException(status_code=400, detail="Link de recuperação inválido ou expirado.")

    user = db.get(User, reset.user_id)
    if not user or not user.active:
        raise HTTPException(status_code=400, detail="Não foi possível redefinir esta senha.")

    user.password_hash = hash_password(payload.new_password)
    reset.used_at = utcnow()
    # Invalida todas as sessões existentes após troca de senha.
    for session in db.scalars(select(UserSession).where(UserSession.user_id == user.id)):
        db.delete(session)
    db.commit()
    return {"message": "Senha redefinida com sucesso. Faça login novamente."}
