from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import (
    Automation,
    AutomationRun,
    Campaign,
    Contact,
    EmailDelivery,
    EmailEngagementEvent,
    EventCommunication,
    MarketingEvent,
    SenderIdentity,
    SendingDomain,
    SuppressionEntry,
    User,
)
from ..security import get_current_user

router = APIRouter(prefix="/api/reports", tags=["reports"])


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


def in_window(value: datetime | None, start: datetime, end: datetime) -> bool:
    value = aware(value)
    return bool(value and start <= value < end)


def safe_rate(num: int | float, den: int | float) -> float:
    if not den:
        return 0.0
    return round((float(num) / float(den)) * 100, 2)


def pct_change(current: int | float, previous: int | float) -> float | None:
    if previous == 0:
        if current == 0:
            return 0.0
        return None
    return round(((float(current) - float(previous)) / abs(float(previous))) * 100, 2)


def iso_day(value: datetime | None) -> str | None:
    value = aware(value)
    return value.date().isoformat() if value else None


def _delivery_summary(rows: list[EmailDelivery]) -> dict:
    sent = sum(1 for row in rows if row.sent_at is not None)
    delivered = sum(1 for row in rows if row.delivered_at is not None)
    opens = sum(1 for row in rows if row.opened_at is not None)
    clicks = sum(1 for row in rows if row.clicked_at is not None)
    bounces = sum(1 for row in rows if row.bounced_at is not None)
    complaints = sum(1 for row in rows if row.complained_at is not None)
    unsubscribes = sum(1 for row in rows if row.unsubscribed_at is not None)
    failed = sum(1 for row in rows if row.failed_at is not None or row.status == "failed")
    queued = sum(1 for row in rows if row.status in {"queued", "retry"})
    return {
        "sent": sent,
        "delivered": delivered,
        "opens": opens,
        "clicks": clicks,
        "bounces": bounces,
        "complaints": complaints,
        "unsubscribes": unsubscribes,
        "failed": failed,
        "queued": queued,
        "delivery_rate": safe_rate(delivered, sent),
        "open_rate": safe_rate(opens, delivered),
        "click_rate": safe_rate(clicks, delivered),
        "ctor": safe_rate(clicks, opens),
        "bounce_rate": safe_rate(bounces, sent),
        "complaint_rate": safe_rate(complaints, delivered),
        "unsubscribe_rate": safe_rate(unsubscribes, delivered),
        "failure_rate": safe_rate(failed, sent + failed),
    }


def _metric_changes(current: dict, previous: dict) -> dict:
    keys = [
        "sent", "delivered", "opens", "clicks", "bounces", "complaints",
        "unsubscribes", "delivery_rate", "open_rate", "click_rate", "ctor",
        "bounce_rate", "complaint_rate", "unsubscribe_rate",
    ]
    return {key: pct_change(current.get(key, 0), previous.get(key, 0)) for key in keys}


def _campaign_metrics(campaign: Campaign, deliveries: list[EmailDelivery]) -> dict:
    summary = _delivery_summary(deliveries)
    activity_at = aware(campaign.send_completed_at or campaign.send_started_at or campaign.queued_at or campaign.scheduled_at or campaign.updated_at)
    return {
        "id": campaign.id,
        "name": campaign.name,
        "subject": campaign.subject,
        "status": campaign.status,
        "activity_at": activity_at.isoformat() if activity_at else None,
        **summary,
    }


def _alert(alerts: list[dict], severity: str, code: str, title: str, message: str, value=None, threshold=None):
    alerts.append({
        "severity": severity,
        "code": code,
        "title": title,
        "message": message,
        "value": value,
        "threshold": threshold,
    })


@router.get("/overview")
def reports_overview(
    days: int = Query(30, ge=1, le=365),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    wid = user.workspace_id
    end = utcnow()
    start = end - timedelta(days=days)
    previous_start = start - timedelta(days=days)

    # A fila é a fonte canônica para KPIs operacionais de envio. Testes nunca entram nos relatórios.
    all_period_deliveries = db.scalars(
        select(EmailDelivery).where(
            EmailDelivery.workspace_id == wid,
            EmailDelivery.is_test.is_(False),
            EmailDelivery.queued_at >= previous_start,
            EmailDelivery.queued_at < end,
        )
    ).all()
    current_deliveries = [d for d in all_period_deliveries if in_window(d.queued_at, start, end)]
    previous_deliveries = [d for d in all_period_deliveries if in_window(d.queued_at, previous_start, start)]

    current = _delivery_summary(current_deliveries)
    previous = _delivery_summary(previous_deliveries)

    all_contacts = db.scalars(select(Contact).where(Contact.workspace_id == wid)).all()
    current_new_contacts = [c for c in all_contacts if in_window(c.created_at, start, end)]
    previous_new_contacts = [c for c in all_contacts if in_window(c.created_at, previous_start, start)]
    active_contacts = sum(1 for c in all_contacts if c.status == "active")
    unsubscribed_contacts = sum(1 for c in all_contacts if c.status == "unsubscribed")

    current_suppressions = db.scalars(
        select(SuppressionEntry).where(
            SuppressionEntry.workspace_id == wid,
            SuppressionEntry.active.is_(True),
        )
    ).all()
    suppressions_created = [x for x in current_suppressions if in_window(x.created_at, start, end)]

    # Série diária completa, mesmo em dias sem atividade.
    daily: dict[str, dict] = {}
    for offset in range(days):
        day = (start.date() + timedelta(days=offset)).isoformat()
        daily[day] = {
            "date": day, "new_contacts": 0, "sent": 0, "delivered": 0,
            "opens": 0, "clicks": 0, "bounces": 0, "complaints": 0,
            "unsubscribes": 0, "failed": 0,
        }
    for contact in current_new_contacts:
        day = iso_day(contact.created_at)
        if day in daily:
            daily[day]["new_contacts"] += 1
    for delivery in current_deliveries:
        day = iso_day(delivery.queued_at)
        if day not in daily:
            continue
        if delivery.sent_at: daily[day]["sent"] += 1
        if delivery.delivered_at: daily[day]["delivered"] += 1
        if delivery.opened_at: daily[day]["opens"] += 1
        if delivery.clicked_at: daily[day]["clicks"] += 1
        if delivery.bounced_at: daily[day]["bounces"] += 1
        if delivery.complained_at: daily[day]["complaints"] += 1
        if delivery.unsubscribed_at: daily[day]["unsubscribes"] += 1
        if delivery.failed_at or delivery.status == "failed": daily[day]["failed"] += 1

    # Campanhas: comparação baseada em entregas que entraram na fila dentro do período.
    campaign_rows = db.scalars(select(Campaign).where(Campaign.workspace_id == wid)).all()
    campaign_map = {c.id: c for c in campaign_rows}
    by_campaign: dict[str, list[EmailDelivery]] = defaultdict(list)
    for delivery in current_deliveries:
        if delivery.campaign_id:
            by_campaign[delivery.campaign_id].append(delivery)
    campaign_comparison = [
        _campaign_metrics(campaign_map[cid], rows)
        for cid, rows in by_campaign.items()
        if cid in campaign_map
    ]
    campaign_comparison.sort(key=lambda item: (item["delivered"], item["sent"]), reverse=True)

    top_subjects = sorted(
        [x for x in campaign_comparison if x["delivered"] > 0],
        key=lambda item: (item["open_rate"], item["delivered"]),
        reverse=True,
    )[:8]

    # Ranking de links usa eventos brutos para total e delivery_id para cliques únicos.
    click_events = db.scalars(
        select(EmailEngagementEvent).where(
            EmailEngagementEvent.workspace_id == wid,
            EmailEngagementEvent.event_type == "clicked",
            EmailEngagementEvent.occurred_at >= start,
            EmailEngagementEvent.occurred_at < end,
        )
    ).all()
    links: dict[str, dict] = {}
    for event in click_events:
        url = (event.link_url or "").strip()
        if not url:
            continue
        entry = links.setdefault(url, {"url": url, "host": event.link_host or urlparse(url).netloc, "total_clicks": 0, "delivery_ids": set(), "contact_ids": set()})
        entry["total_clicks"] += 1
        entry["delivery_ids"].add(event.delivery_id)
        if event.contact_id:
            entry["contact_ids"].add(event.contact_id)
    top_links = [
        {
            "url": data["url"], "host": data["host"], "total_clicks": data["total_clicks"],
            "unique_clicks": len(data["delivery_ids"]), "unique_contacts": len(data["contact_ids"]),
        }
        for data in links.values()
    ]
    top_links.sort(key=lambda item: (item["unique_clicks"], item["total_clicks"]), reverse=True)
    top_links = top_links[:10]

    # Origem do envio: campanhas vs. automações vs. outros jobs.
    source_breakdown = {
        "campaign": _delivery_summary([d for d in current_deliveries if d.campaign_id]),
        "automation": _delivery_summary([d for d in current_deliveries if not d.campaign_id and d.automation_run_id]),
        "other": _delivery_summary([d for d in current_deliveries if not d.campaign_id and not d.automation_run_id]),
    }

    automations = db.scalars(select(Automation).where(Automation.workspace_id == wid)).all()
    automation_runs = db.scalars(
        select(AutomationRun).where(
            AutomationRun.workspace_id == wid,
            AutomationRun.started_at >= start,
            AutomationRun.started_at < end,
        )
    ).all()
    runs_by_automation: dict[str, list[AutomationRun]] = defaultdict(list)
    for run in automation_runs:
        runs_by_automation[run.automation_id].append(run)
    automation_performance = []
    for automation in automations:
        rows = runs_by_automation.get(automation.id, [])
        if not rows and not automation.active:
            continue
        completed = sum(1 for r in rows if r.status == "completed")
        failed = sum(1 for r in rows if r.status == "failed")
        active_runs = sum(1 for r in rows if r.status in {"running", "waiting"})
        automation_performance.append({
            "id": automation.id,
            "name": automation.name,
            "active": automation.active,
            "runs": len(rows),
            "completed": completed,
            "failed": failed,
            "in_progress": active_runs,
            "completion_rate": safe_rate(completed, len(rows)),
        })
    automation_performance.sort(key=lambda item: item["runs"], reverse=True)

    # Eventos: agregam apenas as campanhas explicitamente vinculadas às comunicações do evento.
    marketing_events = db.scalars(select(MarketingEvent).where(MarketingEvent.workspace_id == wid)).all()
    communications = db.scalars(select(EventCommunication).where(EventCommunication.workspace_id == wid)).all()
    comms_by_event: dict[str, list[EventCommunication]] = defaultdict(list)
    for comm in communications:
        comms_by_event[comm.event_id].append(comm)
    event_performance = []
    for event in marketing_events:
        event_start = aware(event.start_at)
        event_end = aware(event.end_at)
        relevant = bool(
            (event_start and previous_start <= event_start < end)
            or (event_end and previous_start <= event_end < end)
            or (event_start and event_end and event_start <= end and event_end >= start)
        )
        comms = comms_by_event.get(event.id, [])
        campaign_ids = {c.campaign_id for c in comms if c.campaign_id}
        event_deliveries = [d for d in current_deliveries if d.campaign_id in campaign_ids]
        if not relevant and not event_deliveries:
            continue
        summary = _delivery_summary(event_deliveries)
        prepared = sum(1 for c in comms if c.campaign_id)
        armed = sum(1 for c in comms if c.campaign_id and campaign_map.get(c.campaign_id) and campaign_map[c.campaign_id].send_armed)
        event_performance.append({
            "id": event.id,
            "name": event.name,
            "event_type": event.event_type,
            "status": event.status,
            "start_at": event.start_at.isoformat() if event.start_at else None,
            "communications": len([c for c in comms if c.enabled]),
            "campaigns_prepared": prepared,
            "campaigns_armed": armed,
            **summary,
        })
    event_performance.sort(key=lambda item: item["start_at"] or "", reverse=True)

    # Alertas operacionais. Os thresholds são internos do produto e ficam explícitos no payload.
    alerts: list[dict] = []
    if current["sent"] >= 100 and current["delivery_rate"] < 95:
        _alert(alerts, "warning", "delivery_rate_low", "Entregabilidade abaixo do limite interno", f"A taxa de entrega no período está em {current['delivery_rate']:.2f}%.", current["delivery_rate"], 95)
    if current["sent"] >= 100 and current["bounce_rate"] > 2:
        _alert(alerts, "critical", "bounce_rate_high", "Bounce elevado", f"A taxa de bounce no período está em {current['bounce_rate']:.2f}%.", current["bounce_rate"], 2)
    if current["delivered"] >= 100 and current["complaint_rate"] > 0.1:
        _alert(alerts, "critical", "complaint_rate_high", "Reclamações de spam elevadas", f"A taxa de reclamação no período está em {current['complaint_rate']:.3f}%.", current["complaint_rate"], 0.1)
    if current["delivered"] >= 100 and current["unsubscribe_rate"] > 1:
        _alert(alerts, "warning", "unsubscribe_rate_high", "Descadastros acima do limite interno", f"A taxa de descadastro no período está em {current['unsubscribe_rate']:.2f}%.", current["unsubscribe_rate"], 1)

    stuck_before = end - timedelta(minutes=30)
    stuck_jobs = db.scalars(
        select(EmailDelivery).where(
            EmailDelivery.workspace_id == wid,
            EmailDelivery.is_test.is_(False),
            EmailDelivery.status.in_(["queued", "retry"]),
            EmailDelivery.queued_at < stuck_before,
        )
    ).all()
    if stuck_jobs:
        _alert(alerts, "critical", "queue_stuck", "Fila com itens antigos", f"Há {len(stuck_jobs)} entrega(s) em fila/retry há mais de 30 minutos.", len(stuck_jobs), 0)

    overdue_campaigns = [
        c for c in campaign_rows
        if c.status == "scheduled" and c.send_armed and aware(c.scheduled_at) and aware(c.scheduled_at) < end - timedelta(minutes=10)
    ]
    if overdue_campaigns:
        _alert(alerts, "critical", "campaign_overdue", "Campanha agendada atrasada", f"Há {len(overdue_campaigns)} campanha(s) armada(s) com horário vencido.", len(overdue_campaigns), 0)

    failed_runs = sum(1 for run in automation_runs if run.status == "failed")
    if failed_runs:
        _alert(alerts, "warning", "automation_failures", "Falhas em automações", f"{failed_runs} execução(ões) de automação falharam no período.", failed_runs, 0)

    ready_domains = db.scalars(select(SendingDomain).where(SendingDomain.workspace_id == wid, SendingDomain.ready_for_sending.is_(True))).all()
    default_senders = db.scalars(select(SenderIdentity).where(SenderIdentity.workspace_id == wid, SenderIdentity.active.is_(True), SenderIdentity.is_default.is_(True))).all()
    if not ready_domains:
        _alert(alerts, "info", "no_ready_domain", "Nenhum domínio de envio pronto", "O painel não encontrou domínio marcado como pronto para envio real.", 0, 1)
    if not default_senders:
        _alert(alerts, "info", "no_default_sender", "Nenhum remetente padrão ativo", "Defina um remetente padrão para reduzir bloqueios operacionais em novas campanhas.", 0, 1)

    severity_order = {"critical": 0, "warning": 1, "info": 2}
    alerts.sort(key=lambda item: severity_order.get(item["severity"], 9))

    summary = {
        **current,
        "active_contacts": active_contacts,
        "contacts_total": len(all_contacts),
        "new_contacts": len(current_new_contacts),
        "unsubscribed_contacts": unsubscribed_contacts,
        "active_suppressions": len(current_suppressions),
        "new_suppressions": len(suppressions_created),
        "campaigns_with_activity": len(campaign_comparison),
    }
    previous_summary = {
        **previous,
        "new_contacts": len(previous_new_contacts),
    }
    changes = _metric_changes(current, previous)
    changes["new_contacts"] = pct_change(len(current_new_contacts), len(previous_new_contacts))

    return {
        "period": {
            "days": days,
            "start": start.isoformat(),
            "end": end.isoformat(),
            "previous_start": previous_start.isoformat(),
            "previous_end": start.isoformat(),
        },
        "summary": summary,
        "previous_summary": previous_summary,
        "changes": changes,
        "daily": list(daily.values()),
        "campaign_comparison": campaign_comparison[:50],
        "top_subjects": top_subjects,
        "top_links": top_links,
        "source_breakdown": source_breakdown,
        "automation_performance": automation_performance[:20],
        "event_performance": event_performance[:20],
        "alerts": alerts,
        "thresholds": {
            "delivery_rate_min": 95,
            "bounce_rate_max": 2,
            "complaint_rate_max": 0.1,
            "unsubscribe_rate_max": 1,
            "queue_stale_minutes": 30,
        },
    }
