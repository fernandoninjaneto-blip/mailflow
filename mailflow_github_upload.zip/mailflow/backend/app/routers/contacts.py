from __future__ import annotations

import csv
import io
import json
import math
import re
import unicodedata
from collections import Counter
from datetime import datetime
from typing import Any

from email_validator import EmailNotValidError, validate_email
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Response, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Contact, ContactEvent, CustomFieldDefinition, User
from ..unsubscribe import find_suppression, status_for_reason
from ..schemas import (
    BulkContactActionIn,
    BulkContactActionOut,
    ContactCreate,
    ContactDetailOut,
    ContactListOut,
    ContactOut,
    ContactStatsOut,
    ContactUpdate,
    CustomFieldCreate,
    CustomFieldOut,
    ImportSummaryOut,
    TagSummaryOut,
)
from ..security import get_current_user

router = APIRouter(prefix="/api/contacts", tags=["contacts"])


def normalize_email(value: str) -> str:
    return value.strip().lower()


def normalize_key(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    normalized = re.sub(r"[^a-zA-Z0-9_]+", "_", normalized.strip().lower()).strip("_")
    return normalized[:80]


def add_event(db: Session, contact: Contact, event_type: str, description: str, data: dict[str, Any] | None = None) -> None:
    db.add(ContactEvent(
        workspace_id=contact.workspace_id,
        contact_id=contact.id,
        event_type=event_type,
        description=description,
        event_data=data or {},
    ))


def scoped_contact(db: Session, workspace_id: str, contact_id: str) -> Contact:
    contact = db.get(Contact, contact_id)
    if not contact or contact.workspace_id != workspace_id:
        raise HTTPException(status_code=404, detail="Contato não encontrado.")
    return contact


def base_filtered_contacts(
    db: Session,
    workspace_id: str,
    q: str | None = None,
    status_filter: str | None = None,
    source: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
) -> list[Contact]:
    stmt = select(Contact).where(Contact.workspace_id == workspace_id)
    if q:
        term = f"%{q.lower().strip()}%"
        stmt = stmt.where(or_(
            func.lower(Contact.name).like(term),
            func.lower(Contact.last_name).like(term),
            func.lower(Contact.email).like(term),
            func.lower(Contact.source).like(term),
            func.lower(func.coalesce(Contact.phone, "")).like(term),
        ))
    if status_filter:
        stmt = stmt.where(Contact.status == status_filter)
    if source:
        stmt = stmt.where(Contact.source == source)
    if created_from:
        stmt = stmt.where(Contact.created_at >= created_from)
    if created_to:
        stmt = stmt.where(Contact.created_at <= created_to)
    return list(db.scalars(stmt.order_by(Contact.created_at.desc())))


def post_filter_contacts(
    contacts: list[Contact],
    tag: str | None = None,
    custom_key: str | None = None,
    custom_value: str | None = None,
) -> list[Contact]:
    result = contacts
    if tag:
        tag_lower = tag.strip().lower()
        result = [c for c in result if any(str(t).lower() == tag_lower for t in (c.tags or []))]
    if custom_key:
        key = custom_key.strip()
        if custom_value is None or custom_value == "":
            result = [c for c in result if key in (c.custom_fields or {})]
        else:
            val = custom_value.strip().lower()
            result = [c for c in result if val in str((c.custom_fields or {}).get(key, "")).lower()]
    return result


def filtered_contacts(
    db: Session,
    workspace_id: str,
    q: str | None = None,
    status_filter: str | None = None,
    source: str | None = None,
    tag: str | None = None,
    custom_key: str | None = None,
    custom_value: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
) -> list[Contact]:
    candidates = base_filtered_contacts(db, workspace_id, q, status_filter, source, created_from, created_to)
    return post_filter_contacts(candidates, tag, custom_key, custom_value)


@router.get("", response_model=list[ContactOut])
def list_contacts(
    q: str | None = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Endpoint legado mantido para compatibilidade com o restante do MVP.
    # O módulo visual do Passo 4 usa /search, que é paginado.
    return filtered_contacts(db, user.workspace_id, q=q)[:10000]


@router.get("/search", response_model=ContactListOut)
def search_contacts(
    q: str | None = None,
    contact_status: str | None = Query(default=None, alias="status"),
    source: str | None = None,
    tag: str | None = None,
    custom_key: str | None = None,
    custom_value: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=25, ge=10, le=200),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    items = filtered_contacts(
        db, user.workspace_id, q=q, status_filter=contact_status, source=source, tag=tag,
        custom_key=custom_key, custom_value=custom_value, created_from=created_from, created_to=created_to,
    )
    total = len(items)
    pages = max(1, math.ceil(total / page_size))
    page = min(page, pages)
    start = (page - 1) * page_size
    return ContactListOut(items=items[start:start + page_size], total=total, page=page, page_size=page_size, pages=pages)


@router.get("/stats", response_model=ContactStatsOut)
def contact_stats(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    contacts = list(db.scalars(select(Contact).where(Contact.workspace_id == user.workspace_id)))
    statuses = Counter(c.status for c in contacts)
    return ContactStatsOut(
        total=len(contacts), active=statuses["active"], unsubscribed=statuses["unsubscribed"],
        bounce=statuses["bounce"], blocked=statuses["blocked"], invalid=statuses["invalid"],
        tagged=sum(1 for c in contacts if c.tags),
    )


@router.get("/tags", response_model=list[TagSummaryOut])
def list_tags(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    contacts = db.scalars(select(Contact).where(Contact.workspace_id == user.workspace_id))
    counts: Counter[str] = Counter()
    names: dict[str, str] = {}
    for contact in contacts:
        for tag in contact.tags or []:
            clean = str(tag).strip()
            if not clean:
                continue
            key = clean.lower()
            names.setdefault(key, clean)
            counts[key] += 1
    return [TagSummaryOut(name=names[key], count=count) for key, count in sorted(counts.items(), key=lambda x: (-x[1], names[x[0]].lower()))]


@router.get("/sources", response_model=list[str])
def list_sources(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    values = db.scalars(select(Contact.source).where(Contact.workspace_id == user.workspace_id).distinct().order_by(Contact.source))
    return [v for v in values if v]


@router.get("/custom-fields", response_model=list[CustomFieldOut])
def list_custom_fields(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return list(db.scalars(select(CustomFieldDefinition).where(CustomFieldDefinition.workspace_id == user.workspace_id).order_by(CustomFieldDefinition.created_at)))


@router.post("/custom-fields", response_model=CustomFieldOut, status_code=status.HTTP_201_CREATED)
def create_custom_field(payload: CustomFieldCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    key = normalize_key(payload.key or payload.label)
    if not key:
        raise HTTPException(status_code=422, detail="Não foi possível gerar uma chave válida para o campo.")
    item = CustomFieldDefinition(workspace_id=user.workspace_id, key=key, label=payload.label.strip(), field_type=payload.field_type)
    db.add(item)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Já existe um campo personalizado com esta chave.")
    db.refresh(item)
    return item


@router.delete("/custom-fields/{field_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_custom_field(field_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = db.get(CustomFieldDefinition, field_id)
    if not item or item.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Campo personalizado não encontrado.")
    # Remove o valor do campo dos contatos para evitar dados órfãos.
    contacts = db.scalars(select(Contact).where(Contact.workspace_id == user.workspace_id))
    for contact in contacts:
        data = dict(contact.custom_fields or {})
        if item.key in data:
            data.pop(item.key, None)
            contact.custom_fields = data
            add_event(db, contact, "custom_field_removed", f"Campo personalizado '{item.label}' removido da conta.", {"key": item.key})
    db.delete(item)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/bulk", response_model=BulkContactActionOut)
def bulk_contacts(payload: BulkContactActionIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ids = list(dict.fromkeys(payload.ids))
    contacts = list(db.scalars(select(Contact).where(Contact.workspace_id == user.workspace_id, Contact.id.in_(ids))))
    if not contacts:
        raise HTTPException(status_code=404, detail="Nenhum contato válido foi selecionado.")

    if payload.action == "delete":
        for contact in contacts:
            db.delete(contact)
        db.commit()
        return BulkContactActionOut(affected=len(contacts), action=payload.action)

    if payload.action in {"add_tags", "remove_tags"} and not payload.tags:
        raise HTTPException(status_code=422, detail="Informe pelo menos uma tag.")
    if payload.action == "set_status" and not payload.status:
        raise HTTPException(status_code=422, detail="Informe o novo status.")

    requested = [t.strip()[:80] for t in payload.tags if t.strip()]
    for contact in contacts:
        current = list(contact.tags or [])
        if payload.action == "add_tags":
            existing = {t.lower() for t in current}
            added = [t for t in requested if t.lower() not in existing]
            contact.tags = current + added
            if added:
                add_event(db, contact, "tags_added", f"Tags adicionadas: {', '.join(added)}.", {"tags": added})
        elif payload.action == "remove_tags":
            remove = {t.lower() for t in requested}
            removed = [t for t in current if t.lower() in remove]
            contact.tags = [t for t in current if t.lower() not in remove]
            if removed:
                add_event(db, contact, "tags_removed", f"Tags removidas: {', '.join(removed)}.", {"tags": removed})
        elif payload.action == "set_status":
            old = contact.status
            contact.status = payload.status
            if old != payload.status:
                add_event(db, contact, "status_changed", f"Status alterado de {old} para {payload.status}.", {"from": old, "to": payload.status})
    db.commit()
    return BulkContactActionOut(affected=len(contacts), action=payload.action)


@router.post("/import", response_model=ImportSummaryOut)
async def import_contacts(
    file: UploadFile = File(...),
    mapping: str = Form(...),
    duplicate_strategy: str = Form("skip"),
    default_tags: str = Form("[]"),
    default_source: str = Form("Importação CSV"),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if duplicate_strategy not in {"skip", "update"}:
        raise HTTPException(status_code=422, detail="Estratégia de duplicidade inválida.")
    if not file.filename or not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=422, detail="Envie um arquivo CSV.")

    try:
        field_map = json.loads(mapping)
        import_tags = json.loads(default_tags)
    except json.JSONDecodeError:
        raise HTTPException(status_code=422, detail="Mapeamento ou tags inválidos.")
    if not isinstance(field_map, dict) or not field_map.get("email"):
        raise HTTPException(status_code=422, detail="O campo E-mail é obrigatório no mapeamento.")
    if not isinstance(import_tags, list):
        raise HTTPException(status_code=422, detail="Tags padrão inválidas.")

    raw = await file.read()
    if len(raw) > 20 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="O CSV excede o limite de 20 MB do MVP.")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")

    sample = text[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
        dialect.delimiter = ";" if sample.count(";") > sample.count(",") else ","
    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    if not reader.fieldnames:
        raise HTTPException(status_code=422, detail="CSV sem cabeçalho.")

    rows_found = valid = invalid = duplicates_in_file = duplicates_existing = created = updated = skipped = 0
    errors: list[str] = []
    seen_file: set[str] = set()
    existing = {c.email.lower(): c for c in db.scalars(select(Contact).where(Contact.workspace_id == user.workspace_id))}

    custom_defs = {f.key for f in db.scalars(select(CustomFieldDefinition).where(CustomFieldDefinition.workspace_id == user.workspace_id))}
    import_tags_clean = [str(t).strip()[:80] for t in import_tags if str(t).strip()]

    def value(row: dict[str, Any], target: str) -> str:
        source_header = field_map.get(target)
        return str(row.get(source_header, "") or "").strip() if source_header else ""

    for line_no, row in enumerate(reader, start=2):
        rows_found += 1
        raw_email = value(row, "email")
        try:
            normalized = validate_email(raw_email, check_deliverability=False).normalized.lower()
        except EmailNotValidError:
            invalid += 1
            skipped += 1
            if len(errors) < 20:
                errors.append(f"Linha {line_no}: e-mail inválido '{raw_email}'.")
            continue

        if normalized in seen_file:
            duplicates_in_file += 1
            skipped += 1
            continue
        seen_file.add(normalized)
        valid += 1

        tags = import_tags_clean.copy()
        row_tags = value(row, "tags")
        if row_tags:
            for tag in re.split(r"[|,;]", row_tags):
                clean = tag.strip()[:80]
                if clean and clean.lower() not in {x.lower() for x in tags}:
                    tags.append(clean)

        custom: dict[str, Any] = {}
        for target in field_map:
            if target.startswith("custom:"):
                key = target.split(":", 1)[1]
                if key in custom_defs:
                    v = value(row, target)
                    if v != "":
                        custom[key] = v

        payload = {
            "name": value(row, "name"),
            "last_name": value(row, "last_name"),
            "email": normalized,
            "phone": value(row, "phone") or None,
            "tags": tags,
            "custom_fields": custom,
            "source": value(row, "source") or default_source.strip() or "Importação CSV",
            "status": "active",
        }
        suppression = find_suppression(db, user.workspace_id, normalized)
        if suppression:
            payload["status"] = status_for_reason(suppression.reason)

        current = existing.get(normalized)
        if current:
            duplicates_existing += 1
            if duplicate_strategy == "skip":
                skipped += 1
                continue
            old_tags = list(current.tags or [])
            merged_tags = old_tags.copy()
            existing_tag_names = {t.lower() for t in merged_tags}
            for tag in tags:
                if tag.lower() not in existing_tag_names:
                    merged_tags.append(tag)
                    existing_tag_names.add(tag.lower())
            current.name = payload["name"] or current.name
            current.last_name = payload["last_name"] or current.last_name
            current.phone = payload["phone"] or current.phone
            current.source = payload["source"] or current.source
            current.tags = merged_tags
            current.custom_fields = {**(current.custom_fields or {}), **custom}
            add_event(db, current, "import_updated", f"Contato atualizado pela importação '{file.filename}'.", {"filename": file.filename})
            updated += 1
        else:
            contact = Contact(workspace_id=user.workspace_id, **payload)
            db.add(contact)
            db.flush()
            add_event(db, contact, "import_created", f"Contato criado pela importação '{file.filename}'.", {"filename": file.filename})
            existing[normalized] = contact
            created += 1

    db.commit()
    return ImportSummaryOut(
        rows_found=rows_found, valid=valid, invalid=invalid, duplicates_in_file=duplicates_in_file,
        duplicates_existing=duplicates_existing, created=created, updated=updated, skipped=skipped, errors=errors,
    )


@router.get("/export")
def export_contacts(
    q: str | None = None,
    contact_status: str | None = Query(default=None, alias="status"),
    source: str | None = None,
    tag: str | None = None,
    custom_key: str | None = None,
    custom_value: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
    ids: str | None = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    items = filtered_contacts(db, user.workspace_id, q=q, status_filter=contact_status, source=source, tag=tag, custom_key=custom_key, custom_value=custom_value, created_from=created_from, created_to=created_to)
    if ids:
        selected = {x.strip() for x in ids.split(",") if x.strip()}
        items = [c for c in items if c.id in selected]

    fields = list(db.scalars(select(CustomFieldDefinition).where(CustomFieldDefinition.workspace_id == user.workspace_id).order_by(CustomFieldDefinition.created_at)))
    output = io.StringIO()
    writer = csv.writer(output, delimiter=";")
    writer.writerow(["nome", "sobrenome", "email", "telefone", "tags", "origem", "status", "data_cadastro"] + [f.label for f in fields])
    for c in items:
        writer.writerow([
            c.name, c.last_name, c.email, c.phone or "", "|".join(c.tags or []), c.source, c.status,
            c.created_at.isoformat(), *[str((c.custom_fields or {}).get(f.key, "")) for f in fields],
        ])
    payload = "\ufeff" + output.getvalue()
    headers = {"Content-Disposition": 'attachment; filename="mailflow-contatos.csv"'}
    return StreamingResponse(iter([payload.encode("utf-8")]), media_type="text/csv; charset=utf-8", headers=headers)


@router.post("", response_model=ContactOut, status_code=status.HTTP_201_CREATED)
def create_contact(payload: ContactCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = payload.model_dump()
    data["email"] = normalize_email(str(payload.email))
    suppression = find_suppression(db, user.workspace_id, data["email"])
    if suppression:
        data["status"] = status_for_reason(suppression.reason)
    contact = Contact(workspace_id=user.workspace_id, **data)
    db.add(contact)
    try:
        db.flush()
        add_event(db, contact, "created", "Contato criado manualmente.", {"source": contact.source})
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Já existe um contato com este e-mail.")
    db.refresh(contact)
    return contact


@router.get("/{contact_id}", response_model=ContactDetailOut)
def get_contact(contact_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    contact = scoped_contact(db, user.workspace_id, contact_id)
    history = list(db.scalars(select(ContactEvent).where(
        ContactEvent.workspace_id == user.workspace_id,
        ContactEvent.contact_id == contact.id,
    ).order_by(ContactEvent.created_at.desc()).limit(100)))
    return ContactDetailOut(contact=contact, history=history)


@router.patch("/{contact_id}", response_model=ContactOut)
def update_contact(contact_id: str, payload: ContactUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    contact = scoped_contact(db, user.workspace_id, contact_id)
    changes = payload.model_dump(exclude_unset=True)
    if "email" in changes and changes["email"] is not None:
        changes["email"] = normalize_email(str(changes["email"]))
    effective_email = changes.get("email") or contact.email
    suppression = find_suppression(db, user.workspace_id, effective_email)
    if suppression and changes.get("status") == "active":
        raise HTTPException(status_code=409, detail="Este e-mail está na supressão global. Registre novo consentimento e libere a supressão pela área de Privacidade.")
    before = {key: getattr(contact, key) for key in changes}
    for key, value in changes.items():
        setattr(contact, key, value)
    changed_keys = [key for key in changes if before.get(key) != changes.get(key)]
    if "tags" in changed_keys:
        old_tags = list(before.get("tags") or [])
        new_tags = list(contact.tags or [])
        old_norm = {str(x).casefold() for x in old_tags}
        new_norm = {str(x).casefold() for x in new_tags}
        added = [x for x in new_tags if str(x).casefold() not in old_norm]
        removed = [x for x in old_tags if str(x).casefold() not in new_norm]
        if added:
            add_event(db, contact, "tags_added", f"Tags adicionadas: {', '.join(added)}.", {"tags": added})
        if removed:
            add_event(db, contact, "tags_removed", f"Tags removidas: {', '.join(removed)}.", {"tags": removed})
    if "status" in changed_keys:
        add_event(db, contact, "status_changed", f"Status alterado de {before.get('status')} para {contact.status}.", {"from": before.get("status"), "to": contact.status})
    if changed_keys:
        add_event(db, contact, "updated", f"Contato atualizado: {', '.join(changed_keys)}.", {"fields": changed_keys})
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Já existe um contato com este e-mail.")
    db.refresh(contact)
    return contact


@router.delete("/{contact_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_contact(contact_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    contact = scoped_contact(db, user.workspace_id, contact_id)
    db.delete(contact)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
