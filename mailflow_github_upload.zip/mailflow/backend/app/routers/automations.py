from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..automation_engine import enroll_contact, process_automation_cycle, step_label, trigger_label
from ..database import get_db
from ..models import (
    Automation,
    AutomationRun,
    Campaign,
    Contact,
    ContactList,
    SenderIdentity,
    Template,
    User,
)
from ..schemas import (
    AutomationCreate,
    AutomationEnrollIn,
    AutomationOut,
    AutomationProcessOut,
    AutomationRunOut,
    AutomationUpdate,
)
from ..security import get_current_user, require_admin

router = APIRouter(prefix="/api/automations", tags=["automations"])


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _get_automation(db: Session, workspace_id: str, automation_id: str) -> Automation:
    item = db.get(Automation, automation_id)
    if not item or item.workspace_id != workspace_id:
        raise HTTPException(status_code=404, detail="Automação não encontrada.")
    return item


def _validate_sender(db: Session, workspace_id: str, sender_id: str | None) -> None:
    if not sender_id:
        return
    sender = db.get(SenderIdentity, sender_id)
    if not sender or sender.workspace_id != workspace_id or not sender.active:
        raise HTTPException(status_code=422, detail="Remetente inválido para esta automação.")


def _validate_trigger(db: Session, workspace_id: str, trigger_type: str, config: dict[str, Any]) -> None:
    if trigger_type == "tag_added" and not str(config.get("tag") or "").strip():
        raise HTTPException(status_code=422, detail="Informe a tag que dispara a automação.")
    if trigger_type == "list_joined":
        list_id = str(config.get("list_id") or "").strip()
        item = db.get(ContactList, list_id) if list_id else None
        if not item or item.workspace_id != workspace_id:
            raise HTTPException(status_code=422, detail="Selecione uma lista válida para o gatilho.")
    if trigger_type == "email_clicked":
        campaign_id = str(config.get("campaign_id") or "").strip()
        if campaign_id:
            campaign = db.get(Campaign, campaign_id)
            if not campaign or campaign.workspace_id != workspace_id:
                raise HTTPException(status_code=422, detail="A campanha do gatilho não pertence a este workspace.")
    if trigger_type == "status_changed":
        allowed = {"active", "unsubscribed", "bounce", "blocked", "invalid"}
        target = str(config.get("to") or "").strip()
        if target and target not in allowed:
            raise HTTPException(status_code=422, detail="Status de gatilho inválido.")


def _validate_steps(db: Session, workspace_id: str, steps: list[dict[str, Any]]) -> None:
    for index, step in enumerate(steps):
        if step.get("type") == "send_email":
            template = db.get(Template, step.get("template_id"))
            if not template or template.workspace_id != workspace_id:
                raise HTTPException(status_code=422, detail=f"Template inválido na etapa {index + 1}.")


def _stats(db: Session, automation_id: str) -> dict[str, int]:
    rows = db.execute(select(AutomationRun.status, func.count(AutomationRun.id)).where(
        AutomationRun.automation_id == automation_id
    ).group_by(AutomationRun.status)).all()
    counts = {status: int(count) for status, count in rows}
    return {
        "run_count": sum(counts.values()),
        "running_count": counts.get("running", 0) + counts.get("waiting", 0),
        "completed_count": counts.get("completed", 0),
        "failed_count": counts.get("failed", 0),
    }


def _out(db: Session, item: Automation) -> AutomationOut:
    return AutomationOut(
        id=item.id,
        name=item.name,
        trigger_type=item.trigger_type,
        trigger_config=item.trigger_config or {},
        steps=item.steps_json or [],
        reentry_policy=item.reentry_policy,
        sender_id=item.sender_id,
        active=item.active,
        created_at=item.created_at,
        updated_at=item.updated_at,
        **_stats(db, item.id),
    )


@router.get("", response_model=list[AutomationOut])
def list_automations(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    items = list(db.scalars(select(Automation).where(
        Automation.workspace_id == user.workspace_id
    ).order_by(Automation.updated_at.desc(), Automation.created_at.desc())))
    return [_out(db, item) for item in items]


@router.post("", response_model=AutomationOut, status_code=status.HTTP_201_CREATED)
def create_automation(payload: AutomationCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    steps = [step.model_dump() for step in payload.steps]
    _validate_sender(db, user.workspace_id, payload.sender_id)
    _validate_trigger(db, user.workspace_id, payload.trigger_type, payload.trigger_config)
    _validate_steps(db, user.workspace_id, steps)
    item = Automation(
        workspace_id=user.workspace_id,
        name=payload.name.strip(),
        trigger=trigger_label(payload.trigger_type, payload.trigger_config),
        steps=[step_label(x) for x in steps],
        trigger_type=payload.trigger_type,
        trigger_config=payload.trigger_config,
        steps_json=steps,
        reentry_policy=payload.reentry_policy,
        sender_id=payload.sender_id,
        active=payload.active,
        activated_at=utcnow() if payload.active else None,
    )
    db.add(item)
    db.commit(); db.refresh(item)
    return _out(db, item)


@router.get("/{automation_id}", response_model=AutomationOut)
def get_automation(automation_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return _out(db, _get_automation(db, user.workspace_id, automation_id))


@router.patch("/{automation_id}", response_model=AutomationOut)
def update_automation(automation_id: str, payload: AutomationUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _get_automation(db, user.workspace_id, automation_id)
    data = payload.model_dump(exclude_unset=True)
    next_trigger = data.get("trigger_type", item.trigger_type)
    next_config = data.get("trigger_config", item.trigger_config or {})
    next_sender = data.get("sender_id", item.sender_id)
    next_steps = [x.model_dump() for x in payload.steps] if payload.steps is not None else list(item.steps_json or [])
    _validate_sender(db, user.workspace_id, next_sender)
    _validate_trigger(db, user.workspace_id, next_trigger, next_config)
    _validate_steps(db, user.workspace_id, next_steps)

    if "name" in data:
        item.name = data["name"].strip()
    if "trigger_type" in data:
        item.trigger_type = data["trigger_type"]
    if "trigger_config" in data:
        item.trigger_config = data["trigger_config"]
    if payload.steps is not None:
        item.steps_json = next_steps
    if "reentry_policy" in data:
        item.reentry_policy = data["reentry_policy"]
    if "sender_id" in data:
        item.sender_id = data["sender_id"]
    item.trigger = trigger_label(item.trigger_type, item.trigger_config)
    item.steps = [step_label(x) for x in (item.steps_json or [])]
    db.commit(); db.refresh(item)
    return _out(db, item)


@router.delete("/{automation_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_automation(automation_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _get_automation(db, user.workspace_id, automation_id)
    active_runs = db.scalar(select(func.count(AutomationRun.id)).where(
        AutomationRun.automation_id == item.id,
        AutomationRun.status.in_(["running", "waiting"]),
    )) or 0
    if active_runs:
        raise HTTPException(status_code=409, detail="Pause a automação e cancele/conclua as execuções ativas antes de excluir.")
    db.delete(item); db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.patch("/{automation_id}/toggle", response_model=AutomationOut)
def toggle_automation(automation_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _get_automation(db, user.workspace_id, automation_id)
    item.active = not item.active
    if item.active:
        # Eventos ocorridos durante a pausa não são retroativamente inscritos.
        item.activated_at = utcnow()
    db.commit(); db.refresh(item)
    return _out(db, item)


@router.post("/{automation_id}/enroll", response_model=AutomationRunOut)
def manual_enroll(automation_id: str, payload: AutomationEnrollIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    automation = _get_automation(db, user.workspace_id, automation_id)
    contact = db.get(Contact, payload.contact_id)
    if not contact or contact.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Contato não encontrado.")
    run = enroll_contact(db, automation, contact, context={"manual": True})
    if not run:
        raise HTTPException(status_code=409, detail="Este contato já participou desta automação e a política de reentrada está como 'uma vez'.")
    db.commit(); db.refresh(run)
    return AutomationRunOut(
        id=run.id, automation_id=run.automation_id, contact_id=run.contact_id,
        contact_email=contact.email, status=run.status, current_step=run.current_step,
        total_steps=len((run.context_json or {}).get("steps_snapshot") or automation.steps_json or []),
        next_run_at=run.next_run_at, last_error=run.last_error, started_at=run.started_at,
        completed_at=run.completed_at,
    )


@router.get("/{automation_id}/runs", response_model=list[AutomationRunOut])
def automation_runs(automation_id: str, limit: int = 100, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    automation = _get_automation(db, user.workspace_id, automation_id)
    runs = list(db.scalars(select(AutomationRun).where(
        AutomationRun.automation_id == automation.id,
        AutomationRun.workspace_id == user.workspace_id,
    ).order_by(AutomationRun.started_at.desc()).limit(max(1, min(limit, 500)))))
    out = []
    for run in runs:
        contact = db.get(Contact, run.contact_id) if run.contact_id else None
        steps = (run.context_json or {}).get("steps_snapshot") or automation.steps_json or []
        out.append(AutomationRunOut(
            id=run.id, automation_id=run.automation_id, contact_id=run.contact_id,
            contact_email=contact.email if contact else "", status=run.status,
            current_step=run.current_step, total_steps=len(steps), next_run_at=run.next_run_at,
            last_error=run.last_error, started_at=run.started_at, completed_at=run.completed_at,
        ))
    return out


@router.post("/process-once", response_model=AutomationProcessOut)
def process_once(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    # O motor é global no worker; este endpoint existe para desenvolvimento e testes.
    result = process_automation_cycle(db, trigger_limit=500, run_limit=250)
    return AutomationProcessOut(**result)
