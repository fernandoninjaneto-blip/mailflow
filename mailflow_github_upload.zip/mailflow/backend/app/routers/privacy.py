from __future__ import annotations

from datetime import datetime, timezone
import json

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.responses import HTMLResponse, JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..delivery_service import refresh_campaign_metrics
from ..models import (
    AutomationRun, ConsentEvent, Contact, ContactEvent, ContactListMembership, EmailDelivery,
    EmailEngagementEvent, SuppressionEntry, User, WebhookEvent,
)
from ..schemas import ConsentRecordIn, PrivacyDeleteIn, SuppressionCreateIn, SuppressionOut, SuppressionReleaseIn
from ..security import get_current_user, require_admin
from ..unsubscribe import (
    add_suppression, find_suppression, mask_email, parse_unsubscribe_token,
    record_consent, release_suppression,
)

router = APIRouter(tags=['privacy'])


def utcnow():
    return datetime.now(timezone.utc)


def _delivery_from_token(db: Session, token: str) -> EmailDelivery:
    delivery_id = parse_unsubscribe_token(token)
    delivery = db.get(EmailDelivery, delivery_id) if delivery_id else None
    if not delivery or delivery.is_test:
        raise HTTPException(status_code=404, detail='Link de descadastro inválido.')
    return delivery


def _unsubscribe_delivery(db: Session, delivery: EmailDelivery, source: str) -> None:
    contact = db.get(Contact, delivery.contact_id) if delivery.contact_id else None
    add_suppression(
        db, delivery.workspace_id, delivery.recipient_email,
        reason='unsubscribe', source=source, contact_id=delivery.contact_id,
        campaign_id=delivery.campaign_id,
    )
    record_consent(
        db, delivery.workspace_id, delivery.recipient_email,
        contact_id=delivery.contact_id, action='revoked', legal_basis='withdrawal',
        source=source, evidence={'delivery_id': delivery.id, 'campaign_id': delivery.campaign_id},
    )
    delivery.unsubscribed_at = delivery.unsubscribed_at or utcnow()
    delivery.last_event_type = 'mailflow.unsubscribed'
    if contact:
        contact.status = 'unsubscribed'
    refresh_campaign_metrics(db, delivery.campaign_id)


@router.get('/api/unsubscribe/{token}', response_class=HTMLResponse)
def unsubscribe_page(token: str, db: Session = Depends(get_db)):
    delivery = _delivery_from_token(db, token)
    masked = mask_email(delivery.recipient_email)
    return HTMLResponse(f'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cancelar inscrição</title><style>body{{font-family:system-ui,-apple-system,sans-serif;background:#f6f7fb;color:#111827;margin:0;padding:32px}}main{{max-width:560px;margin:8vh auto;background:white;padding:32px;border-radius:18px;box-shadow:0 18px 60px #11182712}}button{{background:#111827;color:#fff;border:0;border-radius:10px;padding:12px 18px;font-weight:700;cursor:pointer}}p{{line-height:1.6;color:#4b5563}}</style></head><body><main><h1>Cancelar inscrição</h1><p>Você está cancelando os e-mails de marketing enviados para <strong>{masked}</strong>.</p><form method="post"><input type="hidden" name="List-Unsubscribe" value="One-Click"><button type="submit">Confirmar cancelamento</button></form></main></body></html>''')


@router.post('/api/unsubscribe/{token}')
async def unsubscribe_one_click(token: str, request: Request, db: Session = Depends(get_db)):
    delivery = _delivery_from_token(db, token)
    _unsubscribe_delivery(db, delivery, 'one_click' if request.headers.get('user-agent') else 'unsubscribe')
    db.commit()
    accept = request.headers.get('accept', '')
    if 'text/html' in accept:
        return HTMLResponse('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><body style="font-family:system-ui;padding:40px"><h1>Inscrição cancelada</h1><p>Você não receberá novos e-mails de marketing desta lista.</p></body></html>')
    return Response(status_code=200)


@router.get('/api/suppressions', response_model=list[SuppressionOut])
def list_suppressions(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return list(db.scalars(select(SuppressionEntry).where(
        SuppressionEntry.workspace_id == user.workspace_id,
        SuppressionEntry.active.is_(True),
    ).order_by(SuppressionEntry.created_at.desc())))


@router.post('/api/suppressions', response_model=SuppressionOut, status_code=201)
def create_suppression(payload: SuppressionCreateIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = add_suppression(db, admin.workspace_id, str(payload.email), reason=payload.reason, source='manual_admin')
    db.commit(); db.refresh(item)
    return item


@router.post('/api/suppressions/{suppression_id}/release', response_model=SuppressionOut)
def release_suppression_endpoint(suppression_id: str, payload: SuppressionReleaseIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = db.get(SuppressionEntry, suppression_id)
    if not item or item.workspace_id != admin.workspace_id or not item.active:
        raise HTTPException(status_code=404, detail='Supressão ativa não encontrada.')
    if not item.contact_id:
        raise HTTPException(status_code=409, detail='Para remover esta supressão, recrie/vincule o contato e registre novo consentimento verificável.')
    contact = db.get(Contact, item.contact_id)
    if not contact:
        raise HTTPException(status_code=409, detail='Contato vinculado não existe mais.')
    record_consent(db, admin.workspace_id, contact.email, contact_id=contact.id, action='granted', legal_basis=payload.legal_basis, source=payload.source, notice_version=payload.notice_version, evidence={'note': payload.note})
    release_suppression(db, item, source=payload.source)
    db.commit(); db.refresh(item)
    return item


@router.get('/api/privacy/consents')
def list_consents(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    items = list(db.scalars(select(ConsentEvent).where(ConsentEvent.workspace_id == user.workspace_id).order_by(ConsentEvent.created_at.desc()).limit(500)))
    return [{'id':x.id,'contact_id':x.contact_id,'email_hint':x.email_hint,'action':x.action,'legal_basis':x.legal_basis,'source':x.source,'purpose':x.purpose,'notice_version':x.notice_version,'evidence':x.evidence,'created_at':x.created_at} for x in items]


@router.post('/api/privacy/consents')
def create_consent(payload: ConsentRecordIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    contact = db.get(Contact, payload.contact_id)
    if not contact or contact.workspace_id != admin.workspace_id:
        raise HTTPException(status_code=404, detail='Contato não encontrado.')
    event = record_consent(db, admin.workspace_id, contact.email, contact_id=contact.id, action=payload.action, legal_basis=payload.legal_basis, source=payload.source, notice_version=payload.notice_version, evidence=payload.evidence)
    if payload.action == 'revoked':
        add_suppression(db, admin.workspace_id, contact.email, reason='unsubscribe', source=payload.source, contact_id=contact.id)
    elif payload.action == 'granted' and payload.reactivate:
        item = find_suppression(db, admin.workspace_id, contact.email)
        if item:
            release_suppression(db, item, source=payload.source)
        contact.status = 'active'
    db.add(ContactEvent(workspace_id=admin.workspace_id, contact_id=contact.id, event_type='consent_recorded', description=f'Consentimento {payload.action} registrado.', event_data={'legal_basis':payload.legal_basis,'source':payload.source}))
    db.commit()
    return {'id':event.id,'action':event.action,'created_at':event.created_at}


@router.get('/api/privacy/contacts/{contact_id}/export')
def privacy_export(contact_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    contact = db.get(Contact, contact_id)
    if not contact or contact.workspace_id != admin.workspace_id:
        raise HTTPException(status_code=404, detail='Contato não encontrado.')
    history = list(db.scalars(select(ContactEvent).where(ContactEvent.contact_id == contact.id).order_by(ContactEvent.created_at.asc())))
    consents = list(db.scalars(select(ConsentEvent).where(ConsentEvent.contact_id == contact.id).order_by(ConsentEvent.created_at.asc())))
    deliveries = list(db.scalars(select(EmailDelivery).where(EmailDelivery.contact_id == contact.id).order_by(EmailDelivery.created_at.asc())))
    lists = list(db.scalars(select(ContactListMembership.list_id).where(ContactListMembership.contact_id == contact.id)))
    payload = {
        'generated_at': utcnow().isoformat(),
        'contact': {'id':contact.id,'name':contact.name,'last_name':contact.last_name,'email':contact.email,'phone':contact.phone,'tags':contact.tags,'custom_fields':contact.custom_fields,'status':contact.status,'source':contact.source,'created_at':contact.created_at.isoformat()},
        'list_ids': lists,
        'history': [{'type':x.event_type,'description':x.description,'data':x.event_data,'created_at':x.created_at.isoformat()} for x in history],
        'consents': [{'action':x.action,'legal_basis':x.legal_basis,'source':x.source,'purpose':x.purpose,'notice_version':x.notice_version,'evidence':x.evidence,'created_at':x.created_at.isoformat()} for x in consents],
        'deliveries': [{'campaign_id':x.campaign_id,'status':x.status,'sent_at':x.sent_at.isoformat() if x.sent_at else None,'delivered_at':x.delivered_at.isoformat() if x.delivered_at else None,'opened_at':x.opened_at.isoformat() if x.opened_at else None,'clicked_at':x.clicked_at.isoformat() if x.clicked_at else None,'unsubscribed_at':x.unsubscribed_at.isoformat() if x.unsubscribed_at else None} for x in deliveries],
    }
    return JSONResponse(payload, headers={'Content-Disposition':f'attachment; filename="mailflow-privacy-{contact.id}.json"'})


@router.delete('/api/privacy/contacts/{contact_id}')
def privacy_delete(contact_id: str, payload: PrivacyDeleteIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    if payload.confirmation != 'EXCLUIR':
        raise HTTPException(status_code=422, detail='Digite EXCLUIR para confirmar.')
    contact = db.get(Contact, contact_id)
    if not contact or contact.workspace_id != admin.workspace_id:
        raise HTTPException(status_code=404, detail='Contato não encontrado.')
    original_email = contact.email
    item = add_suppression(db, admin.workspace_id, original_email, reason='privacy_delete', source='privacy_delete', contact_id=None)
    item.contact_id = None
    # Remove/anonymize personal data retained in operational history.
    deliveries = list(db.scalars(select(EmailDelivery).where(EmailDelivery.contact_id == contact.id)))
    message_ids = {d.provider_message_id for d in deliveries if d.provider_message_id}
    for d in deliveries:
        d.recipient_email = f'deleted+{d.id[:12]}@invalid.local'
        d.recipient_name = ''
        d.contact_id = None
    events = list(db.scalars(select(EmailEngagementEvent).where(EmailEngagementEvent.contact_id == contact.id)))
    for e in events:
        e.contact_id = None; e.ip_address=''; e.user_agent=''; e.event_data={}
    consents = list(db.scalars(select(ConsentEvent).where(ConsentEvent.contact_id == contact.id)))
    for c in consents:
        c.contact_id = None
    automation_runs = list(db.scalars(select(AutomationRun).where(AutomationRun.contact_id == contact.id)))
    for run in automation_runs:
        run.contact_id = None
        if run.status in {'running', 'waiting'}:
            run.status = 'cancelled'
            run.next_run_at = None
            run.completed_at = utcnow()
            run.last_error = 'Execução cancelada após exclusão dos dados do contato.'
    if message_ids:
        webhooks = list(db.scalars(select(WebhookEvent).where(WebhookEvent.provider_message_id.in_(message_ids))))
        for w in webhooks:
            w.payload = {'redacted': True, 'event_type': w.event_type}
    db.delete(contact)
    db.commit()
    return {'deleted':True,'suppression_preserved':True,'email_hint':item.email_hint,'deliveries_anonymized':len(deliveries)}
