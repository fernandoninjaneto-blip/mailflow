from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User, UserSession, Workspace
from ..schemas import UserCreate, UserOut, UserUpdate, WorkspaceOut, WorkspaceUpdate
from ..security import get_current_user, hash_password, require_admin

router = APIRouter(prefix="/api", tags=["account"])


@router.get("/workspace", response_model=WorkspaceOut)
def get_workspace(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.get(Workspace, user.workspace_id)


@router.patch("/workspace", response_model=WorkspaceOut)
def update_workspace(payload: WorkspaceUpdate, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    workspace = db.get(Workspace, admin.workspace_id)
    workspace.name = payload.name.strip()
    db.commit()
    db.refresh(workspace)
    return workspace


@router.get("/users", response_model=list[UserOut])
def list_users(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return list(db.scalars(select(User).where(User.workspace_id == user.workspace_id).order_by(User.created_at.asc())))


@router.post("/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(payload: UserCreate, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    email = str(payload.email).strip().lower()
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Já existe um usuário com este e-mail.")
    user = User(
        workspace_id=admin.workspace_id,
        name=payload.name.strip(),
        email=email,
        password_hash=hash_password(payload.password),
        role=payload.role,
        active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.patch("/users/{user_id}", response_model=UserOut)
def update_user(user_id: str, payload: UserUpdate, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user or user.workspace_id != admin.workspace_id:
        raise HTTPException(status_code=404, detail="Usuário não encontrado.")

    changes = payload.model_dump(exclude_unset=True)
    if user.id == admin.id and changes.get("active") is False:
        raise HTTPException(status_code=400, detail="Você não pode desativar sua própria conta.")
    if user.id == admin.id and changes.get("role") == "user":
        admins = db.scalar(select(func.count(User.id)).where(User.workspace_id == admin.workspace_id, User.role == "admin", User.active.is_(True))) or 0
        if admins <= 1:
            raise HTTPException(status_code=400, detail="A conta precisa manter pelo menos um administrador ativo.")

    for key, value in changes.items():
        if key == "name" and value is not None:
            value = value.strip()
        setattr(user, key, value)
    if changes.get("active") is False:
        for session in db.scalars(select(UserSession).where(UserSession.user_id == user.id)):
            db.delete(session)
    db.commit()
    db.refresh(user)
    return user


@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user or user.workspace_id != admin.workspace_id:
        raise HTTPException(status_code=404, detail="Usuário não encontrado.")
    if user.id == admin.id:
        raise HTTPException(status_code=400, detail="Você não pode excluir sua própria conta.")
    db.delete(user)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
