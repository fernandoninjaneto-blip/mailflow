from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..email_content import normalize_email_fields, render_with_context
from ..models import Campaign, Contact, User
from ..schemas import EmailPreviewIn, EmailPreviewOut
from ..security import get_current_user

router = APIRouter(prefix="/api/email", tags=["email-editor"])


def _sample_context(payload: dict, user: User) -> dict:
    sample = payload or {}
    return {
        "name": sample.get("name", "Fernando"),
        "last_name": sample.get("last_name", "Neto"),
        "email": sample.get("email", "fernando@exemplo.com"),
        "workspace_name": sample.get("workspace_name", user.workspace.name if user.workspace else "Sua Empresa"),
        "custom_fields": sample.get("custom_fields", {"cidade": "Belém", "curso": "Psicanálise"}),
    }


@router.post("/preview", response_model=EmailPreviewOut)
def preview_email(payload: EmailPreviewIn, user: User = Depends(get_current_user)):
    data = normalize_email_fields(payload.model_dump())
    context = _sample_context(payload.sample, user)
    rendered = render_with_context(payload.subject, payload.preheader, data["html_body"], context)
    return EmailPreviewOut(**rendered, plain_text=data["body"])


@router.get("/campaigns/{campaign_id}/render", response_model=EmailPreviewOut)
def render_campaign(campaign_id: str, contact_id: str | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    campaign = db.get(Campaign, campaign_id)
    if not campaign or campaign.workspace_id != user.workspace_id:
        raise HTTPException(status_code=404, detail="Campanha não encontrada.")

    context = {
        "name": "Fernando",
        "last_name": "Neto",
        "email": "fernando@exemplo.com",
        "workspace_name": user.workspace.name if user.workspace else "Sua Empresa",
        "custom_fields": {},
    }
    if contact_id:
        contact = db.get(Contact, contact_id)
        if not contact or contact.workspace_id != user.workspace_id:
            raise HTTPException(status_code=404, detail="Contato não encontrado.")
        context.update({
            "name": contact.name,
            "last_name": contact.last_name,
            "email": contact.email,
            "custom_fields": contact.custom_fields or {},
        })

    rendered = render_with_context(campaign.subject, campaign.preheader, campaign.html_body, context)
    return EmailPreviewOut(**rendered, plain_text=campaign.body)
