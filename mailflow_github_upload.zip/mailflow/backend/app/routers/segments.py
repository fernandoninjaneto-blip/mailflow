from __future__ import annotations

from math import ceil

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import delete, func, or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Contact, ContactEvent, ContactList, ContactListMembership, MarketingEvent, Segment, User
from ..schemas import (
    ContactListOut,
    ListMembersIn,
    ListMembersResult,
    SegmentCreate,
    SegmentOut,
    SegmentPreviewIn,
    SegmentPreviewOut,
    SegmentUpdate,
    StaticListCreate,
    StaticListOut,
    StaticListUpdate,
)
from ..security import get_current_user
from ..segmentation import filter_contacts

router = APIRouter(prefix="/api", tags=["lists-segments"])


def _get_list(db: Session, workspace_id: str, list_id: str) -> ContactList:
    item = db.get(ContactList, list_id)
    if not item or item.workspace_id != workspace_id:
        raise HTTPException(status_code=404, detail="Lista não encontrada.")
    return item


def _get_segment(db: Session, workspace_id: str, segment_id: str) -> Segment:
    item = db.get(Segment, segment_id)
    if not item or item.workspace_id != workspace_id:
        raise HTTPException(status_code=404, detail="Segmento não encontrado.")
    return item


def _list_counts(db: Session, workspace_id: str, list_id: str) -> tuple[int, int]:
    total = db.scalar(
        select(func.count(ContactListMembership.id)).where(
            ContactListMembership.workspace_id == workspace_id,
            ContactListMembership.list_id == list_id,
        )
    ) or 0
    active = db.scalar(
        select(func.count(ContactListMembership.id))
        .join(Contact, Contact.id == ContactListMembership.contact_id)
        .where(
            ContactListMembership.workspace_id == workspace_id,
            ContactListMembership.list_id == list_id,
            Contact.status == "active",
        )
    ) or 0
    return total, active


def _list_out(db: Session, item: ContactList) -> StaticListOut:
    total, active = _list_counts(db, item.workspace_id, item.id)
    return StaticListOut(
        id=item.id,
        name=item.name,
        description=item.description,
        member_count=total,
        active_member_count=active,
        created_at=item.created_at,
        updated_at=item.updated_at,
    )


def _segment_contacts(db: Session, workspace_id: str, rules: list[dict], match_mode: str) -> list[Contact]:
    contacts = list(db.scalars(select(Contact).where(Contact.workspace_id == workspace_id)))
    return filter_contacts(contacts, rules, match_mode)


def _segment_out(db: Session, item: Segment) -> SegmentOut:
    matches = _segment_contacts(db, item.workspace_id, item.rules or [], item.match_mode)
    return SegmentOut(
        id=item.id,
        name=item.name,
        description=item.description,
        match_mode=item.match_mode,
        rules=item.rules or [],
        matching_count=len(matches),
        active_count=sum(1 for c in matches if c.status == "active"),
        created_at=item.created_at,
        updated_at=item.updated_at,
    )


@router.get("/lists", response_model=list[StaticListOut])
def list_static_lists(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    items = db.scalars(
        select(ContactList)
        .where(ContactList.workspace_id == user.workspace_id)
        .order_by(ContactList.updated_at.desc())
    )
    return [_list_out(db, item) for item in items]


@router.post("/lists", response_model=StaticListOut, status_code=status.HTTP_201_CREATED)
def create_static_list(payload: StaticListCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = ContactList(
        workspace_id=user.workspace_id,
        name=payload.name.strip(),
        description=payload.description.strip(),
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return _list_out(db, item)


@router.patch("/lists/{list_id}", response_model=StaticListOut)
def update_static_list(list_id: str, payload: StaticListUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _get_list(db, user.workspace_id, list_id)
    data = payload.model_dump(exclude_unset=True)
    if "name" in data:
        data["name"] = data["name"].strip()
    if "description" in data and data["description"] is not None:
        data["description"] = data["description"].strip()
    for key, value in data.items():
        setattr(item, key, value)
    db.commit()
    db.refresh(item)
    return _list_out(db, item)


@router.delete("/lists/{list_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_static_list(list_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _get_list(db, user.workspace_id, list_id)
    event_use = db.scalar(select(func.count(MarketingEvent.id)).where(MarketingEvent.workspace_id == user.workspace_id, MarketingEvent.audience_type == "list", MarketingEvent.audience_id == list_id)) or 0
    if event_use:
        raise HTTPException(status_code=409, detail="Esta lista é público de um evento. Altere o público do evento antes de excluir a lista.")
    db.delete(item)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/lists/{list_id}/members", response_model=ContactListOut)
def list_members(
    list_id: str,
    q: str = "",
    page: int = 1,
    page_size: int = 25,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _get_list(db, user.workspace_id, list_id)
    page = max(page, 1)
    page_size = min(max(page_size, 1), 100)
    stmt = (
        select(Contact)
        .join(ContactListMembership, ContactListMembership.contact_id == Contact.id)
        .where(
            Contact.workspace_id == user.workspace_id,
            ContactListMembership.workspace_id == user.workspace_id,
            ContactListMembership.list_id == list_id,
        )
    )
    if q.strip():
        term = f"%{q.strip()}%"
        stmt = stmt.where(or_(Contact.name.ilike(term), Contact.last_name.ilike(term), Contact.email.ilike(term), Contact.phone.ilike(term)))
    matches = list(db.scalars(stmt.order_by(Contact.created_at.desc())))
    total = len(matches)
    pages = max(1, ceil(total / page_size))
    page = min(page, pages)
    start = (page - 1) * page_size
    return ContactListOut(items=matches[start:start + page_size], total=total, page=page, page_size=page_size, pages=pages)


@router.post("/lists/{list_id}/members", response_model=ListMembersResult)
def add_members(list_id: str, payload: ListMembersIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    _get_list(db, user.workspace_id, list_id)
    ids = list(dict.fromkeys(payload.contact_ids))
    valid_contacts = set(db.scalars(select(Contact.id).where(Contact.workspace_id == user.workspace_id, Contact.id.in_(ids))))
    existing = set(db.scalars(select(ContactListMembership.contact_id).where(
        ContactListMembership.workspace_id == user.workspace_id,
        ContactListMembership.list_id == list_id,
        ContactListMembership.contact_id.in_(ids),
    )))
    added = 0
    list_item = _get_list(db, user.workspace_id, list_id)
    for contact_id in valid_contacts - existing:
        db.add(ContactListMembership(workspace_id=user.workspace_id, list_id=list_id, contact_id=contact_id))
        db.add(ContactEvent(workspace_id=user.workspace_id, contact_id=contact_id, event_type="list_added", description=f"Adicionado à lista '{list_item.name}'.", event_data={"list_id": list_id, "list_name": list_item.name}))
        added += 1
    db.commit()
    total, _ = _list_counts(db, user.workspace_id, list_id)
    return ListMembersResult(affected=added, member_count=total)


@router.post("/lists/{list_id}/members/remove", response_model=ListMembersResult)
def remove_members(list_id: str, payload: ListMembersIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    _get_list(db, user.workspace_id, list_id)
    ids = list(dict.fromkeys(payload.contact_ids))
    list_item = _get_list(db, user.workspace_id, list_id)
    existing_ids = set(db.scalars(select(ContactListMembership.contact_id).where(
        ContactListMembership.workspace_id == user.workspace_id,
        ContactListMembership.list_id == list_id,
        ContactListMembership.contact_id.in_(ids),
    )))
    result = db.execute(
        delete(ContactListMembership).where(
            ContactListMembership.workspace_id == user.workspace_id,
            ContactListMembership.list_id == list_id,
            ContactListMembership.contact_id.in_(ids),
        )
    )
    for contact_id in existing_ids:
        db.add(ContactEvent(workspace_id=user.workspace_id, contact_id=contact_id, event_type="list_removed", description=f"Removido da lista '{list_item.name}'.", event_data={"list_id": list_id, "list_name": list_item.name}))
    db.commit()
    total, _ = _list_counts(db, user.workspace_id, list_id)
    return ListMembersResult(affected=result.rowcount or 0, member_count=total)


@router.get("/segments", response_model=list[SegmentOut])
def list_segments(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    items = db.scalars(select(Segment).where(Segment.workspace_id == user.workspace_id).order_by(Segment.updated_at.desc()))
    return [_segment_out(db, item) for item in items]


@router.post("/segments", response_model=SegmentOut, status_code=status.HTTP_201_CREATED)
def create_segment(payload: SegmentCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = Segment(
        workspace_id=user.workspace_id,
        name=payload.name.strip(),
        description=payload.description.strip(),
        match_mode=payload.match_mode,
        rules=[r.model_dump() for r in payload.rules],
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return _segment_out(db, item)


@router.patch("/segments/{segment_id}", response_model=SegmentOut)
def update_segment(segment_id: str, payload: SegmentUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _get_segment(db, user.workspace_id, segment_id)
    data = payload.model_dump(exclude_unset=True)
    if "name" in data:
        data["name"] = data["name"].strip()
    if "description" in data and data["description"] is not None:
        data["description"] = data["description"].strip()
    if "rules" in data and data["rules"] is not None:
        data["rules"] = [r if isinstance(r, dict) else r.model_dump() for r in data["rules"]]
    for key, value in data.items():
        setattr(item, key, value)
    db.commit()
    db.refresh(item)
    return _segment_out(db, item)


@router.delete("/segments/{segment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_segment(segment_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _get_segment(db, user.workspace_id, segment_id)
    event_use = db.scalar(select(func.count(MarketingEvent.id)).where(MarketingEvent.workspace_id == user.workspace_id, MarketingEvent.audience_type == "segment", MarketingEvent.audience_id == segment_id)) or 0
    if event_use:
        raise HTTPException(status_code=409, detail="Este segmento é público de um evento. Altere o público do evento antes de excluir o segmento.")
    db.delete(item)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/segments/preview", response_model=SegmentPreviewOut)
def preview_segment(payload: SegmentPreviewIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rules = [r.model_dump() for r in payload.rules]
    matches = _segment_contacts(db, user.workspace_id, rules, payload.match_mode)
    return SegmentPreviewOut(
        matching_count=len(matches),
        active_count=sum(1 for c in matches if c.status == "active"),
        sample=matches[:20],
    )


@router.get("/segments/{segment_id}/preview", response_model=SegmentPreviewOut)
def preview_saved_segment(segment_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    item = _get_segment(db, user.workspace_id, segment_id)
    matches = _segment_contacts(db, user.workspace_id, item.rules or [], item.match_mode)
    return SegmentPreviewOut(
        matching_count=len(matches),
        active_count=sum(1 for c in matches if c.status == "active"),
        sample=matches[:20],
    )
