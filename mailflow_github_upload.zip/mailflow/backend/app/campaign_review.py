from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json

from sqlalchemy import select
from sqlalchemy.orm import Session

from .deliverability import resolve_sender
from .email_provider import get_provider
from .models import Campaign, Contact, ContactList, ContactListMembership, Segment, SendingDomain
from .unsubscribe import find_suppression
from .segmentation import filter_contacts


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _all_workspace_contacts(db: Session, workspace_id: str) -> list[Contact]:
    return list(db.scalars(select(Contact).where(Contact.workspace_id == workspace_id).order_by(Contact.created_at.asc())))


def _validate_refs(db: Session, workspace_id: str, model, ids: list[str], label: str) -> list:
    out = []
    for ref_id in ids or []:
        item = db.get(model, ref_id)
        if not item or item.workspace_id != workspace_id:
            raise ValueError(f"{label} de exclusão não pertence a este workspace.")
        out.append(item)
    return out


def base_audience_contacts(db: Session, campaign: Campaign) -> list[Contact]:
    contacts = _all_workspace_contacts(db, campaign.workspace_id)
    if campaign.audience_type == "list" and campaign.audience_id:
        member_ids = set(db.scalars(select(ContactListMembership.contact_id).where(
            ContactListMembership.workspace_id == campaign.workspace_id,
            ContactListMembership.list_id == campaign.audience_id,
        )))
        return [c for c in contacts if c.id in member_ids]
    if campaign.audience_type == "segment" and campaign.audience_id:
        segment = db.get(Segment, campaign.audience_id)
        if not segment or segment.workspace_id != campaign.workspace_id:
            return []
        return filter_contacts(contacts, segment.rules or [], segment.match_mode)
    if (campaign.segment or "").startswith("Tag: "):
        tag = campaign.segment.removeprefix("Tag: ").casefold()
        return [c for c in contacts if tag in {str(t).casefold() for t in (c.tags or [])}]
    return contacts


def resolve_campaign_audience(db: Session, campaign: Campaign) -> dict:
    base = base_audience_contacts(db, campaign)
    remaining = list(base)
    exclusions: dict[str, int] = {
        "inactive_status": 0,
        "suppression": 0,
        "lists": 0,
        "segments": 0,
        "tags": 0,
    }

    active: list[Contact] = []
    for contact in remaining:
        if contact.status != "active":
            exclusions["inactive_status"] += 1
        else:
            active.append(contact)
    remaining = active

    unsuppressed: list[Contact] = []
    for contact in remaining:
        if find_suppression(db, campaign.workspace_id, contact.email):
            exclusions["suppression"] += 1
        else:
            unsuppressed.append(contact)
    remaining = unsuppressed

    exclude_lists = _validate_refs(db, campaign.workspace_id, ContactList, campaign.exclude_list_ids or [], "Lista")
    if exclude_lists and remaining:
        list_ids = [x.id for x in exclude_lists]
        member_ids = set(db.scalars(select(ContactListMembership.contact_id).where(
            ContactListMembership.workspace_id == campaign.workspace_id,
            ContactListMembership.list_id.in_(list_ids),
        )))
        kept = []
        for contact in remaining:
            if contact.id in member_ids:
                exclusions["lists"] += 1
            else:
                kept.append(contact)
        remaining = kept

    exclude_segments = _validate_refs(db, campaign.workspace_id, Segment, campaign.exclude_segment_ids or [], "Segmento")
    if exclude_segments and remaining:
        excluded_ids: set[str] = set()
        for segment in exclude_segments:
            matches = filter_contacts(remaining, segment.rules or [], segment.match_mode)
            excluded_ids.update(c.id for c in matches)
        kept = []
        for contact in remaining:
            if contact.id in excluded_ids:
                exclusions["segments"] += 1
            else:
                kept.append(contact)
        remaining = kept

    tags = {str(t).strip().casefold() for t in (campaign.exclude_tags or []) if str(t).strip()}
    if tags and remaining:
        kept = []
        for contact in remaining:
            contact_tags = {str(t).casefold() for t in (contact.tags or [])}
            if tags.intersection(contact_tags):
                exclusions["tags"] += 1
            else:
                kept.append(contact)
        remaining = kept

    return {
        "base": base,
        "eligible": remaining,
        "exclusions": exclusions,
        "excluded_total": len(base) - len(remaining),
    }


def _review_token(campaign: Campaign, eligible: list[Contact], sender_id: str | None) -> str:
    payload = {
        "campaign_id": campaign.id,
        "updated_at": campaign.updated_at.isoformat() if campaign.updated_at else "",
        "scheduled_at": campaign.scheduled_at.isoformat() if campaign.scheduled_at else "",
        "status": campaign.status,
        "sender_id": sender_id or "",
        "eligible_ids": [c.id for c in eligible],
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def build_campaign_review(db: Session, campaign: Campaign) -> dict:
    provider = get_provider()
    resolved = resolve_campaign_audience(db, campaign)
    sender = resolve_sender(
        db,
        campaign.workspace_id,
        require_verified=provider.live,
        identity_id=campaign.sender_id,
    )

    blockers: list[str] = []
    warnings: list[str] = []
    if provider.name == "resend" and not provider.configured:
        blockers.append("RESEND_API_KEY não configurada no backend.")
    if provider.live and not sender:
        blockers.append("O remetente escolhido/padrão não está pronto. Verifique domínio, SPF, DKIM e DMARC antes do envio real.")
    if not provider.live and not sender:
        warnings.append("Nenhum remetente cadastrado; o modo de desenvolvimento usará dev@localhost.")
    if provider.live and sender and sender.domain_id:
        domain = db.get(SendingDomain, sender.domain_id)
        if domain:
            if not domain.open_tracking:
                warnings.append("Open tracking está desativado neste domínio; a taxa de abertura não será preenchida pelo provedor.")
            if not domain.click_tracking:
                warnings.append("Click tracking está desativado neste domínio; cliques e ranking de links não serão preenchidos pelo provedor.")
    if not campaign.subject.strip():
        blockers.append("Defina o assunto da campanha.")
    if not (campaign.html_body or "").strip() and not (campaign.body or "").strip():
        blockers.append("A campanha não possui conteúdo de e-mail.")
    if not resolved["eligible"]:
        blockers.append("Não há contatos elegíveis depois das exclusões.")
    if campaign.status == "scheduled":
        if not campaign.scheduled_at:
            blockers.append("Defina data e hora para o agendamento.")
        else:
            scheduled = campaign.scheduled_at
            if scheduled.tzinfo is None:
                scheduled = scheduled.replace(tzinfo=timezone.utc)
            if scheduled <= utcnow():
                blockers.append("O horário agendado já passou. Atualize a data antes de ativar o envio.")
    if not campaign.preheader.strip():
        warnings.append("A campanha está sem preheader.")
    if len(resolved["eligible"]) >= 1000:
        warnings.append("Volume alto: confirme que o domínio público do descadastro usa HTTPS e monitore reclamações/opt-outs.")

    effective_sender = sender
    if not effective_sender and not provider.live:
        from .deliverability import ResolvedSender
        effective_sender = ResolvedSender("Sua Marca", "dev@localhost", "")

    token = _review_token(campaign, resolved["eligible"], effective_sender.identity_id if effective_sender else None)
    return {
        "campaign_id": campaign.id,
        "campaign_name": campaign.name,
        "status": campaign.status,
        "scheduled_at": campaign.scheduled_at,
        "provider": provider.name,
        "live": provider.live,
        "base_audience": len(resolved["base"]),
        "eligible": len(resolved["eligible"]),
        "excluded_total": resolved["excluded_total"],
        "exclusions": resolved["exclusions"],
        "sender": None if not effective_sender else {
            "id": effective_sender.identity_id,
            "name": effective_sender.sender_name,
            "email": effective_sender.sender_email,
            "reply_to": effective_sender.reply_to,
            "domain_id": effective_sender.domain_id,
        },
        "blockers": blockers,
        "warnings": warnings,
        "can_send": not blockers,
        "review_token": token,
        "sample": [
            {"id": c.id, "name": c.name or "", "last_name": c.last_name or "", "email": c.email}
            for c in resolved["eligible"][:20]
        ],
        "eligible_contacts": resolved["eligible"],
    }


def validate_review_confirmation(db: Session, campaign: Campaign, review_token: str, expected_recipients: int) -> dict:
    review = build_campaign_review(db, campaign)
    if review["review_token"] != review_token or review["eligible"] != expected_recipients:
        raise ValueError("A campanha ou a audiência mudou após a revisão. Revise novamente antes de enviar.")
    if not review["can_send"]:
        raise ValueError(" ".join(review["blockers"]))
    return review
