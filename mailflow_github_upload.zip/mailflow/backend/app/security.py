from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import os
import secrets

from fastapi import Cookie, Depends, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .database import get_db
from .models import User, UserSession

SESSION_COOKIE = os.getenv("SESSION_COOKIE_NAME", "mailflow_session")
SESSION_DAYS = int(os.getenv("SESSION_DAYS", "30"))
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "false").lower() == "true"
CSRF_COOKIE = os.getenv("CSRF_COOKIE_NAME", "mailflow_csrf")
CSRF_SECRET = os.getenv("MAILFLOW_CSRF_SECRET", "dev-mailflow-csrf-secret-change-me")
CSRF_ENABLED = os.getenv("MAILFLOW_CSRF_ENABLED", "false").lower() == "true"


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _b64hex(data: bytes) -> str:
    return data.hex()


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    # scrypt is deliberately expensive and available in Python's standard library.
    derived = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=5, dklen=32)
    return f"scrypt$16384$8$5${_b64hex(salt)}${_b64hex(derived)}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algo, n, r, p, salt_hex, hash_hex = encoded.split("$", 5)
        if algo != "scrypt":
            return False
        derived = hashlib.scrypt(
            password.encode("utf-8"),
            salt=bytes.fromhex(salt_hex),
            n=int(n), r=int(r), p=int(p), dklen=32,
        )
        return hmac.compare_digest(derived.hex(), hash_hex)
    except (ValueError, TypeError):
        return False


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def new_token() -> str:
    return secrets.token_urlsafe(48)




def create_csrf_token(session_token: str) -> str:
    nonce = secrets.token_urlsafe(24)
    message = f"{session_token}:{nonce}".encode("utf-8")
    mac = hmac.new(CSRF_SECRET.encode("utf-8"), message, hashlib.sha256).hexdigest()
    return f"{nonce}.{mac}"


def verify_csrf_token(session_token: str, token: str) -> bool:
    try:
        nonce, mac = token.rsplit(".", 1)
    except ValueError:
        return False
    if not nonce or len(mac) != 64:
        return False
    expected = hmac.new(
        CSRF_SECRET.encode("utf-8"),
        f"{session_token}:{nonce}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, mac)

def create_session(db: Session, user: User, request: Request, response: Response) -> None:
    raw = new_token()
    session = UserSession(
        user_id=user.id,
        token_hash=token_hash(raw),
        expires_at=utcnow() + timedelta(days=SESSION_DAYS),
        user_agent=(request.headers.get("user-agent") or "")[:500] or None,
    )
    db.add(session)
    db.commit()
    response.set_cookie(
        key=SESSION_COOKIE,
        value=raw,
        max_age=SESSION_DAYS * 24 * 60 * 60,
        httponly=True,
        secure=COOKIE_SECURE,
        samesite="lax",
        path="/",
    )
    if CSRF_ENABLED:
        response.set_cookie(
            key=CSRF_COOKIE,
            value=create_csrf_token(raw),
            max_age=SESSION_DAYS * 24 * 60 * 60,
            httponly=False,
            secure=COOKIE_SECURE,
            samesite="lax",
            path="/",
        )


def clear_session_cookie(response: Response) -> None:
    response.delete_cookie(SESSION_COOKIE, path="/", secure=COOKIE_SECURE, httponly=True, samesite="lax")
    if CSRF_ENABLED:
        response.delete_cookie(CSRF_COOKIE, path="/", secure=COOKIE_SECURE, httponly=False, samesite="lax")


def get_current_session(
    session_token: str | None = Cookie(default=None, alias=SESSION_COOKIE),
    db: Session = Depends(get_db),
) -> UserSession:
    if not session_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Faça login para continuar.")
    session = db.scalar(select(UserSession).where(
        UserSession.token_hash == token_hash(session_token),
        UserSession.expires_at > utcnow(),
    ))
    if not session:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Sua sessão expirou. Faça login novamente.")
    return session


def get_current_user(
    session: UserSession = Depends(get_current_session),
    db: Session = Depends(get_db),
) -> User:
    user = db.get(User, session.user_id)
    if not user or not user.active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Usuário indisponível.")
    session.last_seen_at = utcnow()
    db.commit()
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Apenas administradores podem executar esta ação.")
    return user
