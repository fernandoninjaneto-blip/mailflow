from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any
import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .deliverability import ResolvedSender, resolve_sender
from .email_content import render_with_context, substitute_variables
from .email_provider import get_provider
from .models import (
    Automation,
    AutomationRun,
    AutomationStepExecution,
    AutomationTriggerReceipt,
    Contact,
    ContactEvent,
    EmailDelivery,
    Template,
    Workspace,
)
from .segmentation import filter_contacts
from .unsubscribe import find_suppression, inject_unsubscribe_footer, unsubscribe_url


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


TRIGGER_EVENT_TYPES: dict[str, tuple[str, ...]] = {
    "contact_created": ("created", "import_created"),
    "tag_added": ("tags_added", "created", "import_created"),
    "list_joined": ("list_added",),
    "email_clicked": ("email_clicked",),
    "status_changed": ("status_changed",),
    "manual": (),
}


def trigger_label(trigger_type: str, config: dict[str, Any] | None = None) -> str:
    config = config or {}
    if trigger_type == "contact_created":
        return "Contato entra na base"
    if trigger_type == "tag_added":
        return f"Tag adicionada: {config.get('tag') or 'qualquer tag'}"
    if trigger_type == "list_joined":
        return "Contato entra em uma lista"
    if trigger_type == "email_clicked":
        return "Clique em campanha"
    if trigger_type == "status_changed":
        return f"Status alterado para {config.get('to') or 'qualquer status'}"
    return "Inscrição manual"


def step_label(step: dict[str, Any]) -> str:
    kind = step.get("type")
    if kind == "send_email":
        return "Enviar e-mail"
    if kind == "wait":
        units = {"minutes": "min", "hours": "h", "days": "dia(s)"}
        return f"Aguardar {step.get('amount', 1)} {units.get(step.get('unit'), step.get('unit') or '')}"
    if kind == "condition":
        return "Verificar condição"
    if kind == "add_tag":
        return f"Adicionar tag: {step.get('tag', '')}"
    if kind == "remove_tag":
        return f"Remover tag: {step.get('tag', '')}"
    return str(kind or "Etapa")


def _event_matches(automation: Automation, event: ContactEvent, contact: Contact | None) -> bool:
    if not contact or contact.workspace_id != automation.workspace_id:
        return False
    config = automation.trigger_config or {}
    trigger = automation.trigger_type
    if event.event_type not in TRIGGER_EVENT_TYPES.get(trigger, ()):
        return False
    if trigger == "contact_created":
        source = str(config.get("source") or "").strip().casefold()
        return not source or contact.source.casefold() == source
    if trigger == "tag_added":
        wanted = str(config.get("tag") or "").strip().casefold()
        if not wanted:
            return True
        if event.event_type == "tags_added":
            return wanted in {str(x).casefold() for x in (event.event_data or {}).get("tags", [])}
        return wanted in {str(x).casefold() for x in (contact.tags or [])}
    if trigger == "list_joined":
        wanted = str(config.get("list_id") or "").strip()
        return not wanted or str((event.event_data or {}).get("list_id") or "") == wanted
    if trigger == "email_clicked":
        campaign_id = str(config.get("campaign_id") or "").strip()
        url_contains = str(config.get("url_contains") or "").strip().casefold()
        data = event.event_data or {}
        if campaign_id and str(data.get("campaign_id") or "") != campaign_id:
            return False
        if url_contains and url_contains not in str(data.get("url") or "").casefold():
            return False
        return True
    if trigger == "status_changed":
        wanted = str(config.get("to") or "").strip().casefold()
        return not wanted or str((event.event_data or {}).get("to") or "").casefold() == wanted
    return False


def enroll_contact(
    db: Session,
    automation: Automation,
    contact: Contact,
    *,
    trigger_event_id: str | None = None,
    context: dict[str, Any] | None = None,
) -> AutomationRun | None:
    if contact.workspace_id != automation.workspace_id:
        return None
    if automation.reentry_policy == "once":
        existing = db.scalar(select(AutomationRun).where(
            AutomationRun.automation_id == automation.id,
            AutomationRun.contact_id == contact.id,
        ).limit(1))
        if existing:
            return None
    if trigger_event_id:
        existing = db.scalar(select(AutomationRun).where(
            AutomationRun.automation_id == automation.id,
            AutomationRun.trigger_event_id == trigger_event_id,
        ))
        if existing:
            return existing
    run = AutomationRun(
        workspace_id=automation.workspace_id,
        automation_id=automation.id,
        contact_id=contact.id,
        trigger_event_id=trigger_event_id,
        status="running",
        current_step=0,
        next_run_at=utcnow(),
        context_json={
            **(context or {}),
            "steps_snapshot": automation.steps_json or [],
            "sender_id_snapshot": automation.sender_id,
        },
    )
    db.add(run)
    db.flush()
    db.add(ContactEvent(
        workspace_id=contact.workspace_id,
        contact_id=contact.id,
        event_type="automation_enrolled",
        description=f"Contato entrou na automação '{automation.name}'.",
        event_data={"automation_id": automation.id, "run_id": run.id},
    ))
    return run


def scan_triggers(db: Session, limit_per_automation: int = 250) -> dict[str, int]:
    scanned = 0
    enrolled = 0
    automations = list(db.scalars(select(Automation).where(Automation.active.is_(True))))
    for automation in automations:
        event_types = TRIGGER_EVENT_TYPES.get(automation.trigger_type, ())
        if not event_types:
            continue
        activated_at = _aware(automation.activated_at) or _aware(automation.created_at) or utcnow()
        events = list(db.scalars(select(ContactEvent).where(
            ContactEvent.workspace_id == automation.workspace_id,
            ContactEvent.event_type.in_(event_types),
            ContactEvent.created_at >= activated_at,
        ).order_by(ContactEvent.created_at.asc(), ContactEvent.id.asc()).limit(limit_per_automation)))
        for event in events:
            receipt = db.scalar(select(AutomationTriggerReceipt).where(
                AutomationTriggerReceipt.automation_id == automation.id,
                AutomationTriggerReceipt.event_id == event.id,
            ))
            if receipt:
                continue
            scanned += 1
            contact = db.get(Contact, event.contact_id)
            matched = _event_matches(automation, event, contact)
            run = None
            if matched and contact:
                run = enroll_contact(db, automation, contact, trigger_event_id=event.id, context={"trigger_event_type": event.event_type})
                if run:
                    enrolled += 1
            db.add(AutomationTriggerReceipt(
                workspace_id=automation.workspace_id,
                automation_id=automation.id,
                event_id=event.id,
                matched=bool(matched),
                run_id=run.id if run else None,
            ))
        if events:
            db.commit()
    return {"triggers_scanned": scanned, "enrolled": enrolled}


def _context(contact: Contact, workspace_name: str) -> dict[str, Any]:
    return {
        "name": contact.name,
        "last_name": contact.last_name,
        "email": contact.email,
        "workspace_name": workspace_name,
        "custom_fields": contact.custom_fields or {},
    }


def _automation_sender(db: Session, automation: Automation, sender_id: str | None = None) -> ResolvedSender:
    provider = get_provider()
    sender = resolve_sender(db, automation.workspace_id, require_verified=provider.live, identity_id=sender_id if sender_id is not None else automation.sender_id)
    if provider.live and not sender:
        raise ValueError("A automação não possui remetente ligado a um domínio verificado.")
    if not sender:
        sender = ResolvedSender("Sua Marca", "dev@localhost", "")
    return sender


def _enqueue_template_email(db: Session, automation: Automation, run: AutomationRun, contact: Contact, step_index: int, step: dict[str, Any]) -> EmailDelivery:
    template = db.get(Template, step.get("template_id"))
    if not template or template.workspace_id != automation.workspace_id:
        raise ValueError("Template da automação não encontrado.")
    suppression = find_suppression(db, automation.workspace_id, contact.email)
    if suppression or contact.status != "active":
        raise PermissionError("Contato não está elegível para e-mail de marketing.")
    sender = _automation_sender(db, automation, (run.context_json or {}).get("sender_id_snapshot"))
    workspace = db.get(Workspace, automation.workspace_id)
    context = _context(contact, workspace.name if workspace else "Sua Empresa")
    rendered = render_with_context(template.subject, template.preheader, template.html_body, context)
    text = substitute_variables(template.body or "", context)
    delivery_id = str(uuid.uuid4())
    unsub = unsubscribe_url(delivery_id)
    rendered["html"], text = inject_unsubscribe_footer(rendered["html"], text, unsub, workspace.name if workspace else "Sua Empresa")
    provider = get_provider()
    delivery = EmailDelivery(
        id=delivery_id,
        workspace_id=automation.workspace_id,
        campaign_id=None,
        automation_run_id=run.id,
        automation_step_index=step_index,
        contact_id=contact.id,
        recipient_email=contact.email,
        recipient_name=" ".join(x for x in [contact.name, contact.last_name] if x).strip(),
        is_test=False,
        status="queued",
        provider=provider.name,
        idempotency_key=f"automation/{automation.id}/run/{run.id}/step/{step_index}",
        subject_snapshot=rendered["subject"],
        html_snapshot=rendered["html"],
        text_snapshot=text,
        sender_name_snapshot=sender.sender_name or "",
        sender_email_snapshot=sender.sender_email or "",
        reply_to_snapshot=sender.reply_to or "",
        next_attempt_at=utcnow(),
    )
    db.add(delivery)
    db.flush()
    return delivery


def _execution(db: Session, run_id: str, step_index: int) -> AutomationStepExecution | None:
    return db.scalar(select(AutomationStepExecution).where(
        AutomationStepExecution.run_id == run_id,
        AutomationStepExecution.step_index == step_index,
    ))


def _log_execution(db: Session, run: AutomationRun, step_index: int, step_type: str, status: str, output: dict[str, Any] | None = None) -> AutomationStepExecution:
    item = _execution(db, run.id, step_index)
    if not item:
        item = AutomationStepExecution(
            workspace_id=run.workspace_id,
            run_id=run.id,
            step_index=step_index,
            step_type=step_type,
            status=status,
            output_json=output or {},
            completed_at=utcnow() if status == "completed" else None,
        )
        db.add(item)
    else:
        item.status = status
        item.output_json = output or item.output_json or {}
        if status == "completed":
            item.completed_at = item.completed_at or utcnow()
    return item


def _finish_run(db: Session, run: AutomationRun, automation: Automation, contact: Contact | None, *, status: str, error: str = "") -> None:
    run.status = status
    run.last_error = error[:1000]
    run.next_run_at = None
    run.completed_at = utcnow()
    if contact:
        label = {"completed": "concluiu", "failed": "falhou em", "cancelled": "saiu de"}.get(status, status)
        db.add(ContactEvent(
            workspace_id=run.workspace_id,
            contact_id=contact.id,
            event_type=f"automation_{status}",
            description=f"Contato {label} a automação '{automation.name}'.",
            event_data={"automation_id": automation.id, "run_id": run.id, "error": error[:500]},
        ))


def _wait_delta(amount: int, unit: str) -> timedelta:
    if unit == "minutes":
        return timedelta(minutes=amount)
    if unit == "hours":
        return timedelta(hours=amount)
    return timedelta(days=amount)


def process_run(db: Session, run: AutomationRun) -> AutomationRun:
    automation = db.get(Automation, run.automation_id)
    contact = db.get(Contact, run.contact_id) if run.contact_id else None
    if not automation or not automation.active:
        return run
    if not contact or contact.workspace_id != run.workspace_id:
        _finish_run(db, run, automation, contact, status="cancelled", error="Contato não existe mais.")
        db.commit()
        return run
    steps = (run.context_json or {}).get("steps_snapshot") or automation.steps_json or []
    if run.current_step >= len(steps):
        _finish_run(db, run, automation, contact, status="completed")
        db.commit()
        return run

    now = utcnow()
    due = _aware(run.next_run_at)
    if due and due > now:
        run.status = "waiting"
        return run

    # Executa etapas instantâneas em cadeia, com limite de segurança.
    for _ in range(30):
        if run.current_step >= len(steps):
            _finish_run(db, run, automation, contact, status="completed")
            db.commit()
            return run
        idx = run.current_step
        step = steps[idx]
        kind = str(step.get("type") or "")
        run.status = "running"
        try:
            if kind == "wait":
                amount = max(1, int(step.get("amount") or 1))
                unit = str(step.get("unit") or "days")
                next_at = utcnow() + _wait_delta(amount, unit)
                _log_execution(db, run, idx, kind, "completed", {"wait_until": next_at.isoformat()})
                run.current_step += 1
                run.status = "waiting"
                run.next_run_at = next_at
                db.commit()
                return run

            if kind == "condition":
                matched = bool(filter_contacts([contact], step.get("rules") or [], step.get("match_mode") or "all"))
                _log_execution(db, run, idx, kind, "completed", {"matched": matched})
                if matched:
                    run.current_step += 1
                elif step.get("on_false", "stop") == "skip_next":
                    run.current_step += 2
                else:
                    run.context_json = {**(run.context_json or {}), "stopped_by_condition": idx}
                    _finish_run(db, run, automation, contact, status="completed")
                    db.commit()
                    return run
                run.next_run_at = utcnow()
                continue

            if kind in {"add_tag", "remove_tag"}:
                tag = str(step.get("tag") or "").strip()
                current = list(contact.tags or [])
                if kind == "add_tag":
                    if tag and tag.casefold() not in {x.casefold() for x in current}:
                        contact.tags = current + [tag]
                        db.add(ContactEvent(workspace_id=run.workspace_id, contact_id=contact.id, event_type="tags_added", description=f"Tag adicionada pela automação: {tag}.", event_data={"tags": [tag], "automation_id": automation.id}))
                else:
                    removed = [x for x in current if x.casefold() == tag.casefold()]
                    if removed:
                        contact.tags = [x for x in current if x.casefold() != tag.casefold()]
                        db.add(ContactEvent(workspace_id=run.workspace_id, contact_id=contact.id, event_type="tags_removed", description=f"Tag removida pela automação: {tag}.", event_data={"tags": removed, "automation_id": automation.id}))
                _log_execution(db, run, idx, kind, "completed", {"tag": tag})
                run.current_step += 1
                run.next_run_at = utcnow()
                continue

            if kind == "send_email":
                execution = _execution(db, run.id, idx)
                if not execution:
                    delivery = _enqueue_template_email(db, automation, run, contact, idx, step)
                    _log_execution(db, run, idx, kind, "waiting", {"delivery_id": delivery.id})
                    run.status = "waiting"
                    run.next_run_at = utcnow() + timedelta(seconds=5)
                    db.commit()
                    return run
                delivery_id = str((execution.output_json or {}).get("delivery_id") or "")
                delivery = db.get(EmailDelivery, delivery_id) if delivery_id else None
                if not delivery:
                    raise ValueError("Entrega da automação não encontrada.")
                if delivery.status in {"sent", "delivered"}:
                    execution.status = "completed"
                    execution.completed_at = execution.completed_at or utcnow()
                    run.current_step += 1
                    run.next_run_at = utcnow()
                    continue
                if delivery.status in {"failed", "bounced", "complained"}:
                    execution.status = "failed"
                    _finish_run(db, run, automation, contact, status="failed", error=delivery.last_error or f"Entrega terminou como {delivery.status}.")
                    db.commit()
                    return run
                if delivery.status in {"suppressed", "cancelled"}:
                    execution.status = "cancelled"
                    _finish_run(db, run, automation, contact, status="cancelled", error="Contato não está elegível para novos envios.")
                    db.commit()
                    return run
                run.status = "waiting"
                run.next_run_at = _aware(delivery.next_attempt_at) or (utcnow() + timedelta(seconds=5))
                db.commit()
                return run

            raise ValueError(f"Tipo de etapa desconhecido: {kind}")
        except PermissionError as exc:
            _log_execution(db, run, idx, kind or "unknown", "cancelled", {"error": str(exc)})
            _finish_run(db, run, automation, contact, status="cancelled", error=str(exc))
            db.commit()
            return run
        except Exception as exc:
            _log_execution(db, run, idx, kind or "unknown", "failed", {"error": str(exc)[:1000]})
            _finish_run(db, run, automation, contact, status="failed", error=str(exc))
            db.commit()
            return run

    _finish_run(db, run, automation, contact, status="failed", error="Limite de etapas instantâneas excedido.")
    db.commit()
    return run


def process_due_runs(db: Session, limit: int = 100) -> dict[str, int]:
    now = utcnow()
    runs = list(db.scalars(select(AutomationRun).join(
        Automation, Automation.id == AutomationRun.automation_id
    ).where(
        Automation.active.is_(True),
        AutomationRun.status.in_(["running", "waiting"]),
        func.coalesce(AutomationRun.next_run_at, now) <= now,
    ).order_by(AutomationRun.next_run_at.asc()).limit(max(1, min(limit, 500)))))
    failed = 0
    for run in runs:
        result = process_run(db, run)
        if result.status == "failed":
            failed += 1
    return {"runs_processed": len(runs), "runs_failed": failed}


def process_automation_cycle(db: Session, *, trigger_limit: int = 250, run_limit: int = 100) -> dict[str, int]:
    trigger_result = scan_triggers(db, trigger_limit)
    run_result = process_due_runs(db, run_limit)
    return {**trigger_result, **run_result}
