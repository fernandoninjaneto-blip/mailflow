from __future__ import annotations

from datetime import datetime, timedelta, timezone
import os
import uuid

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from .email_content import render_with_context, substitute_variables
from .email_provider import ProviderError, get_provider
from .deliverability import ResolvedSender, resolve_sender
from .campaign_review import resolve_campaign_audience
from .models import Automation, AutomationRun, Campaign, Contact, ContactEvent, ContactListMembership, EmailDelivery, Segment, Workspace
from .unsubscribe import find_suppression, inject_unsubscribe_footer, unsubscribe_headers, unsubscribe_url
from .tracking import apply_campaign_utm, refresh_engagement_metrics
from .segmentation import filter_contacts


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _campaign_contacts(db: Session, campaign: Campaign) -> list[Contact]:
    return resolve_campaign_audience(db, campaign)["eligible"]


def _context(contact: Contact, workspace_name: str) -> dict:
    return {
        "name": contact.name,
        "last_name": contact.last_name,
        "email": contact.email,
        "workspace_name": workspace_name,
        "custom_fields": contact.custom_fields or {},
    }


def _snapshot_delivery(db: Session, campaign: Campaign, contact: Contact, sender: ResolvedSender, provider_name: str, next_attempt_at: datetime | None = None) -> EmailDelivery:
    workspace = db.get(Workspace, campaign.workspace_id)
    context = _context(contact, workspace.name if workspace else "Sua Empresa")
    rendered = render_with_context(campaign.subject, campaign.preheader, campaign.html_body, context)
    rendered["html"] = apply_campaign_utm(rendered["html"], campaign)
    text = substitute_variables(campaign.body or "", context)
    delivery_id = str(uuid.uuid4())
    unsub_url = unsubscribe_url(delivery_id)
    rendered["html"], text = inject_unsubscribe_footer(rendered["html"], text, unsub_url, workspace.name if workspace else "Sua Empresa")
    return EmailDelivery(
        id=delivery_id,
        workspace_id=campaign.workspace_id,
        campaign_id=campaign.id,
        contact_id=contact.id,
        recipient_email=contact.email,
        recipient_name=" ".join(x for x in [contact.name, contact.last_name] if x).strip(),
        is_test=False,
        status="queued",
        provider=provider_name,
        idempotency_key=f"campaign/{campaign.id}/contact/{contact.id}",
        subject_snapshot=rendered["subject"],
        html_snapshot=rendered["html"],
        text_snapshot=text,
        sender_name_snapshot=sender.sender_name or "",
        sender_email_snapshot=sender.sender_email or "",
        reply_to_snapshot=sender.reply_to or "",
        next_attempt_at=next_attempt_at or utcnow(),
    )


def validate_send_configuration(db: Session, campaign: Campaign) -> dict:
    provider = get_provider()
    errors: list[str] = []
    if provider.name == "resend" and not provider.configured:
        errors.append("RESEND_API_KEY não configurada no backend.")
    sender = resolve_sender(db, campaign.workspace_id, require_verified=provider.live, identity_id=campaign.sender_id)
    if provider.live and not sender:
        errors.append("Configure um remetente padrão ligado a um domínio com SPF, DKIM e DMARC validados antes do envio real.")
    elif not provider.live and not sender:
        # Em desenvolvimento o fallback vazio continua permitido para preservar o pipeline local.
        sender = ResolvedSender("Sua Marca", "dev@localhost", "")
    return {
        "provider": provider.name,
        "live": provider.live,
        "configured": provider.configured,
        "errors": errors,
        "sender": sender,
    }


def enqueue_campaign(db: Session, campaign: Campaign, scheduled_for: datetime | None = None) -> int:
    existing = db.scalar(select(func.count(EmailDelivery.id)).where(
        EmailDelivery.campaign_id == campaign.id,
        EmailDelivery.is_test.is_(False),
    )) or 0
    if existing:
        return int(existing)

    config = validate_send_configuration(db, campaign)
    if config["errors"]:
        raise ValueError(" ".join(config["errors"]))

    contacts = _campaign_contacts(db, campaign)
    if not contacts:
        raise ValueError("A campanha não possui contatos ativos elegíveis para envio.")

    sender = config["sender"]
    provider = get_provider()
    for contact in contacts:
        db.add(_snapshot_delivery(db, campaign, contact, sender, provider.name, next_attempt_at=scheduled_for))

    now = utcnow()
    campaign.send_armed = True
    campaign.queued_at = campaign.queued_at or now
    if scheduled_for is None:
        campaign.status = "sending"
        campaign.send_started_at = campaign.send_started_at or now
    else:
        campaign.status = "scheduled"
    db.commit()
    return len(contacts)


def enqueue_due_campaigns(db: Session, limit: int = 20) -> int:
    now = utcnow()
    campaigns = list(db.scalars(select(Campaign).where(
        Campaign.status == "scheduled",
        Campaign.send_armed.is_(True),
        Campaign.scheduled_at.is_not(None),
        Campaign.scheduled_at <= now,
    ).order_by(Campaign.scheduled_at.asc()).limit(limit)))
    queued = 0
    for campaign in campaigns:
        try:
            existing = db.scalar(select(func.count(EmailDelivery.id)).where(
                EmailDelivery.campaign_id == campaign.id, EmailDelivery.is_test.is_(False)
            )) or 0
            if existing:
                campaign.status = "sending"
                campaign.send_started_at = campaign.send_started_at or now
                db.commit()
            else:
                queued += enqueue_campaign(db, campaign)
        except ValueError:
            campaign.status = "paused"
            campaign.send_armed = False
            db.commit()
    return queued


def _backoff_seconds(attempt: int) -> int:
    base = int(os.getenv("MAILFLOW_RETRY_BASE_SECONDS", "30"))
    maximum = int(os.getenv("MAILFLOW_RETRY_MAX_SECONDS", "3600"))
    return min(maximum, base * (2 ** max(0, attempt - 1)))


def refresh_campaign_metrics(db: Session, campaign_id: str | None) -> None:
    if not campaign_id:
        return
    campaign = db.get(Campaign, campaign_id)
    if not campaign:
        return
    rows = list(db.scalars(select(EmailDelivery).where(
        EmailDelivery.campaign_id == campaign_id,
        EmailDelivery.is_test.is_(False),
    )))
    campaign.sent = sum(1 for x in rows if x.sent_at is not None)
    campaign.delivered = sum(1 for x in rows if x.delivered_at is not None)
    campaign.opens = sum(1 for x in rows if x.opened_at is not None)
    campaign.clicks = sum(1 for x in rows if x.clicked_at is not None)
    refresh_engagement_metrics(db, campaign)
    campaign.bounces = sum(1 for x in rows if x.status == "bounced")
    campaign.complaints = sum(1 for x in rows if x.status == "complained")
    campaign.failures = sum(1 for x in rows if x.status == "failed")
    campaign.unsub = sum(1 for x in rows if x.unsubscribed_at is not None)

    terminal = {"sent", "delivered", "bounced", "complained", "failed", "suppressed", "cancelled"}
    if rows and all(x.status in terminal for x in rows):
        campaign.status = "sent"
        campaign.send_completed_at = campaign.send_completed_at or utcnow()
    elif rows:
        campaign.status = "sending"




def _wake_automation_run(db: Session, delivery: EmailDelivery) -> None:
    if not delivery.automation_run_id:
        return
    run = db.get(AutomationRun, delivery.automation_run_id)
    if not run or run.status not in {"running", "waiting"}:
        return
    if delivery.status == "retry" and delivery.next_attempt_at:
        run.next_run_at = delivery.next_attempt_at
    else:
        run.next_run_at = utcnow()

def process_delivery(db: Session, delivery: EmailDelivery) -> EmailDelivery:
    now = utcnow()
    if delivery.status not in {"queued", "retry"}:
        return delivery
    if not delivery.is_test:
        suppression = find_suppression(db, delivery.workspace_id, delivery.recipient_email)
        if suppression:
            delivery.status = "suppressed"
            delivery.next_attempt_at = None
            delivery.last_event_type = "mailflow.suppressed"
            delivery.last_error = f"Envio bloqueado pela supressão global ({suppression.reason})."
            refresh_campaign_metrics(db, delivery.campaign_id)
            _wake_automation_run(db, delivery)
            db.commit(); db.refresh(delivery)
            return delivery
        if delivery.campaign_id:
            campaign = db.get(Campaign, delivery.campaign_id)
            if not campaign or campaign.status != "sending":
                return delivery
        if delivery.automation_run_id:
            run = db.get(AutomationRun, delivery.automation_run_id)
            automation = db.get(Automation, run.automation_id) if run else None
            if not run or run.status not in {"running", "waiting"} or not automation or not automation.active:
                return delivery
    provider = get_provider()
    # O snapshot registra o provider da fila. Impede trocar silenciosamente de infraestrutura no meio da campanha.
    if delivery.provider != provider.name:
        delivery.status = "failed"
        delivery.failed_at = now
        delivery.last_error = f"Provider da fila é {delivery.provider}, mas o worker está configurado como {provider.name}."
        refresh_campaign_metrics(db, delivery.campaign_id)
        _wake_automation_run(db, delivery)
        db.commit()
        return delivery

    delivery.status = "processing"
    delivery.attempt_count += 1
    delivery.last_error = ""
    db.commit()

    try:
        result = provider.send(
            from_name=delivery.sender_name_snapshot,
            from_email=delivery.sender_email_snapshot,
            to_email=delivery.recipient_email,
            subject=delivery.subject_snapshot,
            html=delivery.html_snapshot,
            text=delivery.text_snapshot,
            reply_to=delivery.reply_to_snapshot,
            idempotency_key=delivery.idempotency_key,
            headers=None if delivery.is_test else unsubscribe_headers(unsubscribe_url(delivery.id)),
        )
        delivery.provider_message_id = result.message_id
        delivery.status = "sent"
        delivery.sent_at = delivery.sent_at or utcnow()
        delivery.next_attempt_at = None
        delivery.last_event_type = "email.sent"
    except ProviderError as exc:
        delivery.last_error = str(exc)[:1000]
        if exc.retryable and delivery.attempt_count < delivery.max_attempts:
            delivery.status = "retry"
            delivery.next_attempt_at = utcnow() + timedelta(seconds=_backoff_seconds(delivery.attempt_count))
        else:
            delivery.status = "failed"
            delivery.failed_at = utcnow()
            delivery.next_attempt_at = None
            delivery.last_event_type = "email.failed"

    refresh_campaign_metrics(db, delivery.campaign_id)
    _wake_automation_run(db, delivery)
    db.commit()
    db.refresh(delivery)
    return delivery


def process_batch(db: Session, limit: int = 50) -> dict:
    enqueue_due_campaigns(db)
    now = utcnow()
    jobs = list(db.scalars(select(EmailDelivery).outerjoin(
        Campaign, EmailDelivery.campaign_id == Campaign.id
    ).outerjoin(
        AutomationRun, EmailDelivery.automation_run_id == AutomationRun.id
    ).outerjoin(
        Automation, AutomationRun.automation_id == Automation.id
    ).where(
        EmailDelivery.status.in_(["queued", "retry"]),
        or_(EmailDelivery.next_attempt_at.is_(None), EmailDelivery.next_attempt_at <= now),
        or_(
            EmailDelivery.is_test.is_(True),
            Campaign.status == "sending",
            (EmailDelivery.automation_run_id.is_not(None) & Automation.active.is_(True) & AutomationRun.status.in_(["running", "waiting"])),
        ),
    ).order_by(EmailDelivery.queued_at.asc()).limit(max(1, min(limit, 500)))))
    processed = 0
    failed = 0
    for job in jobs:
        result = process_delivery(db, job)
        processed += 1
        if result.status == "failed":
            failed += 1
    return {"processed": processed, "failed": failed}


def send_test_delivery(db: Session, campaign: Campaign, recipient_email: str) -> EmailDelivery:
    config = validate_send_configuration(db, campaign)
    if config["errors"]:
        raise ValueError(" ".join(config["errors"]))
    sender = config["sender"]
    provider = get_provider()
    workspace = db.get(Workspace, campaign.workspace_id)
    sample = {
        "name": "Teste",
        "last_name": "MailFlow",
        "email": recipient_email,
        "workspace_name": workspace.name if workspace else "Sua Empresa",
        "custom_fields": {},
    }
    rendered = render_with_context(campaign.subject, campaign.preheader, campaign.html_body, sample)
    rendered["html"] = apply_campaign_utm(rendered["html"], campaign)
    delivery = EmailDelivery(
        workspace_id=campaign.workspace_id,
        campaign_id=campaign.id,
        contact_id=None,
        recipient_email=recipient_email,
        recipient_name="Teste MailFlow",
        is_test=True,
        status="queued",
        provider=provider.name,
        idempotency_key=f"test/{campaign.id}/{uuid.uuid4()}",
        subject_snapshot=rendered["subject"],
        html_snapshot=rendered["html"],
        text_snapshot=substitute_variables(campaign.body or "", sample),
        sender_name_snapshot=sender.sender_name or "",
        sender_email_snapshot=sender.sender_email or "",
        reply_to_snapshot=sender.reply_to or "",
        next_attempt_at=utcnow(),
    )
    db.add(delivery)
    db.commit()
    db.refresh(delivery)
    return process_delivery(db, delivery)


def record_contact_event(db: Session, delivery: EmailDelivery, event_type: str, description: str, data: dict | None = None) -> None:
    if not delivery.contact_id:
        return
    db.add(ContactEvent(
        workspace_id=delivery.workspace_id,
        contact_id=delivery.contact_id,
        event_type=event_type,
        description=description,
        event_data=data or {},
    ))
