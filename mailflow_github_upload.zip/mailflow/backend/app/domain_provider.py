from __future__ import annotations

import os
from typing import Any

import httpx


class DomainProviderError(RuntimeError):
    def __init__(self, message: str, *, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class ResendDomainClient:
    def __init__(self) -> None:
        self.api_key = os.getenv("RESEND_API_KEY", "").strip()
        self.base_url = os.getenv("RESEND_API_BASE", "https://api.resend.com").rstrip("/")
        self.timeout = float(os.getenv("MAILFLOW_PROVIDER_TIMEOUT_SECONDS", "20"))

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    def _request(self, method: str, path: str, *, json: dict[str, Any] | None = None) -> dict[str, Any]:
        if not self.api_key:
            raise DomainProviderError("RESEND_API_KEY não configurada no backend.")
        try:
            response = httpx.request(
                method,
                f"{self.base_url}{path}",
                headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
                json=json,
                timeout=self.timeout,
            )
        except httpx.TimeoutException as exc:
            raise DomainProviderError("Timeout ao comunicar com o Resend.") from exc
        except httpx.RequestError as exc:
            raise DomainProviderError(f"Falha de rede ao comunicar com o Resend: {exc}") from exc
        if response.status_code >= 400:
            try:
                data = response.json()
                message = data.get("message") or data.get("error") or response.text
            except Exception:
                message = response.text
            raise DomainProviderError(
                f"Resend respondeu {response.status_code}: {str(message)[:700]}",
                status_code=response.status_code,
            )
        if response.status_code == 204 or not response.content:
            return {}
        return response.json()

    def create_domain(
        self,
        *,
        name: str,
        region: str,
        custom_return_path: str,
        open_tracking: bool,
        click_tracking: bool,
        tracking_subdomain: str,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": name,
            "region": region,
            "custom_return_path": custom_return_path,
            "open_tracking": open_tracking,
            "click_tracking": click_tracking,
        }
        if tracking_subdomain:
            payload["tracking_subdomain"] = tracking_subdomain
        return self._request("POST", "/domains", json=payload)

    def get_domain(self, domain_id: str) -> dict[str, Any]:
        return self._request("GET", f"/domains/{domain_id}")

    def verify_domain(self, domain_id: str) -> dict[str, Any]:
        return self._request("POST", f"/domains/{domain_id}/verify")

    def update_domain(
        self,
        domain_id: str,
        *,
        open_tracking: bool,
        click_tracking: bool,
        tracking_subdomain: str,
        tls_mode: str,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "open_tracking": open_tracking,
            "click_tracking": click_tracking,
            "tls": tls_mode,
        }
        # O tracking_subdomain é definido na criação. Não o reenviamos em updates comuns,
        # pois mudanças de subdomínio têm restrições e exigem nova verificação DNS.
        return self._request("PATCH", f"/domains/{domain_id}", json=payload)
