from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
import html as html_lib
import re
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import Campaign, EmailDelivery, EmailEngagementEvent

_HREF_RE = re.compile(r'(?P<prefix>\bhref\s*=\s*)(?P<quote>["\'])(?P<url>.*?)(?P=quote)', re.I | re.S)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _slug(value: str) -> str:
    value = (value or '').strip().lower()
    value = re.sub(r'[^a-z0-9]+', '-', value).strip('-')
    return value[:120]


def add_utm_to_url(url: str, campaign: Campaign) -> str:
    if not getattr(campaign, 'utm_enabled', False):
        return url
    raw = (url or '').strip()
    if not raw or raw.startswith(('#', 'mailto:', 'tel:', 'sms:', 'javascript:')):
        return raw
    parsed = urlparse(raw)
    if parsed.scheme not in {'http', 'https'}:
        return raw

    values = {
        'utm_source': (campaign.utm_source or 'mailflow').strip(),
        'utm_medium': (campaign.utm_medium or 'email').strip(),
        'utm_campaign': (campaign.utm_campaign or _slug(campaign.name) or campaign.id).strip(),
        'utm_content': (campaign.utm_content or '').strip(),
        'utm_term': (campaign.utm_term or '').strip(),
    }
    utm_keys = set(values)
    params = [(k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True) if k not in utm_keys]
    params.extend((key, value) for key, value in values.items() if value)
    return urlunparse(parsed._replace(query=urlencode(params, doseq=True)))


def apply_campaign_utm(html: str, campaign: Campaign) -> str:
    if not getattr(campaign, 'utm_enabled', False) or not html:
        return html or ''

    def repl(match: re.Match[str]) -> str:
        raw_url = html_lib.unescape(match.group('url'))
        tracked = add_utm_to_url(raw_url, campaign)
        safe_url = html_lib.escape(tracked, quote=True)
        return f"{match.group('prefix')}{match.group('quote')}{safe_url}{match.group('quote')}"

    return _HREF_RE.sub(repl, html)


def _parse_event_time(payload: dict) -> datetime:
    candidates = [
        (payload.get('data') or {}).get('click', {}).get('timestamp') if isinstance((payload.get('data') or {}).get('click'), dict) else None,
        payload.get('created_at'),
        (payload.get('data') or {}).get('created_at'),
    ]
    for value in candidates:
        if not value:
            continue
        try:
            dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    return utcnow()


def record_engagement_event(
    db: Session,
    delivery: EmailDelivery,
    provider_event_id: str,
    event_type: str,
    payload: dict,
) -> EmailEngagementEvent | None:
    if event_type not in {'email.opened', 'email.clicked'}:
        return None
    existing = db.scalar(select(EmailEngagementEvent).where(
        EmailEngagementEvent.provider == delivery.provider,
        EmailEngagementEvent.provider_event_id == provider_event_id,
    ))
    if existing:
        return existing

    data = payload.get('data') or {}
    click = data.get('click') if isinstance(data.get('click'), dict) else {}
    link = str(click.get('link') or '').strip() if event_type == 'email.clicked' else ''
    parsed = urlparse(link) if link else None
    event = EmailEngagementEvent(
        workspace_id=delivery.workspace_id,
        campaign_id=delivery.campaign_id,
        delivery_id=delivery.id,
        contact_id=delivery.contact_id,
        provider=delivery.provider,
        provider_event_id=provider_event_id,
        event_type='click' if event_type == 'email.clicked' else 'open',
        occurred_at=_parse_event_time(payload),
        link_url=link,
        link_host=(parsed.hostname or '') if parsed else '',
        ip_address=str(click.get('ipAddress') or ''),
        user_agent=str(click.get('userAgent') or '')[:1000],
        event_data={'provider_type': event_type},
    )
    db.add(event)
    db.flush()
    return event


def refresh_engagement_metrics(db: Session, campaign: Campaign) -> None:
    open_count = int(db.scalar(select(func.count(EmailEngagementEvent.id)).where(
        EmailEngagementEvent.campaign_id == campaign.id,
        EmailEngagementEvent.event_type == 'open',
    )) or 0)
    click_count = int(db.scalar(select(func.count(EmailEngagementEvent.id)).where(
        EmailEngagementEvent.campaign_id == campaign.id,
        EmailEngagementEvent.event_type == 'click',
    )) or 0)
    # Campanhas migradas do Passo 9 podem ter apenas opened_at/clicked_at, sem eventos brutos históricos.
    campaign.open_events = max(open_count, int(campaign.opens or 0))
    campaign.click_events = max(click_count, int(campaign.clicks or 0))


def build_campaign_report(db: Session, campaign: Campaign, recipient_limit: int = 100) -> dict:
    deliveries = list(db.scalars(select(EmailDelivery).where(
        EmailDelivery.campaign_id == campaign.id,
        EmailDelivery.is_test.is_(False),
    ).order_by(EmailDelivery.queued_at.desc())))
    events = list(db.scalars(select(EmailEngagementEvent).where(
        EmailEngagementEvent.campaign_id == campaign.id,
    ).order_by(EmailEngagementEvent.occurred_at.asc())))

    delivered = sum(1 for d in deliveries if d.delivered_at is not None)
    sent = sum(1 for d in deliveries if d.sent_at is not None)
    unique_open_ids = {d.id for d in deliveries if d.opened_at is not None}
    unique_click_ids = {d.id for d in deliveries if d.clicked_at is not None}
    bounces = sum(1 for d in deliveries if d.status == 'bounced')
    complaints = sum(1 for d in deliveries if d.status == 'complained')

    def rate(n: int, base: int) -> float:
        return round((n / base) * 100, 2) if base else 0.0

    link_map: dict[str, dict] = defaultdict(lambda: {'delivery_ids': set(), 'total': 0, 'host': ''})
    per_delivery: dict[str, dict] = defaultdict(lambda: {'open_events': 0, 'click_events': 0, 'last_clicked_url': ''})
    for event in events:
        bucket = per_delivery[event.delivery_id]
        if event.event_type == 'open':
            bucket['open_events'] += 1
        elif event.event_type == 'click':
            bucket['click_events'] += 1
            bucket['last_clicked_url'] = event.link_url or bucket['last_clicked_url']
            if event.link_url:
                link_bucket = link_map[event.link_url]
                link_bucket['delivery_ids'].add(event.delivery_id)
                link_bucket['total'] += 1
                link_bucket['host'] = event.link_host or link_bucket['host']

    links = [{
        'url': url,
        'host': values['host'],
        'unique_clicks': len(values['delivery_ids']),
        'total_clicks': values['total'],
        'ctr': rate(len(values['delivery_ids']), delivered),
    } for url, values in link_map.items()]
    links.sort(key=lambda x: (-x['unique_clicks'], -x['total_clicks'], x['url']))

    recipients = []
    for d in deliveries[:max(1, min(recipient_limit, 500))]:
        e = per_delivery[d.id]
        recipients.append({
            'delivery_id': d.id,
            'contact_id': d.contact_id,
            'email': d.recipient_email,
            'name': d.recipient_name,
            'delivered_at': d.delivered_at,
            'opened_at': d.opened_at,
            'clicked_at': d.clicked_at,
            'open_events': e['open_events'],
            'click_events': e['click_events'],
            'last_clicked_url': e['last_clicked_url'],
        })

    unique_opens = len(unique_open_ids)
    unique_clicks = len(unique_click_ids)
    summary = {
        'sent': sent,
        'delivered': delivered,
        'delivery_rate': rate(delivered, sent),
        'unique_opens': unique_opens,
        'open_events': max(sum(1 for e in events if e.event_type == 'open'), unique_opens),
        'open_rate': rate(unique_opens, delivered),
        'unique_clicks': unique_clicks,
        'click_events': max(sum(1 for e in events if e.event_type == 'click'), unique_clicks),
        'click_rate': rate(unique_clicks, delivered),
        'click_to_open_rate': rate(unique_clicks, unique_opens),
        'bounces': bounces,
        'bounce_rate': rate(bounces, sent),
        'complaints': complaints,
        'complaint_rate': rate(complaints, delivered),
        'unsubscribes': campaign.unsub or 0,
    }
    return {
        'campaign_id': campaign.id,
        'campaign_name': campaign.name,
        'subject': campaign.subject,
        'status': campaign.status,
        'summary': summary,
        'links': links,
        'recipients': recipients,
        'utm': {
            'enabled': bool(campaign.utm_enabled),
            'source': campaign.utm_source or '',
            'medium': campaign.utm_medium or '',
            'campaign': campaign.utm_campaign or _slug(campaign.name),
            'content': campaign.utm_content or '',
            'term': campaign.utm_term or '',
        },
    }
