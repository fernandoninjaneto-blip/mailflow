from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import hmac
import os


class WebhookVerificationError(ValueError):
    pass


def verify_svix_signature(payload: bytes, headers: dict[str, str], secret: str | None = None) -> None:
    """Verifica assinaturas Svix/Resend usando o corpo bruto da requisição.

    Compatível com os headers svix-id, svix-timestamp e svix-signature.
    """
    secret = (secret or os.getenv("RESEND_WEBHOOK_SECRET", "")).strip()
    if not secret:
        raise WebhookVerificationError("RESEND_WEBHOOK_SECRET não configurado.")

    message_id = (headers.get("svix-id") or "").strip()
    timestamp = (headers.get("svix-timestamp") or "").strip()
    signatures = (headers.get("svix-signature") or "").strip()
    if not message_id or not timestamp or not signatures:
        raise WebhookVerificationError("Headers de assinatura ausentes.")

    try:
        ts = int(timestamp)
    except ValueError as exc:
        raise WebhookVerificationError("Timestamp de webhook inválido.") from exc

    tolerance = int(os.getenv("WEBHOOK_TOLERANCE_SECONDS", "300"))
    now = int(datetime.now(timezone.utc).timestamp())
    if abs(now - ts) > tolerance:
        raise WebhookVerificationError("Webhook fora da janela de tolerância.")

    encoded_secret = secret.removeprefix("whsec_")
    try:
        key = base64.b64decode(encoded_secret)
    except Exception as exc:
        raise WebhookVerificationError("Segredo de webhook inválido.") from exc

    signed = f"{message_id}.{timestamp}.".encode("utf-8") + payload
    expected = base64.b64encode(hmac.new(key, signed, hashlib.sha256).digest()).decode("ascii")

    valid = False
    for token in signatures.split():
        if "," not in token:
            continue
        version, signature = token.split(",", 1)
        if version == "v1" and hmac.compare_digest(signature, expected):
            valid = True
            break
    if not valid:
        raise WebhookVerificationError("Assinatura de webhook inválida.")
