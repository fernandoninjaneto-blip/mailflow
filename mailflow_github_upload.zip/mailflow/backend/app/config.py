from __future__ import annotations

import os
from dataclasses import dataclass
from urllib.parse import urlparse


def env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def csv_env(name: str, default: str = "") -> list[str]:
    return [x.strip().rstrip("/") for x in os.getenv(name, default).split(",") if x.strip()]


@dataclass(frozen=True)
class Settings:
    app_env: str = os.getenv("APP_ENV", "development").strip().lower()
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./mailflow.db")
    app_url: str = os.getenv("APP_URL", "http://localhost:8080").rstrip("/")
    public_base_url: str = os.getenv("MAILFLOW_PUBLIC_BASE_URL", "http://localhost:8080").rstrip("/")
    mail_provider: str = os.getenv("MAIL_PROVIDER", "console").strip().lower()
    cookie_secure: bool = env_bool("COOKIE_SECURE", False)
    expose_reset_token: bool = env_bool("MAILFLOW_EXPOSE_RESET_TOKEN", False)
    csrf_enabled: bool = env_bool("MAILFLOW_CSRF_ENABLED", False)
    origin_check_enabled: bool = env_bool("MAILFLOW_ORIGIN_CHECK_ENABLED", False)
    trusted_origins: tuple[str, ...] = tuple(csv_env("MAILFLOW_TRUSTED_ORIGINS", "http://localhost:8080,http://127.0.0.1:8080"))
    require_worker_health: bool = env_bool("MAILFLOW_REQUIRE_WORKER_HEALTH", False)
    worker_stale_seconds: int = int(os.getenv("MAILFLOW_WORKER_STALE_SECONDS", "90"))
    log_level: str = os.getenv("LOG_LEVEL", "INFO").upper()
    trust_proxy_headers: bool = env_bool("TRUST_PROXY_HEADERS", False)

    @property
    def production_like(self) -> bool:
        return self.app_env in {"staging", "production"}


settings = Settings()


def _is_https(url: str) -> bool:
    try:
        return urlparse(url).scheme == "https"
    except Exception:
        return False


def validate_runtime_configuration() -> list[str]:
    """Return configuration errors. In production these are fatal at startup."""
    errors: list[str] = []
    if not settings.production_like:
        return errors

    if settings.database_url.startswith("sqlite"):
        errors.append("DATABASE_URL não pode usar SQLite em staging/produção.")
    if not settings.cookie_secure:
        errors.append("COOKIE_SECURE deve ser true em staging/produção.")
    if settings.expose_reset_token:
        errors.append("MAILFLOW_EXPOSE_RESET_TOKEN deve ser false em staging/produção.")
    if not settings.csrf_enabled:
        errors.append("MAILFLOW_CSRF_ENABLED deve ser true em staging/produção.")
    if not settings.origin_check_enabled:
        errors.append("MAILFLOW_ORIGIN_CHECK_ENABLED deve ser true em staging/produção.")
    if not env_bool("MAILFLOW_RATE_LIMIT_ENABLED", False):
        errors.append("MAILFLOW_RATE_LIMIT_ENABLED deve ser true em staging/produção.")
    if not settings.trust_proxy_headers:
        errors.append("TRUST_PROXY_HEADERS deve ser true atrás do reverse proxy de staging/produção.")
    if not settings.trusted_origins:
        errors.append("MAILFLOW_TRUSTED_ORIGINS deve conter ao menos uma origem confiável.")
    elif any(not _is_https(origin) for origin in settings.trusted_origins):
        errors.append("Todas as MAILFLOW_TRUSTED_ORIGINS devem usar HTTPS em staging/produção.")
    if not _is_https(settings.app_url):
        errors.append("APP_URL deve usar HTTPS em staging/produção.")
    if not _is_https(settings.public_base_url):
        errors.append("MAILFLOW_PUBLIC_BASE_URL deve usar HTTPS em staging/produção.")

    required_secrets = {
        "MAILFLOW_CSRF_SECRET": os.getenv("MAILFLOW_CSRF_SECRET", ""),
        "MAILFLOW_SECURITY_SECRET": os.getenv("MAILFLOW_SECURITY_SECRET", ""),
        "MAILFLOW_UNSUBSCRIBE_SECRET": os.getenv("MAILFLOW_UNSUBSCRIBE_SECRET", ""),
        "MAILFLOW_SUPPRESSION_SECRET": os.getenv("MAILFLOW_SUPPRESSION_SECRET", ""),
    }
    for name, value in required_secrets.items():
        if len(value) < 32:
            errors.append(f"{name} deve ter pelo menos 32 caracteres aleatórios.")

    if settings.mail_provider == "resend":
        if not os.getenv("RESEND_API_KEY", ""):
            errors.append("RESEND_API_KEY é obrigatório quando MAIL_PROVIDER=resend.")
        if not os.getenv("RESEND_WEBHOOK_SECRET", ""):
            errors.append("RESEND_WEBHOOK_SECRET é obrigatório quando MAIL_PROVIDER=resend.")

    session_cookie = os.getenv("SESSION_COOKIE_NAME", "")
    csrf_cookie = os.getenv("CSRF_COOKIE_NAME", "")
    if settings.app_env == "production" and not session_cookie.startswith("__Host-"):
        errors.append("SESSION_COOKIE_NAME deve usar prefixo __Host- em produção.")
    if settings.app_env == "production" and not csrf_cookie.startswith("__Host-"):
        errors.append("CSRF_COOKIE_NAME deve usar prefixo __Host- em produção.")
    return errors
