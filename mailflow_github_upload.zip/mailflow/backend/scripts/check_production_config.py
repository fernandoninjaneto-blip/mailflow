from __future__ import annotations

import sys
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

from app.config import validate_runtime_configuration  # noqa: E402

errors = validate_runtime_configuration()
if errors:
    for item in errors:
        print(f"ERRO: {item}")
    raise SystemExit(1)
print("Configuração de produção validada.")
