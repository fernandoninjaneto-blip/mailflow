from __future__ import annotations

import os
import sys

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect, text

BASELINE = "0001_v14_baseline"
REQUIRED_TABLES = {"workspaces", "users", "contacts", "campaigns", "email_deliveries", "automations", "marketing_events"}


def main() -> int:
    url = os.getenv("DATABASE_URL", "")
    if not url:
        print("DATABASE_URL ausente.", file=sys.stderr)
        return 2
    engine = create_engine(url, pool_pre_ping=True)
    inspector = inspect(engine)
    tables = set(inspector.get_table_names())
    cfg = Config("alembic.ini")
    cfg.set_main_option("sqlalchemy.url", url.replace("%", "%%"))

    if "alembic_version" not in tables:
        missing = sorted(REQUIRED_TABLES - tables)
        if missing:
            print("A base não parece ser uma v0.14 válida. Tabelas ausentes: " + ", ".join(missing), file=sys.stderr)
            return 3
        campaign_columns = {c["name"] for c in inspector.get_columns("campaigns")}
        expected = {"utm_enabled", "send_armed", "exclude_tags", "open_events", "click_events"}
        if not expected.issubset(campaign_columns):
            print("Schema de campaigns anterior ao baseline v0.14; interrompendo para evitar migração incorreta.", file=sys.stderr)
            return 4
        command.stamp(cfg, BASELINE)
        print(f"Baseline {BASELINE} aplicado à base existente.")
    else:
        with engine.connect() as conn:
            version = conn.execute(text("SELECT version_num FROM alembic_version")).scalar()
        print(f"Alembic já inicializado em {version}.")

    command.upgrade(cfg, "head")
    print("Upgrade Alembic concluído em head.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
